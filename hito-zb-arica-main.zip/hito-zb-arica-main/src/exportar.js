// Descarga de cuadros en Excel (.xlsx) o Word (.doc) desde cualquier pantalla.
import React, { useState } from "react";
import { Platform, Alert, View } from "react-native";
import * as XLSX from "xlsx";
import { File, Paths } from "expo-file-system";
import * as Sharing from "expo-sharing";
import { Btn, Row } from "./ui";

const hoy = () => { const d = new Date(); return [d.getDate(), d.getMonth() + 1, d.getFullYear()].map((x) => String(x).padStart(2, "0")).join("-"); };
const limpio = (s) => String(s || "Hito").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^A-Za-z0-9_-]+/g, "_").slice(0, 60);

export async function entregar(bytes, nombre, mime) {
  if (Platform.OS === "web") {
    const blob = new Blob([bytes], { type: mime }); const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = nombre; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000); return;
  }
  const f = new File(Paths.cache, nombre); if (f.exists) f.delete(); f.create(); f.write(bytes);
  await Sharing.shareAsync(f.uri, { mimeType: mime, dialogTitle: nombre });
}

// hojas: [{ nombre: "Tareas", filas: [[encabezados...], [fila...], ...] }]
export async function aExcel(titulo, hojas) {
  const wb = XLSX.utils.book_new();
  hojas.forEach((h, i) => {
    const filas = h.filas && h.filas.length ? h.filas : [["Sin datos"]];
    const ws = XLSX.utils.aoa_to_sheet(filas);
    const n = Math.max(...filas.map((f) => f.length));
    ws["!cols"] = [...Array(n)].map((_, c) => ({ wch: Math.min(60, Math.max(8, ...filas.map((f) => String(f[c] == null ? "" : f[c]).length + 2))) }));
    XLSX.utils.book_append_sheet(wb, ws, String(h.nombre || "Hoja" + (i + 1)).slice(0, 31).replace(/[\\/?*[\]:]/g, " "));
  });
  const bytes = new Uint8Array(XLSX.write(wb, { type: "array", bookType: "xlsx" }));
  await entregar(bytes, limpio(titulo) + "_" + hoy() + ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
}

const esc = (s) => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\n/g, "<br/>");
export async function aWord(titulo, hojas, notas) {
  const tablas = hojas.map((h) => {
    const [cab, ...rest] = h.filas && h.filas.length ? h.filas : [["Sin datos"]];
    return (hojas.length > 1 || h.nombre ? "<h3>" + esc(h.nombre) + "</h3>" : "") +
      "<table><thead><tr>" + cab.map((c) => "<th>" + esc(c) + "</th>").join("") + "</tr></thead><tbody>" +
      rest.map((r) => "<tr>" + cab.map((_, i) => "<td>" + esc(r[i]) + "</td>").join("") + "</tr>").join("") + "</tbody></table>";
  }).join("");
  const html = "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word'><head><meta charset='utf-8'><title>" + esc(titulo) + "</title>" +
    "<style>body{font-family:Arial;font-size:10pt} h2{font-size:13pt;margin:0 0 4pt} h3{font-size:11pt;margin:12pt 0 4pt} p.s{color:#555;margin:0 0 8pt} table{border-collapse:collapse;width:100%} th,td{border:1px solid #777;padding:3pt 5pt;vertical-align:top} th{background:#DDE6E1}</style></head><body>" +
    "<p class='s'>EJÉRCITO DE CHILE · Zona de Bienestar \"Arica\"</p><h2>" + esc(titulo) + "</h2><p class='s'>Generado en Hito el " + hoy() + "</p>" +
    (notas ? "<p>" + esc(notas) + "</p>" : "") + tablas + "</body></html>";
  const bytes = new TextEncoder().encode("﻿" + html);
  await entregar(bytes, limpio(titulo) + "_" + hoy() + ".doc", "application/msword");
}

export async function aPpt(titulo, hojas, notas) {
  const PptxGenJS = require("pptxgenjs");
  const P = PptxGenJS.default || PptxGenJS;
  const p = new P(); p.layout = "LAYOUT_WIDE"; p.title = titulo;
  const port = p.addSlide();
  port.background = { color: "16201C" };
  port.addText("EJÉRCITO DE CHILE · Zona de Bienestar \"Arica\"", { x: 0.6, y: 1.6, w: 12, h: 0.5, fontSize: 16, color: "C9D3CE", fontFace: "Arial" });
  port.addText(titulo, { x: 0.6, y: 2.2, w: 12, h: 1.4, fontSize: 34, bold: true, color: "FFFFFF", fontFace: "Arial" });
  port.addText("Generado en Hito el " + hoy() + (notas ? "\n" + notas : ""), { x: 0.6, y: 3.8, w: 12, h: 1, fontSize: 14, color: "F2B78F", fontFace: "Arial" });
  hojas.forEach((h) => {
    const filas = h.filas && h.filas.length ? h.filas : [["Sin datos"]];
    const [cab, ...rest] = filas; const n = cab.length;
    const per = 12;
    for (let i = 0; i < Math.max(1, rest.length); i += per) {
      const sl = p.addSlide();
      sl.addText((h.nombre || titulo) + (rest.length > per ? "  (" + (i / per + 1) + "/" + Math.ceil(rest.length / per) + ")" : ""), { x: 0.4, y: 0.25, w: 12.5, h: 0.6, fontSize: 22, bold: true, color: "1F5D4C", fontFace: "Arial" });
      const rows = [cab.map((c) => ({ text: String(c), options: { bold: true, fill: { color: "DDE6E1" }, color: "16201C" } }))]
        .concat(rest.slice(i, i + per).map((r) => cab.map((_, j) => ({ text: String(r[j] == null ? "" : r[j]) }))));
      sl.addTable(rows, { x: 0.4, y: 1.0, w: 12.5, fontSize: n > 6 ? 9 : 11, fontFace: "Arial", color: "16201C", border: { type: "solid", pt: 0.5, color: "999999" }, valign: "top" });
      sl.addText("ZB Arica · Hito", { x: 0.4, y: 7.0, w: 6, h: 0.3, fontSize: 9, color: "8A968F" });
    }
  });
  const bytes = await p.write({ outputType: "uint8array" });
  await entregar(bytes, limpio(titulo) + "_" + hoy() + ".pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation");
}

// Botones "Excel", "Word" y "PPT". build() devuelve { hojas, notas? } al momento de descargar.
export function Descargar({ titulo, build, label }) {
  const [busy, setBusy] = useState(false);
  const go = async (fmt) => {
    setBusy(true);
    try { const r = build(); if (fmt === "x") await aExcel(titulo, r.hojas); else if (fmt === "p") await aPpt(titulo, r.hojas, r.notas); else await aWord(titulo, r.hojas, r.notas); }
    catch (e) { Alert.alert("No se pudo descargar", String((e && e.message) || e)); }
    setBusy(false);
  };
  return (
    <View>
      <Row style={{ flexWrap: "wrap" }}>
        <Btn small title={busy ? "Preparando…" : (label || "Descargar") + " Excel"} disabled={busy} onPress={() => go("x")} />
        <Btn small title="Word" disabled={busy} onPress={() => go("w")} />
        <Btn small title="PPT" disabled={busy} onPress={() => go("p")} />
      </Row>
    </View>
  );
}

// Convierte tablas en formato markdown (| a | b |) de un texto en hojas.
export function tablasDeTexto(texto) {
  const out = []; let cur = null;
  String(texto || "").split("\n").forEach((l) => {
    const t = l.trim();
    if (/^\|.*\|$/.test(t)) {
      if (/^\|[\s:|-]+\|$/.test(t)) return;
      const cells = t.slice(1, -1).split("|").map((c) => c.trim().replace(/\*\*/g, ""));
      if (!cur) { cur = { nombre: "Cuadro " + (out.length + 1), filas: [] }; out.push(cur); }
      cur.filas.push(cells);
    } else cur = null;
  });
  return out;
}
