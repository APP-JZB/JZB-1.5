// Datos del proyecto Supabase de la Zona. La clave "anon" es pública por diseño:
// la seguridad la dan las reglas por filas (RLS) definidas en supabase/schema.sql.
export const SUPABASE_URL = "https://qgzdytylvsbvvmkmlvxq.supabase.co";
export const SUPABASE_ANON_KEY = "sb_publishable_xG054BcxVDHHy1E_aqwLRQ_ItmTJ7_P";
