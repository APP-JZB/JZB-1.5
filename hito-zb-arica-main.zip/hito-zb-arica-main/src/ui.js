import React from "react";
import { View, Text, Pressable, TextInput, Modal, ScrollView, StyleSheet } from "react-native";
import { TF_COLORS } from "./catalog";

export const C = {
  bg: "#F3F4F0", surface: "#FFFFFF", surface2: "#ECEDE9", line: "#E2E5DF", line2: "#D5D9D2",
  ink: "#16201C", ink2: "#2F4A41", muted: "#4B5A54",
  accent: "#1F5D4C", accentSoft: "#E3ECE7", inv: "#16201C", invFg: "#F3F4F0", invMuted: "#C9D3CE", invHi: "#F2B78F",
  red: "#B4380A", redSoft: "#FBE4DA", redInk: "#8A2A07",
  amber: "#C98A12", amberSoft: "#FFF4E5", amberInk: "#7A4A12", amberLine: "#F2C79A",
  blue: "#2F5DA8", blueSoft: "#EAF0FA", blueLine: "#C7D5EE", blueInk: "#1E3A6B",
};

export function Btn({ title, onPress, kind = "default", disabled, style, small }) {
  const k = {
    default: { bg: C.surface, fg: C.ink, bd: C.line2 },
    primary: { bg: C.accent, fg: "#fff", bd: C.accent },
    dark: { bg: C.inv, fg: C.invFg, bd: C.inv },
    danger: { bg: C.surface, fg: C.red, bd: C.red },
    blue: { bg: C.blue, fg: "#fff", bd: C.blue },
  }[kind];
  return (
    <Pressable accessibilityRole="button" onPress={disabled ? undefined : onPress}
      style={({ pressed }) => [{ minHeight: small ? 38 : 46, paddingHorizontal: 14, borderRadius: 12, borderWidth: 1, borderColor: k.bd, backgroundColor: k.bg,
        alignItems: "center", justifyContent: "center", opacity: disabled ? 0.5 : pressed ? 0.8 : 1 }, style]}>
      <Text style={{ color: k.fg, fontWeight: "700", fontSize: small ? 13 : 15, textAlign: "center" }}>{title}</Text>
    </Pressable>
  );
}

export function Chip({ label, on, onPress, color }) {
  return (
    <Pressable accessibilityRole="button" accessibilityState={{ selected: !!on }} onPress={onPress}
      style={{ minHeight: 38, paddingHorizontal: 12, borderRadius: 999, borderWidth: 1, justifyContent: "center", marginRight: 6, marginBottom: 6,
        borderColor: on ? (color || C.inv) : C.line2, backgroundColor: on ? (color || C.inv) : C.surface }}>
      <Text style={{ color: on ? "#fff" : (color || C.ink2), fontWeight: on ? "700" : "500", fontSize: 13 }}>{label}</Text>
    </Pressable>
  );
}

export function Chips({ options, value, onChange, colors }) {
  return (
    <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
      {options.map((o) => {
        const k = Array.isArray(o) ? o[0] : o, l = Array.isArray(o) ? o[1] : o;
        return <Chip key={String(k)} label={l} on={k === value} color={colors && colors[k]} onPress={() => onChange(k)} />;
      })}
    </View>
  );
}

export function Card({ children, style, onPress, tone }) {
  const t = { inv: { bg: C.inv, bd: C.inv }, event: { bg: C.blueSoft, bd: C.blueLine }, warn: { bg: C.amberSoft, bd: C.amberLine } }[tone] || { bg: C.surface, bd: C.line };
  const inner = <View style={[{ backgroundColor: t.bg, borderColor: t.bd, borderWidth: 1, borderRadius: 16, padding: 14, gap: 8 }, style]}>{children}</View>;
  return onPress ? <Pressable onPress={onPress} accessibilityRole="button">{inner}</Pressable> : inner;
}

export function Badge({ text, kind }) {
  const k = { over: [C.red, "#fff"], soon: [C.amberSoft, C.amberInk], ok: [C.accent, "#fff"], done: [C.surface2, C.ink2], event: [C.blue, "#fff"] }[kind] || [C.surface2, C.ink2];
  return <View style={{ alignSelf: "flex-start", backgroundColor: k[0], borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 }}><Text style={{ color: k[1], fontSize: 11, fontWeight: "800" }}>{text}</Text></View>;
}

export function TfTag({ tf, proc }) {
  return <View style={{ alignSelf: "flex-start", backgroundColor: TF_COLORS[tf] || C.inv, borderRadius: 6, paddingHorizontal: 7, paddingVertical: 2 }}>
    <Text style={{ color: "#fff", fontSize: 11, fontWeight: "600" }}>{tf}{proc ? " · " + proc : ""}</Text></View>;
}

export function Field({ label, ...props }) {
  return (
    <View style={{ gap: 6 }}>
      <Text style={S.label}>{label}</Text>
      <TextInput placeholderTextColor="#8A968F" {...props}
        style={[{ minHeight: 46, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 14, fontSize: 15, color: C.ink },
          props.multiline ? { minHeight: 96, paddingTop: 12, textAlignVertical: "top" } : null]} />
    </View>
  );
}

export function Note({ text, kind = "ok" }) {
  const k = { ok: [C.accentSoft, C.ink2], warn: [C.amberSoft, C.amberInk], bad: [C.redSoft, C.redInk], info: [C.blueSoft, C.blueInk] }[kind];
  return <View style={{ backgroundColor: k[0], borderRadius: 12, padding: 12 }}><Text style={{ color: k[1], fontSize: 13, lineHeight: 19 }}>{text}</Text></View>;
}

export function Sheet({ visible, title, onClose, children }) {
  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose} presentationStyle="pageSheet">
      <View style={{ flex: 1, backgroundColor: C.bg }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 16, paddingTop: 22, borderBottomWidth: 1, borderColor: C.line }}>
          <Text style={{ fontSize: 18, fontWeight: "800", color: C.ink, flex: 1 }} numberOfLines={2}>{title}</Text>
          <Pressable onPress={onClose} accessibilityLabel="Cerrar" style={{ padding: 10 }}><Text style={{ fontSize: 15, color: C.muted, fontWeight: "700" }}>Cerrar</Text></Pressable>
        </View>
        <ScrollView contentContainerStyle={{ padding: 16, gap: 14, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">{children}</ScrollView>
      </View>
    </Modal>
  );
}

export function Empty({ text }) {
  return <View style={{ borderWidth: 1, borderStyle: "dashed", borderColor: C.line2, borderRadius: 16, padding: 20 }}><Text style={{ color: C.muted, textAlign: "center" }}>{text}</Text></View>;
}

export function Row({ children, style }) { return <View style={[{ flexDirection: "row", alignItems: "center", gap: 8 }, style]}>{children}</View>; }
export function Between({ children, style }) { return <View style={[{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 }, style]}>{children}</View>; }

export const S = StyleSheet.create({
  label: { fontSize: 12, fontWeight: "700", color: C.muted },
  h2: { fontSize: 16, fontWeight: "700", color: C.ink },
  title: { fontSize: 15, fontWeight: "700", color: C.ink },
  small: { fontSize: 12, color: C.muted },
  body: { fontSize: 14, color: C.ink2, lineHeight: 20 },
});
