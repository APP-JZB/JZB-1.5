import React, { useState } from "react";
import { View, Alert } from "react-native";
import { Btn, Note } from "./ui";
import { entregar } from "./exportar";
import { crearZipDescriptores, crearDescriptor } from "./descriptor-docx";

export function DescargarDescriptores({ d, profile }) {
 const [busy,setBusy]=useState(false),[progress,setProgress]=useState("");
 async function download(){
  setBusy(true);setProgress("Preparando documentos…");
  try{
   const date=new Date().toISOString().slice(0,10);
   if(profile){
    const bytes=await crearDescriptor({cargo:profile.cargo,definition:profile.definition,source:profile.definition.manual?"Ficha guardada en HITO":"Descriptor institucional de referencia",unit:profile.unit||(d.members.find(m=>m.cargo===profile.cargo)||{}).unit||""});
    const name=profile.cargo.normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zA-Z0-9]+/g,"_").slice(0,100);
    await entregar(bytes,`Descriptor_${name}_${date}.docx`,"application/vnd.openxmlformats-officedocument.wordprocessingml.document");
   }else{
    const result=await crearZipDescriptores(d,(done,total)=>setProgress(`Preparando ${done} de ${total}…`));
    await entregar(result.bytes,`Descriptores_ZB_Arica_${date}.zip`,"application/zip");
   }
  }catch(e){Alert.alert("No se pudo descargar",e.message||String(e));}
  finally{setBusy(false);setProgress("");}
 }
 return <View style={{gap:6}}><Btn title={busy?progress:profile?"Descargar este descriptor en Word":"Descargar todos los descriptores en ZIP"} disabled={busy||!!profile&&!profile.definition} kind="primary" onPress={download}/>{!profile?<Note text="Un Word por cargo, con el formato institucional. Incluye índice y cargos sin descriptor registrado."/>:null}</View>;
}
