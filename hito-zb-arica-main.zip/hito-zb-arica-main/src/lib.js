import "react-native-url-polyfill/auto";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { createClient } from "@supabase/supabase-js";
import { SUPABASE_URL, SUPABASE_ANON_KEY } from "./config";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { storage: AsyncStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false },
});

export const DAY = 86400000;

// Teléfono → dígitos con prefijo de Chile (56 9 XXXX XXXX)
export function phoneDigits(p) {
  let d = String(p || "").replace(/\D/g, "");
  if (d.length === 9 && d[0] === "9") d = "56" + d;
  else if (d.length === 8) d = "569" + d;
  return d;
}
export function waLink(phone, text) {
  return "https://wa.me/" + phoneDigits(phone) + "?text=" + encodeURIComponent(text);
}

const DIAS = ["dom", "lun", "mar", "mié", "jue", "vie", "sáb"];
const MESES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
const p2 = (x) => String(x).padStart(2, "0");
export function fmtDay(ms) { const d = new Date(ms); return DIAS[d.getDay()] + " " + d.getDate() + " " + MESES[d.getMonth()]; }
export function fmtTime(ms) { const d = new Date(ms); return p2(d.getHours()) + ":" + p2(d.getMinutes()); }
export function fmt(ms) { return fmtDay(ms) + ", " + fmtTime(ms); }
export function startOfDay(ms) { const d = new Date(ms); d.setHours(0, 0, 0, 0); return d.getTime(); }
export function addDays(ms, n) { const d = new Date(ms); d.setDate(d.getDate() + n); return d.getTime(); }
export function weekStart(ms) { const d = new Date(startOfDay(ms)); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d.getTime(); }
// "dd-mm-aaaa hh:mm" ↔ ms
export function toInput(ms) { const d = new Date(ms); return p2(d.getDate()) + "-" + p2(d.getMonth() + 1) + "-" + d.getFullYear() + " " + p2(d.getHours()) + ":" + p2(d.getMinutes()); }
export function fromInput(s) {
  const m = String(s || "").trim().match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})(?:\s+(\d{1,2}):(\d{2}))?$/);
  if (!m) return null;
  const d = new Date(+m[3], +m[2] - 1, +m[1], m[4] ? +m[4] : 12, m[5] ? +m[5] : 0);
  return isNaN(d.getTime()) ? null : d.getTime();
}

export function due(t) { return new Date(t.due).getTime(); }
export function status(t) {
  if (t.done) return "done";
  const d = due(t) - Date.now();
  if (d < 0) return "over";
  if (d < 2 * DAY) return "soon";
  return "ok";
}
export function onTime(t) { return !!(t.done && !t.late && t.done_at && new Date(t.done_at).getTime() <= due(t)); }
export function grade(ok, tot) { return tot ? 1 + 6 * ok / tot : null; }
export function gfmt(g) { return g == null ? "—" : g.toFixed(1).replace(".", ","); }
export function initials(name) { return String(name || "?").replace(/^\S+\s/, "").split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase(); }
export function norm(s) { return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }
export const RANKS = ["GDB", "CRL", "TCL", "MAY", "CAP", "TTE", "STE", "SOM", "SOF", "SG1", "SG2", "CB1", "CB2", "CBO", "SLC", "ECP", "ECL", "PAC", "PAJ", "PAH"];
export function rank(m) { const g = (m.grado || String(m.name || "").split(/\s+/)[0] || "").toUpperCase(); const i = RANKS.indexOf(g); return i < 0 ? 50 : i; }
export function errMsg(e) {
  const m = (e && (e.message || e.error_description)) || "";
  if (/Invalid login credentials/i.test(m)) return "Número o PIN incorrecto.";
  if (/already registered/i.test(m)) return "Ese número ya tiene acceso. Usa “Ingresar”.";
  if (/Password should be/i.test(m)) return "El PIN debe tener al menos 6 dígitos.";
  if (/duplicate key value violates unique constraint .?tasks_actividad_due/i.test(m)) return "Ya existe otra ocurrencia de esta actividad con ese plazo. Verifica la tarea periódica antes de cambiar la fecha.";
  if (/network|fetch/i.test(m)) return "Sin conexión. Revisa tu señal e inténtalo de nuevo.";
  return m || "No se pudo completar. Inténtalo de nuevo.";
}
