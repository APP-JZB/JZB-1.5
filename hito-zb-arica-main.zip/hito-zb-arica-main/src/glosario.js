// Glosario de Hito (Mural → Glosario): define las palabras que usa la app para evitar confusiones.
// Lo leen todos; solo el Comandante lo edita (control en la base de datos, tabla glosario).
import React, { useState, useEffect, useCallback } from "react";
import { View, Text, Alert, TextInput } from "react-native";
import { supabase, norm, errMsg } from "./lib";
import { C, S, Btn, Chips, Card, Field, Note, Sheet, Row, Between, Empty } from "./ui";

const GRUPOS = ["Tareas", "Plazos", "Organización", "Parte", "Gestión", "Procesos", "Pantallas", "General"];

function Editor({ t, meId, onClose, onOk }) {
  const [termino, setTermino] = useState(t ? t.termino : "");
  const [definicion, setDefinicion] = useState(t ? t.definicion : "");
  const [grupo, setGrupo] = useState(t ? t.grupo : "General");
  const [busy, setBusy] = useState(false);
  async function guardar() {
    if (!termino.trim() || !definicion.trim()) return Alert.alert("Completa la palabra y su definición");
    setBusy(true);
    const body = { termino: termino.trim(), definicion: definicion.trim(), grupo, updated_at: new Date().toISOString(), updated_by: meId };
    const { error } = t ? await supabase.from("glosario").update(body).eq("id", t.id) : await supabase.from("glosario").insert(body);
    setBusy(false);
    if (error) return Alert.alert("No se pudo guardar", /duplicate|unique/i.test(error.message || "") ? "Esa palabra ya está en el glosario." : errMsg(error));
    onOk(); onClose();
  }
  function borrar() {
    Alert.alert("¿Quitar “" + t.termino + "” del glosario?", "", [{ text: "No", style: "cancel" }, { text: "Quitar", style: "destructive", onPress: async () => {
      const { error } = await supabase.from("glosario").delete().eq("id", t.id);
      if (error) return Alert.alert("No se pudo", errMsg(error)); onOk(); onClose();
    } }]);
  }
  return (
    <Sheet visible title={t ? "Editar definición" : "Nueva palabra"} onClose={onClose}>
      <Field label="Palabra o concepto" value={termino} onChangeText={setTermino} placeholder="Ej.: Escalar" />
      <Text style={S.label}>Definición</Text>
      <TextInput value={definicion} onChangeText={setDefinicion} multiline placeholder="Qué significa en Hito y cuándo se usa"
        placeholderTextColor="#8A968F" style={{ minHeight: 110, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, padding: 12, textAlignVertical: "top", color: C.ink }} />
      <Text style={S.label}>Grupo</Text>
      <Chips options={GRUPOS.map((g) => [g, g])} value={grupo} onChange={setGrupo} />
      <Btn title={busy ? "Guardando…" : "Guardar"} kind="primary" disabled={busy} onPress={guardar} />
      {t ? <Btn title="Quitar del glosario" kind="danger" onPress={borrar} /> : null}
    </Sheet>);
}

export function Glosario({ d, isAdmin }) {
  const [rows, setRows] = useState(null); const [err, setErr] = useState("");
  const [q, setQ] = useState(""); const [g, setG] = useState("todo"); const [edit, setEdit] = useState(null);
  const cargar = useCallback(async () => {
    const { data, error } = await supabase.from("glosario").select("*").order("orden").order("termino");
    if (error) return setErr(errMsg(error)); setErr(""); setRows(data || []);
  }, []);
  useEffect(() => { cargar(); }, [cargar]);
  if (err) return <Note kind="bad" text={"No se pudo cargar el glosario: " + err} />;
  if (!rows) return <Empty text="Cargando…" />;
  const qq = norm(q);
  const grupos = GRUPOS.filter((x) => rows.some((r) => r.grupo === x));
  const list = rows.filter((r) => (g === "todo" || r.grupo === g) && (!qq || norm(r.termino + " " + r.definicion).includes(qq)));
  const porGrupo = grupos.map((x) => [x, list.filter((r) => r.grupo === x)]).filter((x) => x[1].length);
  return (
    <View style={{ gap: 12 }}>
      <Note kind="info" text={"Qué significa cada palabra en Hito. " + (isAdmin ? "Puedes corregir o agregar definiciones; los cambios los ven todos al instante." : "Si una definición no es clara, coméntalo al Comandante.")} />
      {isAdmin ? <Btn title="+ Nueva palabra" kind="primary" onPress={() => setEdit({})} /> : null}
      <TextInput value={q} onChangeText={setQ} placeholder="Buscar palabra (ej.: escalar, derivar)" placeholderTextColor="#8A968F"
        style={{ minHeight: 44, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 12, color: C.ink }} />
      <Chips options={[["todo", "Todo"]].concat(grupos.map((x) => [x, x]))} value={g} onChange={setG} />
      {porGrupo.length ? porGrupo.map(([grupo, items]) => (
        <View key={grupo} style={{ gap: 8 }}>
          <Text style={S.label}>{grupo.toUpperCase()}</Text>
          {items.map((r) => (
            <Card key={r.id} onPress={isAdmin ? () => setEdit(r) : undefined} style={{ gap: 4 }}>
              <Between><Text style={[S.title, { flex: 1 }]}>{r.termino}</Text>{isAdmin ? <Text style={{ fontSize: 12, color: C.accent, fontWeight: "700" }}>Editar</Text> : null}</Between>
              <Text style={S.body}>{r.definicion}</Text>
            </Card>))}
        </View>)) : <Empty text="No hay palabras que coincidan." />}
      {edit ? <Editor t={edit.id ? edit : null} meId={d.me && d.me.id} onClose={() => setEdit(null)} onOk={cargar} /> : null}
    </View>);
}
