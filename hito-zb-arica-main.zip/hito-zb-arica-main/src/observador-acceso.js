import React, { useCallback, useEffect, useState } from "react";
import { View, Text, ActivityIndicator } from "react-native";
import { phoneDigits } from "./lib";
import { Btn, Field, Note, S } from "./ui";
import { accessAction, CambiarClave } from "./usuarios";
import { Observador } from "./observador-panel";

export function ObserverLogin({ onLogin, onBack }) {
 const [phone,setPhone]=useState(""),[pin,setPin]=useState(""),[busy,setBusy]=useState(false),[error,setError]=useState("");
 async function login(){setBusy(true);setError("");try{const r=await accessAction({action:"observer_login",phone:phoneDigits(phone),password:pin});setPin("");onLogin(r.token);}catch(e){setError(e.message);}finally{setBusy(false);}}
 return <View style={{flex:1,padding:24,justifyContent:"center",gap:16}}><Text style={{...S.title,fontSize:28}}>Ingreso de observadores</Text><Note text="Solo consulta. Usa el teléfono y el PIN entregados por el Comandante."/><Field label="Teléfono" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="9 1234 5678"/><Field label="PIN" value={pin} onChangeText={setPin} secureTextEntry keyboardType="number-pad"/>{error?<Note kind="bad" text={error}/>:null}<Btn title={busy?"Ingresando…":"Ingresar como observador"} kind="primary" onPress={login} disabled={busy}/><Btn title="Volver al ingreso de integrantes" onPress={onBack} disabled={busy}/></View>;
}
export function ObserverSession({ token, onExit }) {
 const [d,setD]=useState(null),[error,setError]=useState("");
 const reload=useCallback(async()=>{try{const next=await accessAction({action:"observer_read",token});setD(next);setError("");}catch(e){setD(null);setError(e.message);}},[token]);
 useEffect(()=>{let active=true;accessAction({action:"observer_read",token}).then(next=>{if(active)setD(next);}).catch(e=>{if(active)setError(e.message);});const timer=setInterval(reload,60000);return()=>{active=false;clearInterval(timer);};},[token,reload]);
 const exit=()=>{accessAction({action:"observer_logout",token}).catch(()=>{});onExit();};
 if(error)return <View style={{padding:24,gap:12}}><Note kind="bad" text={error}/><Btn title="Reintentar" onPress={reload}/><Btn title="Salir" onPress={exit}/></View>;
 if(!d)return <ActivityIndicator style={{marginTop:100}}/>;
 if(d.password_change_required)return <CambiarClave required observerToken={token} onClose={reload} onExit={exit}/>;
 return <Observador d={d} reload={reload} token={token} onExit={exit}/>;
}
