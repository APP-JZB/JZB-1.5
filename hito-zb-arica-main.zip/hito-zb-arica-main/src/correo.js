// Avisos por correo: abren el correo listo en el Outlook de quien envía (sin guardar contraseñas).
import { Alert, Linking, Platform } from "react-native";
import { fmt, due } from "./lib";
const mname = (members, id) => ((members || []).find((m) => m.id === id) || {}).name || "—";

/* Aviso por correo: abre un correo listo en el Outlook de quien lo envía (web o app del teléfono) */
const WEB_APP = "https://sergiocerda22-maker.github.io/hito-zb-arica-web/";
export function notificarCorreo(d, ids, subject, body) {
  const ms = [...new Set(ids.filter(Boolean))].map((id) => d.members.find((m) => m.id === id) || { id, name: id });
  const emails = [...new Set(ms.map((m) => (m.email || "").trim()).filter(Boolean))];
  const sin = ms.filter((m) => !(m.email || "").trim()).map((m) => m.name);
  const full = firmaTexto(d, body);
  const enc = encodeURIComponent;
  const go = () => abrirOutlook(emails, subject, full);
  const ask = () => Alert.alert("Notificar por correo", "Se abre tu Outlook (con la sesión iniciada) con el correo listo para " + emails.length + " destinatario(s). Revísalo y toca Enviar.",
    [{ text: "Cancelar", style: "cancel" }, { text: "Abrir Outlook", onPress: go }]);
  if (!emails.length) return Alert.alert("Nadie tiene correo registrado", "Agrega el correo en Equipo o en Participantes: " + sin.join(", "));
  if (sin.length) return Alert.alert("Algunos sin correo", sin.join(", ") + " no tienen correo registrado y no recibirán el aviso.", [{ text: "Cancelar", style: "cancel" }, { text: "Continuar", onPress: ask }]);
  ask();
}
/* Abre el correo listo en la app Outlook del teléfono (la que ya tiene la sesión abierta).
   Android app: intención directa a Outlook · Android web: intent de Chrome a Outlook · iPhone: ms-outlook:// · computador: Outlook web. */
const OUTLOOK_PKG = "com.microsoft.office.outlook";
export async function abrirOutlook(emails, subject, body) {
  const enc = (x) => encodeURIComponent(x).replace(/%0A/g, "%0D%0A");
  const q = "subject=" + enc(subject) + "&body=" + enc(body);
  const mailto = "mailto:" + emails.join(",") + "?" + q;
  const web = "https://outlook.office.com/mail/deeplink/compose?to=" + encodeURIComponent(emails.join(";")) + "&subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
  const ios = "ms-outlook://compose?to=" + encodeURIComponent(emails.join(",")) + "&" + q;
  if (Platform.OS === "android") {
    try {
      const IL = require("expo-intent-launcher");
      await IL.startActivityAsync("android.intent.action.SENDTO", { data: mailto, packageName: OUTLOOK_PKG });
      return;
    } catch (e) {}
    try { await Linking.openURL(mailto); return; } catch (e) {}
    return Linking.openURL(web);
  }
  if (Platform.OS === "ios") { try { await Linking.openURL(ios); return; } catch (e) {} try { await Linking.openURL(mailto); return; } catch (e) {} return Linking.openURL(web); }
  // Web
  const ua = (typeof navigator !== "undefined" && navigator.userAgent) || "";
  if (/Android/i.test(ua)) {
    window.location.href = "intent:" + emails.join(",") + "?" + q + "#Intent;scheme=mailto;package=" + OUTLOOK_PKG + ";S.browser_fallback_url=" + encodeURIComponent(web) + ";end";
    return;
  }
  if (/iPhone|iPad|iPod/i.test(ua)) {
    window.location.href = ios;
    setTimeout(() => { if (document.visibilityState === "visible") window.location.href = mailto; }, 1500);
    return;
  }
  window.open(web, "_blank");
}
export function msgTarea(d, t) {
  return { ids: [t.member_id, t.apoyo, t.delegado, ...(t.participantes || [])], subject: "Hito ZB Arica · Tarea: " + t.title,
    body: "Se le informa la siguiente tarea en la app Hito:\n\n" + t.title + "\nPlazo: " + fmt(due(t)) + "\nResponsable: " + mname(d.members, t.member_id)
      + (t.apoyo ? "\nResponsable secundario: " + mname(d.members, t.apoyo) : "") + (t.delegado ? "\nDerivada a: " + mname(d.members, t.delegado) : "")
      + ((t.participantes || []).length ? "\nParticipantes: " + t.participantes.map((x) => mname(d.members, x)).join(", ") : "")
      + (t.controla ? "\nControla: " + mname(d.members, t.controla) : "") + (t.dirige ? "\nDirige: " + mname(d.members, t.dirige) : "")
      + (t.evidencia ? "\nProducto / evidencia: " + t.evidencia : "") };
}
export function msgEvento(d, e) {
  return { ids: [e.responsable, ...(e.participantes || [])], subject: "Hito ZB Arica · " + (e.type || "Evento") + ": " + e.title,
    body: "Se le informa el siguiente evento:\n\n" + (e.type ? e.type + ": " : "") + e.title + "\nFecha: " + fmt(new Date(e.at).getTime())
      + (e.responsable ? "\nResponsable: " + mname(d.members, e.responsable) : "") + ((e.participantes || []).length ? "\nParticipantes: " + e.participantes.map((x) => mname(d.members, x)).join(", ") : "")
      + (e.detail ? "\n\n" + e.detail : "") };
}
export function msgDerivacion(d, t, id, paso) {
  const adm = (d.members.find((m) => m.role === "admin") || {}).id;
  return { ids: [id, adm].filter((x) => x && x !== (d.me && d.me.id)), subject: "Hito ZB Arica · Tarea derivada: " + t.title,
    body: "Le derivo la siguiente tarea en la app Hito" + (paso ? " (paso " + paso.n + ": " + paso.a + ")" : "") + ":\n\n" + t.title + "\nPlazo: " + fmt(due(t))
      + "\nResponsable principal: " + mname(d.members, t.member_id) + "\nDerivada a: " + mname(d.members, id) + "\nDerivada por: " + ((d.me && d.me.name) || "") };
}
export function firmaTexto(d, body) {
  const yo = d.me || {}; const firma = yo.role === "admin" ? "TCL Sergio Cerda Larrañaga\nComandante Zona de Bienestar \"Arica\"" : (yo.name || "") + (yo.cargo ? "\n" + yo.cargo : "") + "\nZona de Bienestar \"Arica\"";
  return body + "\n\nRevisa y actualiza en Hito: " + WEB_APP + "\n\n" + firma;
}
