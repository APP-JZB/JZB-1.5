import React, { useMemo, useState } from "react";
import { View, Text, TextInput } from "react-native";
import { TaskCard } from "./screens";
import { AREA_GROUPS, AREA_COLORS, areaInfo } from "./catalog";
import { status, due, norm } from "./lib";
import { C, Card, Chip, Chips, Btn, Empty, S } from "./ui";

const STATUS = {
  over: "Vencida",
  soon: "Por vencer",
  ok: "En plazo",
  done: "Cumplida",
};
const FILTERS = [
  ["open", "Pendientes"],
  ["over", "Atrasadas"],
  ["soon", "Próx. 48 h"],
  ["done", "Completadas"],
  ["mine", "Mías"],
  ["all", "Todas"],
];

function ownerName(task, members) {
  const m = members.find((x) => x.id === task.member_id);
  return m ? m.name : "Sin asignar";
}

function taskStatus(task) {
  return STATUS[status(task)] || "Sin estado";
}

function groupColor(groupBy, group) {
  if (groupBy === "area") {
    const info = group.tasks[0] && areaInfo(group.tasks[0].area);
    return info ? AREA_COLORS[info.group] || C.accent : C.muted;
  }
  if (groupBy === "status" && group.name === "Vencida") return C.red;
  if (groupBy === "status" && group.name === "Por vencer") return C.amber;
  return C.accent;
}

export function VistaTareas({ d, open }) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("open");
  const [areaGroup, setAreaGroup] = useState(null);
  const [view, setView] = useState("tablero");
  const [groupBy, setGroupBy] = useState("area");
  const [limit, setLimit] = useState(60);
  const tasks = d.tasks || [];
  const members = d.members || [];
  const mineIds = new Set([d.me && d.me.id].filter(Boolean));

  const counts = useMemo(() => ({
    open: tasks.filter((t) => !t.done).length,
    over: tasks.filter((t) => !t.done && status(t) === "over").length,
    soon: tasks.filter((t) => !t.done && status(t) === "soon").length,
    done: tasks.filter((t) => t.done).length,
  }), [tasks]);

  const filtered = useMemo(() => tasks
    .filter((t) => {
      if (filter === "open" && t.done) return false;
      if (filter === "over" && (t.done || status(t) !== "over")) return false;
      if (filter === "soon" && (t.done || status(t) !== "soon")) return false;
      if (filter === "done" && !t.done) return false;
      if (filter === "mine" && ![t.member_id, t.apoyo, t.delegado, ...(t.participantes || [])].some((id) => mineIds.has(id))) return false;
      if (areaGroup && (areaInfo(t.area) || {}).group !== areaGroup) return false;
      if (query.trim()) {
        const a = areaInfo(t.area);
        const person = [ownerName(t, members), t.apoyo ? ownerName({ member_id: t.apoyo }, members) : "", t.delegado ? ownerName({ member_id: t.delegado }, members) : ""].join(" ");
        const haystack = [t.title, t.tf, t.proc, a && a.name, person, taskStatus(t)].filter(Boolean).join(" ");
        if (!norm(haystack).includes(norm(query))) return false;
      }
      return true;
    })
    .sort((a, b) => {
      if (filter === "done") return new Date(b.done_at || b.due || 0) - new Date(a.done_at || a.due || 0);
      return due(a) - due(b);
    }), [tasks, filter, areaGroup, query, members, d.me && d.me.id]);

  const getGroup = (task) => {
    if (groupBy === "status") return taskStatus(task);
    if (groupBy === "responsable") return ownerName(task, members);
    const info = areaInfo(task.area);
    return info ? info.name : "Sin área";
  };
  const groups = useMemo(() => {
    if (view === "lista") return [{ name: "Tareas", tasks: filtered.slice(0, limit) }];
    const map = new Map();
    filtered.forEach((t) => {
      const label = getGroup(t);
      if (!map.has(label)) map.set(label, []);
      map.get(label).push(t);
    });
    return Array.from(map.entries())
      .map(([name, list]) => ({ name, tasks: list.slice(0, limit) }))
      .sort((a, b) => {
        if (groupBy === "status") {
          const order = ["Vencida", "Por vencer", "En plazo", "Cumplida", "Sin estado"];
          return order.indexOf(a.name) - order.indexOf(b.name);
        }
        return a.name.localeCompare(b.name, "es");
      });
  }, [filtered, view, groupBy, limit, members]);

  const openTask = (task) => open({ kind: "task", id: task.id });

  return (
    <View style={{ gap: 12 }}>
      <Card tone="inv">
        <Text style={{ color: C.invMuted, fontSize: 12, fontWeight: "700" }}>VISTA DE TAREAS · DATOS DE HITO</Text>
        <Text style={{ color: C.invFg, fontSize: 22, fontWeight: "800" }}>Seguimiento del equipo</Text>
        <Text style={{ color: C.invMuted, fontSize: 13 }}>Agrupa por área, estado o responsable. Toca una tarea para ver su detalle y registrar avance.</Text>
      </Card>

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
        {[
          ["Pendientes", counts.open, C.ink],
          ["Atrasadas", counts.over, counts.over ? C.red : C.ink],
          ["Por vencer", counts.soon, counts.soon ? C.amberInk : C.ink],
          ["Completadas", counts.done, C.accent],
        ].map(([label, value, color]) => (
          <Card key={label} style={{ flexGrow: 1, flexBasis: 125, padding: 12, gap: 4 }}>
            <Text style={{ color: C.muted, fontSize: 12 }}>{label}</Text>
            <Text style={{ color, fontSize: 25, fontWeight: "800" }}>{value}</Text>
          </Card>
        ))}
      </View>

      <TextInput
        value={query}
        onChangeText={(value) => { setQuery(value); setLimit(60); }}
        placeholder="Buscar tarea, proceso, área o responsable"
        placeholderTextColor="#8A968F"
        accessibilityLabel="Buscar tareas por nombre, proceso, área o responsable"
        style={{ minHeight: 46, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 14, fontSize: 14, color: C.ink }}
      />

      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
        {FILTERS.map(([key, label]) => {
          const n = key === "open" ? counts.open : key === "over" ? counts.over : key === "soon" ? counts.soon : key === "done" ? counts.done : null;
          return <Chip key={key} label={label + (n == null ? "" : " (" + n + ")")} on={filter === key} onPress={() => { setFilter(key); setLimit(60); }} />;
        })}
      </View>

      <Text style={S.label}>FILTRAR POR ÁREA</Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
        <Chip label="Todas las áreas" on={!areaGroup} onPress={() => setAreaGroup(null)} />
        {AREA_GROUPS.map(([key, label]) => (
          <Chip key={key} label={label} on={areaGroup === key} color={AREA_COLORS[key]} onPress={() => setAreaGroup(areaGroup === key ? null : key)} />
        ))}
      </View>

      <View style={{ flexDirection: "row", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
        <Chips options={[["tablero", "Tablero"], ["lista", "Lista"]]} value={view} onChange={(value) => { setView(value); setLimit(60); }} />
        {view === "tablero" ? (
          <Chips options={[["area", "Área"], ["status", "Estado"], ["responsable", "Responsable"]]} value={groupBy} onChange={setGroupBy} />
        ) : null}
      </View>

      <Text style={S.small}>{filtered.length} tarea{filtered.length === 1 ? "" : "s"} en esta vista · ordenadas por plazo</Text>
      {!filtered.length ? <Empty text="No hay tareas que coincidan con estos filtros." /> : null}
      {groups.map((group) => (
        <View key={group.name} style={{ gap: 8 }}>
          {view === "tablero" ? (
            <View style={{ borderLeftWidth: 5, borderLeftColor: groupColor(groupBy, group), paddingLeft: 10, paddingVertical: 4 }}>
              <Text style={{ color: C.ink, fontWeight: "800", fontSize: 16 }}>{group.name} · {filtered.filter((t) => getGroup(t) === group.name).length}</Text>
            </View>
          ) : null}
          {group.tasks.map((t) => (
            <TaskCard key={t.id} t={t} members={members} onPress={() => openTask(t)} />
          ))}
        </View>
      ))}
      {filtered.length > limit ? <Btn title={"Mostrar " + Math.min(60, filtered.length - limit) + " más"} onPress={() => setLimit((n) => n + 60)} /> : null}
      <Text style={S.small}>Vencida: plazo superado · Por vencer: dentro de 48 horas · En plazo: posterior. El detalle mantiene controles y evidencia de HITO.</Text>
    </View>
  );
}

