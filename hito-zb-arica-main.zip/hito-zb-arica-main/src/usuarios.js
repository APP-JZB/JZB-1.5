import React, { useEffect, useState } from "react";
import { View, Text, Platform, Alert } from "react-native";
import { supabase, phoneDigits } from "./lib";
import { C, S, Btn, Field, Note, Card, Chips } from "./ui";
import { DASHBOARD_OWNER } from "./dashboard";

export async function accessAction(body) {
 const { data, error } = await supabase.functions.invoke("usuarios-admin", { body });
 if (error) {
  let message = "No se pudo completar. Revisa tu conexión e intenta nuevamente.";
  try { const detail = await error.context.json(); message = detail.error || message; } catch {}
  throw new Error(message);
 }
 if (data?.error) throw new Error(data.error);
 return data;
}
async function confirmAction(title, message) {
 if (Platform.OS === "web") return window.confirm(`${title}\n\n${message}`);
 return new Promise(resolve => Alert.alert(title, message, [{ text: "Cancelar", style: "cancel", onPress: () => resolve(false) }, { text: "Continuar", onPress: () => resolve(true) }], { cancelable: true, onDismiss: () => resolve(false) }));
}
export function CambiarClave({ required = false, admin = false, observerToken = null, onClose, onExit }) {
 const [password, setPassword] = useState(""); const [confirmation, setConfirmation] = useState("");
 const [busy, setBusy] = useState(false); const [message, setMessage] = useState("");
 async function save() {
  if (password !== confirmation) return setMessage("Las claves no coinciden.");
  if (admin ? password.length < 8 || password.length > 64 : !/^\d{8,64}$/.test(password)) return setMessage(admin ? "Usa entre 8 y 64 caracteres." : "Usa entre 8 y 64 dígitos.");
  setBusy(true); setMessage("");
  try { await accessAction({ action: observerToken ? "observer_change_password" : "change_password", password, token: observerToken }); if (!observerToken) { const {error}=await supabase.auth.refreshSession(); if(error) await supabase.auth.signOut(); } setPassword(""); setConfirmation(""); if (onClose) onClose(); }
  catch (e) { setMessage(e.message); }
  finally { setBusy(false); }
 }
 return <View style={{ padding: 16, gap: 12 }}><Text style={{ ...S.title, fontSize: 22 }}>{required ? "Crea tu nueva clave" : "Cambiar mi contraseña"}</Text>
  <Note kind="info" text={required ? "Tu contraseña fue restablecida. Elige una nueva clave personal para continuar." : "La cuenta conserva tus tareas y permisos."}/>
  <Field label={admin ? "Nueva contraseña (mínimo 8 caracteres)" : "Nuevo PIN (mínimo 8 dígitos)"} value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" keyboardType={admin ? "default" : "number-pad"}/>
  <Field label="Repetir clave nueva" value={confirmation} onChangeText={setConfirmation} secureTextEntry autoCapitalize="none" keyboardType={admin ? "default" : "number-pad"}/>
  {message ? <Note kind="bad" text={message}/> : null}<Btn title={busy ? "Guardando…" : "Guardar clave nueva"} disabled={busy} kind="primary" onPress={save}/>
  {!required ? <Btn title="Volver" disabled={busy} onPress={onClose}/> : <Btn title="Salir" onPress={onExit || (() => supabase.auth.signOut())}/>}
 </View>;
}

export function Usuarios({ d, session, reload }) {
 const [observers,setObservers]=useState([]);
 useEffect(()=>{if(session?.user?.id===DASHBOARD_OWNER)accessAction({action:"observer_list"}).then(r=>setObservers(r.observers||[])).catch(e=>setMessage(e.message));},[session?.user?.id]);
 const [query, setQuery] = useState(""); const [filter, setFilter] = useState("all"); const [selectedId, setSelectedId] = useState(null);
 const [name, setName] = useState(""); const [phone, setPhone] = useState(""); const [email, setEmail] = useState("");
 const [adding, setAdding] = useState(false); const [busy, setBusy] = useState(false); const [message, setMessage] = useState("");
 const [temporary, setTemporary] = useState(null); const [ownPassword, setOwnPassword] = useState(false);
 const isOwner = session?.user?.id === DASHBOARD_OWNER && d.me?.role === "admin";
 if (!isOwner) return null;
 if (ownPassword) return <CambiarClave admin onClose={() => {setOwnPassword(false);setMessage("Contraseña actualizada.");}}/>;
 const people = [...d.members,...observers];
 const selected = people.find(m => m.id === selectedId);
 const list = people.filter(m => (filter !== "observer" || m.role === "observer") && `${m.name} ${m.phone || ""} ${m.unit || ""}`.toLowerCase().includes(query.toLowerCase()));
 async function run(fn, success) {
  setBusy(true); setMessage("");
  try { await fn(); await reload(); const r=await accessAction({action:"observer_list"});setObservers(r.observers||[]);setMessage(success); }
  catch(e) { setMessage(e.message || "No se pudo guardar."); }
  finally { setBusy(false); }
 }
 async function add() {
  await run(async () => {
   const r=await accessAction({action:"observer_create",name:name.trim(),phone:phoneDigits(phone),email:email.trim() || null});
   setTemporary({name:name.trim(),password:r.temporary_password});
   setName("");setPhone("");setEmail("");setAdding(false);
  }, "Observador agregado. Debe ingresar por Observador con su teléfono y este PIN temporal.");
 }
 async function setObserver() {
  if(!await confirmAction("Cambiar acceso",selected.active?"Se desactivará esta cuenta de observador y sus sesiones.":"Se activará esta cuenta de observador."))return;
  await run(()=>accessAction({action:selected.active?"observer_deactivate":"observer_activate",member_id:selected.id}),"Acceso actualizado.");
 }
 async function reset() {
  if(!await confirmAction("Restablecer contraseña", `Se generará un PIN temporal para ${selected.name}. Deberá cambiarlo al ingresar. Su cuenta y tareas se conservan.`))return;
  await run(async()=>{const r=await accessAction({action:"reset_password",member_id:selected.id});setTemporary({name:selected.name,password:r.temporary_password});},"Contraseña restablecida. Entrega el PIN temporal de forma privada.");
 }
 return <View style={{gap:12}}>
  <Card tone="inv"><Text style={{color:C.invFg,fontSize:20,fontWeight:"800"}}>Administración de usuarios</Text><Text style={{color:C.invMuted}}>Integrantes: trabajo habitual. Observadores: solo indicadores agregados del dashboard.</Text></Card>
  <Btn title="Cambiar mi contraseña" onPress={()=>setOwnPassword(true)} disabled={busy}/>
  <Btn title={adding ? "Cerrar formulario" : "+ Agregar observador"} kind="primary" onPress={()=>{setAdding(!adding);setTemporary(null);}} disabled={busy}/>
  {adding ? <Card><Field label="Nombre y apellidos" value={name} onChangeText={setName}/><Field label="Celular chileno (para ingresar)" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="9 1234 5678"/><Field label="Correo de contacto (opcional)" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address"/><Note text="Se genera un PIN temporal. Ingresa por Observador y debe cambiarlo la primera vez. No se incorpora al parte de fuerza."/><Btn title="Guardar observador" onPress={add} disabled={busy} kind="primary"/></Card> : null}
  {message ? <Note text={message}/> : null}
  {temporary ? <Card><Text style={S.title}>PIN temporal · {temporary.name}</Text><Text selectable style={{fontSize:28,fontWeight:"800",letterSpacing:2,color:C.ink}}>{temporary.password}</Text><Text style={S.small}>Se muestra solo en esta pantalla. No se envía automáticamente ni se guarda en el código.</Text><Btn title="Ocultar PIN" onPress={()=>setTemporary(null)}/></Card> : null}
  <Chips options={[["all","Todos"],["observer","Observadores"]]} value={filter} onChange={setFilter}/>
  <Field label="Buscar usuario" value={query} onChangeText={setQuery} placeholder="Nombre, teléfono o unidad"/>
  <Text style={S.small}>{list.length} usuarios · {observers.length} observadores</Text>
  {selected ? <Card><Text style={S.title}>{selected.name}</Text><Text style={S.small}>{selected.role==="observer"?"Observador · solo lectura"+(selected.active?"":" · desactivado"):selected.role==="admin"?"Administrador":"Integrante"} · {selected.user_id?"Acceso creado":"Sin acceso creado"}</Text>
   {selected.role!=="admin" ? <>{selected.role==="observer"?<Btn title={selected.active?"Desactivar observador":"Activar observador"} onPress={setObserver} disabled={busy}/>:null}<Btn title="Resetear contraseña / PIN" kind="danger" onPress={reset} disabled={busy || !selected.user_id}/></> : <Note text="La cuenta administradora conserva sus permisos. Para tu clave usa Cambiar mi contraseña."/>}
   {!selected.user_id?<Note text="Debe usar Crear mi acceso con su teléfono registrado."/>:null}<Btn title="Cerrar ficha" onPress={()=>{setSelectedId(null);setTemporary(null);}} disabled={busy}/></Card>:null}
  {list.map(m=><Card key={m.id} onPress={busy?undefined:()=>{setSelectedId(m.id);setTemporary(null);setMessage("");}}><Text style={S.title}>{m.name}</Text><Text style={S.small}>{m.role==="observer"?"Observador · solo lectura":m.role==="admin"?"Administrador":"Integrante"} · {m.phone || "Sin teléfono"}</Text></Card>)}
 </View>;
}
