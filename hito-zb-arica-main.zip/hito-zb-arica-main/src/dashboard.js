import React, { useEffect, useState } from "react";
import { View, Text, Pressable, ActivityIndicator } from "react-native";
import { supabase } from "./lib";
import { C, Btn, Note } from "./ui";
import { areaInfo, AREA_COLORS } from "./catalog";

export const DASHBOARD_OWNER = "6c012c39-34a7-40d9-9154-d7ace10606da";
const card = { backgroundColor: C.surface, padding: 16, borderRadius: 16, gap: 10, borderWidth: 1, borderColor: C.line };
const pct = n => n == null ? "Sin casos" : `${Number(n).toFixed(1)} %`;
export function snapshotMetrics(snapshot,from,to,now=new Date()) {
 const tasks=snapshot.tasks.filter(t=>new Date(t.due)>=from&&new Date(t.due)<to);
 const matured=tasks.filter(t=>new Date(t.due)<=now);
 const onTime=t=>t.done&&t.done_at&&new Date(t.done_at)<=new Date(t.due)&&!t.late;
 const percent=(n,total)=>total?Math.round(1000*n/total)/10:null;
 const units={};const processes={};const areas={};
 tasks.forEach(t=>{
  const unit=snapshot.members.find(m=>m.id===t.member_id)?.unit||"Sin unidad";
  if(!units[unit])units[unit]={name:unit,total:0,completed:0,overdue:0,matured:0,on_time:0};
  const u=units[unit];u.total++;if(t.done)u.completed++;if(!t.done&&new Date(t.due)<now)u.overdue++;if(new Date(t.due)<=now){u.matured++;if(onTime(t))u.on_time++;}
  const process=t.proc||"Sin proceso";if(!processes[process])processes[process]={name:process,total:0,completed:0};processes[process].total++;if(t.done)processes[process].completed++;
  const area=areaInfo(t.area);const areaKey=t.area||"__sin_area";const areaName=area?area.name:"Sin área";
  if(!areas[areaKey])areas[areaKey]={key:areaKey,name:areaName,group:area?.group||null,total:0,completed:0,overdue:0,progress_sum:0};
  const ar=areas[areaKey];ar.total++;if(t.done)ar.completed++;if(!t.done&&new Date(t.due)<now)ar.overdue++;ar.progress_sum+=t.done?100:Math.max(0,Math.min(100,t.progress||0));
 });
 const soon=t=>!t.done&&new Date(t.due)>=now&&new Date(t.due)<new Date(now.getTime()+48*3600000);
 return {as_of:snapshot.as_of||now.toISOString(),metrics:{total:tasks.length,completed:tasks.filter(t=>t.done).length,overdue:tasks.filter(t=>!t.done&&new Date(t.due)<now).length,soon:tasks.filter(soon).length,matured:matured.length,on_time:matured.filter(onTime).length,compliance_pct:percent(matured.filter(onTime).length,matured.length),progress_pct:tasks.length?Math.round(10*tasks.reduce((n,t)=>n+(t.done?100:Math.max(0,Math.min(100,t.progress||0))),0)/tasks.length)/10:null},units:Object.values(units).map(u=>({...u,compliance_pct:percent(u.on_time,u.matured)})).sort((a,b)=>b.overdue-a.overdue),areas:Object.values(areas).map(a=>({...a,progress_pct:a.total?Math.round(10*a.progress_sum/a.total)/10:null})).sort((a,b)=>b.overdue-a.overdue||a.name.localeCompare(b.name,"es")),processes:Object.values(processes),alerts:tasks.filter(t=>!t.done&&new Date(t.due)<new Date(now.getTime()+48*3600000)).sort((a,b)=>new Date(a.due)-new Date(b.due)).slice(0,50).map(t=>({...t,responsible:snapshot.members.find(m=>m.id===t.member_id)?.name||"Sin asignar",reason:new Date(t.due)<now?"Vencida":"Vence en menos de 48 h"}))};
}
function Bar({ label, value, total, color = C.accent }) {
 return <View style={{ gap: 6 }}><Text style={{ color: C.ink }}>{label} · {value}/{total}</Text><View style={{ height: 9, backgroundColor: C.surface2, borderRadius: 5 }}><View style={{ height: 9, borderRadius: 5, backgroundColor: color, width: `${total ? Math.min(100,100*value/total) : 0}%` }} /></View></View>;
}
export function Dashboard({ session, revision, snapshot, reportProvider, open }) {
 const [period,setPeriod]=useState("month");
 const [attempt,setAttempt]=useState(0);
 const [state,setState]=useState({ loading:true,data:null,error:"" });
 const authorized=!!session?.user?.id || typeof reportProvider === "function";
 useEffect(()=>{
  if (!authorized) return;
  let active=true;
  const now=new Date();
  const from=period==="all" ? new Date("2000-01-01T00:00:00Z") : period==="year" ? new Date(now.getFullYear(),0,1) : new Date(now.getFullYear(),now.getMonth(),1);
  const to=period==="all" ? new Date("2100-01-01T00:00:00Z") : period==="year" ? new Date(now.getFullYear()+1,0,1) : new Date(now.getFullYear(),now.getMonth()+1,1);
  if(snapshot){setState({loading:false,data:snapshotMetrics(snapshot,from,to),error:""});return;}
  setState({ loading:true,data:null,error:"" });
  const request=reportProvider ? reportProvider(period).then(data=>({data,error:null})) : supabase.rpc("hito_dashboard_comandante",{p_from:from.toISOString(),p_to:to.toISOString()});
  request.then(({data,error})=>{
   if(active) setState({loading:false,data:error?null:data,error:error?"No se pudo cargar el dashboard. Reintenta; si persiste, verifica la instalación de la consulta privada.":""});
  }).catch(()=>{if(active)setState({loading:false,data:null,error:"No se pudo conectar. Revisa tu conexión y reintenta."});});
  return ()=>{active=false;};
 },[authorized,period,attempt,revision,snapshot,reportProvider]);
 if(!authorized)return null;
 const data=state.data,m=data?.metrics;
 return <View style={{gap:14}}>
  <View style={{...card,backgroundColor:C.inv}}><Text style={{color:C.invMuted,fontSize:12}}>CONTROL DE GESTIÓN · SOLO CONSULTA</Text><Text style={{color:C.invFg,fontSize:24,fontWeight:"800"}}>Panel de gestión</Text><Text style={{color:C.invMuted}}>Tareas agrupadas por su plazo vigente. Información disponible según tu acceso.</Text></View>
  <View style={{flexDirection:"row",flexWrap:"wrap",gap:8}}>{[["month","Este mes"],["year","Este año"],["all","Todo"]].map(([key,label])=><Btn key={key} title={label} small kind={key===period?"primary":"default"} onPress={()=>setPeriod(key)}/>)}</View>
  <Btn title="Actualizar" small disabled={state.loading} onPress={()=>setAttempt(x=>x+1)}/>
  {state.loading?<ActivityIndicator color={C.accent}/>:null}
  {state.error?<Note kind="bad" text={state.error}/>:null}
  {m?<>
   <View style={{flexDirection:"row",flexWrap:"wrap",gap:10}}>{[["Cumplimiento a tiempo",pct(m.compliance_pct),C.accent],["Tareas del período",m.total,C.ink],["Completadas",m.completed,C.accent],["Vencidas pendientes",m.overdue,C.red],["Por vencer en 48 h",m.soon,C.amberInk],["Avance promedio",pct(m.progress_pct),C.blue]].map(([label,value,color])=><View key={label} style={{...card,flexGrow:1,flexBasis:145}}><Text style={{color:C.muted,fontSize:13}}>{label}</Text><Text style={{color,fontSize:29,fontWeight:"800"}}>{value}</Text></View>)}</View>
   <Text style={{color:C.muted,fontSize:12}}>Cumplimiento: completadas a tiempo / tareas cuyo plazo ya venció. Se utiliza el plazo vigente, incluidas las prórrogas. Sin casos se muestra cuando no hay tareas evaluables.</Text>
   {!m.total?<Note kind="info" text="No hay tareas con plazo en este período."/>:null}
   <View style={card}><Text style={{color:C.ink,fontWeight:"800",fontSize:18}}>Resultados por unidad</Text>{data.units.map(u=><View key={u.name} style={{gap:6,marginBottom:10}}><Bar label={u.name} value={u.completed} total={u.total}/><Text style={{color:u.overdue?C.red:C.muted,fontSize:12}}>{u.overdue} vencidas · Cumplimiento: {pct(u.compliance_pct)}</Text></View>)}</View>
   {data.areas?.length?<View style={card}><Text style={{color:C.ink,fontWeight:"800",fontSize:18}}>Avance por área</Text>{data.areas.map(a=><View key={a.key} style={{gap:6,marginBottom:10}}><Bar label={a.name} value={a.completed} total={a.total} color={AREA_COLORS[a.group]||C.blue}/><Text style={{color:a.overdue?C.red:C.muted,fontSize:12}}>{a.overdue} vencidas · Avance promedio: {pct(a.progress_pct)}</Text></View>)}</View>:null}
   <View style={card}><Text style={{color:C.ink,fontWeight:"800",fontSize:18}}>Procesos · tareas completadas</Text>{data.processes.map(p=><Bar key={p.name} label={p.name} value={p.completed} total={p.total} color={C.blue}/>)}</View>
   <View style={card}><Text style={{color:C.ink,fontWeight:"800",fontSize:18}}>Alertas del período</Text><Text style={{color:C.muted,fontSize:12}}>{data.aggregated_only ? "Acceso a cifras agregadas. No incluye detalle de tareas ni datos personales." : "Hasta 50 tareas, comenzando por el plazo más antiguo."}</Text>{!data.alerts.length?<Text style={{color:C.accent}}>{data.aggregated_only ? "Revisa los contadores de vencimientos del panel." : "Sin alertas en este período."}</Text>:null}{data.alerts.map(a=><Pressable key={a.id} accessibilityRole="button" onPress={()=>open({kind:"task",id:a.id})} style={{paddingVertical:12,borderBottomWidth:1,borderColor:C.line,gap:4}}><Text style={{color:a.reason==="Vencida"?C.red:C.amberInk,fontWeight:"700"}}>{a.reason}</Text><Text style={{color:C.ink,fontWeight:"700"}}>{a.title}</Text><Text style={{color:C.muted,fontSize:12}}>{a.responsible} · {new Date(a.due).toLocaleString("es-CL")}</Text></Pressable>)}</View>
   <Text style={{color:C.muted,fontSize:12}}>Actualizado: {new Date(data.as_of).toLocaleString("es-CL")}</Text>
  </>:null}
 </View>;
}

