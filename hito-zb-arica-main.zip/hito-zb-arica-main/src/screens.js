import React, { useState, useMemo, useEffect } from "react";
import { nivelR } from "./control";
import { View, Text, TextInput, Pressable, Linking, Alert, ScrollView, KeyboardAvoidingView, Platform, Image, Share } from "react-native";
import { supabase, phoneDigits, waLink, fmt, fmtDay, fmtTime, startOfDay, addDays, weekStart, toInput, fromInput, due, status, onTime, grade, gfmt, initials, norm, errMsg, DAY } from "./lib";
import { SUPABASE_URL } from "./config";
import { Glosario } from "./glosario";
import { DescargarDescriptores } from "./descriptores";
import { Descargar, tablasDeTexto } from "./exportar";
import { Dictar } from "./voz";
import { notificarCorreo, msgTarea, msgEvento, msgDerivacion, firmaTexto } from "./correo";
import { TF, TFK, procInfo, stagesFor, MOTIVOS, EVTYPES, CATS, TF_COLORS, AREAS, AREA_GROUPS, AREA_COLORS, areaInfo, UNIT_AREA, areaColor } from "./catalog";
import { C, S, Btn, Chip, Chips, Card, Badge, TfTag, Field, Note, Sheet, Empty, Row, Between } from "./ui";
import { Procedimiento, flujo, verDiagrama, tieneDiagrama } from "./procedimiento";
import { PERFILES_CARGO } from "./perfiles";
import { CLASIFICADOR, esHoja, totalDe, EDITORES_CATALOGO } from "./clasificador";

const first = (m) => (m ? m.name.replace(/^\S+\s/, "").split(/\s+/)[0] : "");
const mname = (members, id) => (members.find((m) => m.id === id) || {}).name || "Sin asignar";
const member = (members, id) => members.find((m) => m.id === id);
const perfilCargo = (m, manuales = []) => {
  const value = norm((m && m.cargo || "") + " " + (m && m.unit || ""));
  const cargoKey = norm(m && m.cargo || "");
  const scopedKey = cargoKey.trim() + "::" + norm(m && m.unit || "").trim();
  const manual = manuales.find((p) => norm(p.cargo_key || "") === scopedKey) || manuales.find((p) => norm(p.cargo_key || "") === cargoKey);
  if (manual) return { ...manual, manual: true };
  return PERFILES_CARGO.find((p) => p.aliases.some((a) => value.includes(norm(a)))) || null;
};
const PERFIL_SECTION_LABELS = [
  "requisitos",
  "misión del cargo",
  "relaciones de dependencia y supervisión",
  "funciones y tareas principales",
  "competencias conductuales",
  "observaciones",
];
async function run(fn, ok) { const r = await fn(); if (r && r.error) { Alert.alert("No se pudo guardar", errMsg(r.error)); return false; } if (ok) Alert.alert(ok); return true; }
function openWa(phone, text) { if (!phone) { Alert.alert("Sin número", "Esta persona no tiene WhatsApp registrado."); return; } Linking.openURL(waLink(phone, text)).catch(() => Alert.alert("No se pudo abrir WhatsApp")); }

/* ================= Ingreso ================= */
export function Login() {
  const [mode, setMode] = useState("member");
  const [phone, setPhone] = useState(""); const [pin, setPin] = useState("");
  const [email, setEmail] = useState(""); const [pass, setPass] = useState("");
  const [busy, setBusy] = useState(false); const [msg, setMsg] = useState("");
  async function go(kind) {
    setMsg(""); setBusy(true);
    try {
      let r;
      if (mode === "member") {
        const d = phoneDigits(phone);
        if (d.length !== 11) throw { message: "Escribe tu número de celular, por ejemplo 9 1234 5678." };
        if (!/^\d{6,}$/.test(pin)) throw { message: "El PIN debe tener al menos 6 dígitos." };
        const creds = { email: d + "@hito.app", password: pin };
        r = kind === "signup" ? await supabase.auth.signUp(creds) : await supabase.auth.signInWithPassword(creds);
      } else {
        const em = email.trim().toLowerCase();
        if (!/^\S+@\S+\.\S+$/.test(em)) throw { message: "Escribe tu correo completo." };
        if (pass.length < 6) throw { message: "Escribe una contraseña de al menos 6 caracteres en el campo “Contraseña”." };
        const creds = { email: em, password: pass };
        r = kind === "signup" ? await supabase.auth.signUp(creds) : await supabase.auth.signInWithPassword(creds);
      }
      if (r.error) throw r.error;
      if (kind === "signup" && !r.data.session) setMsg("Acceso creado. Ahora toca “Ingresar”.");
    } catch (e) {
      let m = errMsg(e);
      if (/Database error saving new user/i.test(m)) m = mode === "member" ? "Ese número no está en el equipo de la Zona o ya tiene acceso. Habla con el Comandante." : "Ese correo no está autorizado como Comandante.";
      if (mode === "admin") m = m.replace("Número o PIN incorrecto.", "Correo o contraseña incorrectos. Si es tu primera vez, toca “Crear mi acceso”.").replace("Ese número ya tiene acceso.", "Ese correo ya tiene acceso.").replace("El PIN debe tener al menos 6 dígitos.", "La contraseña debe tener al menos 6 caracteres.");
      setMsg(m);
    }
    setBusy(false);
  }
  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
    <ScrollView keyboardShouldPersistTaps="handled" style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ padding: 20, paddingTop: 40, paddingBottom: 60, gap: 16 }}>
      <Image source={require("../assets/emblema.png")} style={{ width: 120, height: 120, alignSelf: "center" }} resizeMode="contain" accessibilityLabel="Emblema División de Bienestar" />
      <Text style={{ fontSize: 13, color: C.muted, letterSpacing: 1 }}>ZONA DE BIENESTAR “ARICA”</Text>
      <Text style={{ fontSize: 34, fontWeight: "800", color: C.ink }}>Hito</Text>
      <Text style={S.body}>Tareas, plazos y avisos del equipo.</Text>
      <Chips options={[["member", "Soy integrante"], ["admin", "Comandante"]]} value={mode} onChange={(k) => { setMode(k); setMsg(""); }} />
      {mode === "member" ? (
        <>
          <Field label="Tu número de celular" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="9 1234 5678" />
          <Field label="PIN (mínimo 6 dígitos)" value={pin} onChangeText={setPin} keyboardType="number-pad" secureTextEntry placeholder="••••••" />
          <Note kind="info" text="La primera vez toca “Crear mi acceso” con el número que tienes registrado en la Zona y elige tu PIN." />
        </>
      ) : (
        <>
          <Field label="Correo" value={email} onChangeText={setEmail} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" placeholder="correo@ejemplo.cl" />
          <Field label="Contraseña (mínimo 6 caracteres)" value={pass} onChangeText={setPass} secureTextEntry autoCapitalize="none" autoCorrect={false} importantForAutofill="no" placeholder="Elige o escribe tu contraseña" />
          <Note kind="info" text="La primera vez escribe tu correo y una contraseña nueva, y toca “Crear mi acceso”. Después usa “Ingresar”." />
        </>
      )}
      {msg ? <Note kind={/creado/.test(msg) ? "ok" : "bad"} text={msg} /> : null}
      <Btn title={busy ? "Un momento…" : "Ingresar"} kind="primary" disabled={busy} onPress={() => go("login")} />
      <Btn title="Crear mi acceso" disabled={busy} onPress={() => go("signup")} />
    </ScrollView>
    </KeyboardAvoidingView>
  );
}

/* ================= Delegar ================= */
function Delegar({ t, d, onDone }) {
  const [openD, setOpenD] = useState(false); const [q, setQ] = useState("");
  const me = d.me;
  const cands = d.members.filter((m) => m.activo !== false && m.nivel !== "X" && m.id !== t.member_id && (!q || norm(m.name + " " + m.cargo + " " + m.unit).includes(norm(q))))
    .sort((a, b) => ((a.unit === (member(d.members, t.member_id) || {}).unit) ? 0 : 1) - ((b.unit === (member(d.members, t.member_id) || {}).unit) ? 0 : 1)).slice(0, q ? 25 : 10);
  async function delegar(id) {
    const log = (t.log || []).concat([{ t: id ? "delegada a " + mname(d.members, id) + " por " + me.name : "delegación retirada por " + me.name, at: Date.now() }]);
    if (await run(() => supabase.from("tasks").update({ delegado: id, delegado_por: id ? me.id : null, log }).eq("id", t.id), id ? "Delegada a " + mname(d.members, id) : "Delegación retirada")) { setOpenD(false); setQ(""); if (onDone) onDone(); }
  }
  if (!openD) return (
    <>
      {t.delegado ? <Note kind="info" text={"Delegada a " + mname(d.members, t.delegado) + ". " + mname(d.members, t.member_id) + " sigue como responsable."} /> : null}
      <Row>
        <Btn title={t.delegado ? "Cambiar delegación" : "Delegar a otra persona"} style={{ flex: 1 }} onPress={() => setOpenD(true)} />
        {t.delegado ? <Btn title="Quitar" style={{ flex: 1 }} onPress={() => delegar(null)} /> : null}
      </Row>
    </>);
  return (
    <Card style={{ borderColor: "#B9A2E0" }}>
      <Text style={{ color: "#5B3A8E", fontWeight: "800" }}>Delegar el trabajo</Text>
      <Text style={S.small}>Ambos quedan como responsables: {mname(d.members, t.member_id)} sigue a cargo y la persona delegada lo ejecuta y ve la tarea en su teléfono.</Text>
      <TextInput value={q} onChangeText={setQ} placeholder="Buscar persona (aparecen primero los de su unidad)" placeholderTextColor="#8A968F" style={{ minHeight: 44, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 12 }} />
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{cands.map((m) => <Chip key={m.id} label={m.name} on={t.delegado === m.id} color="#5B3A8E" onPress={() => delegar(m.id)} />)}</View>
      <Btn title="Cancelar" onPress={() => setOpenD(false)} />
    </Card>);
}

/* ================= Derivar / delegar a uno o varios responsables ================= */
// La primera persona elegida queda como ejecutor (derivada); las demás quedan también como responsables (participantes).
// Comandante: se aplica directo. Resto de los usuarios: queda pendiente de aprobación del Comandante.
export async function asignarVarios(t, d, sel, dueTs) {
  const me = d.me;
  if (me.role !== "admin") {
    const { data, error } = await supabase.rpc("derivar_varios", { p_task: t.id, p_destinos: sel, p_due: dueTs ? new Date(dueTs).toISOString() : null });
    return { error, est: data };
  }
  const [deriv, ...resto] = sel;
  const part = Array.from(new Set((t.participantes || []).concat(resto))).filter((x) => x !== t.member_id && x !== deriv);
  const log = (t.log || []).concat([{ t: "derivada a " + mname(d.members, deriv) + (resto.length ? " y delegada también a " + resto.map((x) => mname(d.members, x)).join(", ") : "") + " por " + me.name, at: Date.now() }]);
  const upd = { delegado: deriv, delegado_por: me.id, participantes: part, log }; if (dueTs) upd.due = new Date(dueTs).toISOString();
  const r = await supabase.from("tasks").update(upd).eq("id", t.id);
  return { error: r.error, est: "derivada" };
}
export function ElegirVarios({ d, t, sel, setSel, hint }) {
  const [q, setQ] = useState("");
  const ownerUnit = (member(d.members, t.member_id) || {}).unit;
  const cands = d.members.filter((x) => x.activo !== false && x.nivel !== "X" && !/WhatsApp/i.test(x.unit || "") && x.id !== t.member_id && (!q || norm(x.name + " " + x.cargo + " " + x.unit).includes(norm(q))))
    .sort((a, b) => (sel.includes(a.id) ? 0 : 1) - (sel.includes(b.id) ? 0 : 1) || (a.unit === ownerUnit ? 0 : 1) - (b.unit === ownerUnit ? 0 : 1)).slice(0, q ? 25 : 12);
  const toggle = (id) => setSel(sel.includes(id) ? sel.filter((x) => x !== id) : sel.concat([id]));
  return (<>
    <TextInput value={q} onChangeText={setQ} placeholder={hint || "Buscar persona (primero los de su unidad)"} placeholderTextColor="#8A968F" style={{ minHeight: 44, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 12 }} />
    <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{cands.map((x) => <Chip key={x.id} label={(sel.indexOf(x.id) === 0 ? "① " : sel.includes(x.id) ? "＋ " : "") + x.name} on={sel.includes(x.id)} color="#5B3A8E" onPress={() => toggle(x.id)} />)}</View>
    {sel.length ? <Text style={S.small}>Ejecutor: <Text style={{ fontWeight: "800" }}>{mname(d.members, sel[0])}</Text>{sel.length > 1 ? " · También responsables: " + sel.slice(1).map((x) => mname(d.members, x)).join(", ") : ""}</Text> : <Text style={S.small}>Marca una o más personas. La primera queda como ejecutor.</Text>}
  </>);
}
function Derivar({ t, d, open }) {
  const [openD, setOpenD] = useState(false); const [sel, setSel] = useState([]); const [busy, setBusy] = useState(false);
  const me = d.me; const admin = me.role === "admin";
  async function quitar() {
    if (!admin) {
      const { data: est, error } = await supabase.rpc("derivar_tarea", { p_task: t.id, p_destino: null });
      if (error) return Alert.alert("No se pudo", errMsg(error));
      return Alert.alert("Derivación retirada");
    }
    const log = (t.log || []).concat([{ t: "derivación retirada por " + me.name, at: Date.now() }]);
    await run(() => supabase.from("tasks").update({ delegado: null, delegado_por: null, log }).eq("id", t.id), "Derivación retirada");
  }
  async function asignar() {
    if (!sel.length) return Alert.alert("Elige al menos una persona");
    setBusy(true); const { error, est } = await asignarVarios(t, d, sel); setBusy(false);
    if (error) return Alert.alert("No se pudo", errMsg(error));
    const nombres = sel.map((x) => mname(d.members, x)).join(", ");
    setOpenD(false); setSel([]);
    if (est === "derivada") { Alert.alert("Asignada a " + nombres); if (open) open({ kind: "notificar", msg: msgDerivacion(d, t, sel[0]) }); }
    else Alert.alert("Enviada al Comandante", "La derivación a " + nombres + " queda pendiente de su aprobación. Te avisará la app cuando la resuelva.");
  }
  if (!openD) return (
    <Row>
      <Btn title={t.delegado ? "↪ Cambiar / agregar responsables" : "↪ Derivar / delegar"} style={{ flex: 1 }} onPress={() => { setSel(t.delegado ? [t.delegado].concat((t.participantes || []).filter((x) => x !== t.delegado)) : []); setOpenD(true); }} />
      {t.delegado ? <Btn title="Quitar" style={{ flex: 1 }} onPress={quitar} /> : null}
      {t.delegado && open ? <Btn title="Notificar" style={{ flex: 1 }} onPress={() => open({ kind: "notificar", msg: msgDerivacion(d, t, t.delegado) })} /> : null}
    </Row>);
  return (
    <Card style={{ borderColor: "#B9A2E0" }}>
      <Text style={{ color: "#5B3A8E", fontWeight: "800" }}>Derivar / delegar</Text>
      <Text style={S.small}>{mname(d.members, t.member_id)} sigue a cargo; quienes elijas quedan como responsables y la ven en Mis tareas.{admin ? "" : " Queda pendiente de aprobación del Comandante."}</Text>
      <ElegirVarios d={d} t={t} sel={sel} setSel={setSel} />
      <Row><Btn title="Cancelar" style={{ flex: 1 }} onPress={() => { setOpenD(false); setSel([]); }} /><Btn title={busy ? "Guardando…" : (admin ? "Asignar" : "Pedir aprobación") + (sel.length ? " (" + sel.length + ")" : "")} kind="primary" disabled={busy} style={{ flex: 1 }} onPress={asignar} /></Row>
    </Card>);
}

/* ================= Tarjetas ================= */
function GrupoCard({ t, d, onPress }) {
  const g = d.tasks.filter((x) => x.grupo === t.grupo); const ok = g.filter((x) => x.done).length;
  const ac = areaColor(t);
  return (
    <Card onPress={onPress} style={ac ? { borderLeftWidth: 6, borderLeftColor: ac } : null}>
      <Between><Badge kind={ok === g.length ? "done" : status(t) === "over" ? "over" : "ok"} text={"PARA " + g.length + " PERSONAS"} /><Text style={S.small}>{fmt(due(t))}</Text></Between>
      <Text style={S.title}>{t.title}</Text>
      <View style={{ height: 6, borderRadius: 3, backgroundColor: C.surface2 }}><View style={{ width: (g.length ? 100 * ok / g.length : 0) + "%", height: 6, borderRadius: 3, backgroundColor: C.accent }} /></View>
      <Text style={S.small}>Cumplieron {ok} de {g.length}{t.grupo_label ? " · " + t.grupo_label : ""}</Text>
    </Card>);
}
export function TaskCard({ t, members, onPress, onEdit }) {
  const st = status(t); const m = member(members, t.member_id);
  const p = t.done ? 100 : t.progress || 0;
  const badge = st === "over" ? <Badge kind="over" text={"😟 VENCIDA · " + Math.max(1, Math.ceil((Date.now() - due(t)) / DAY)) + " d"} />
    : st === "soon" ? <Badge kind="soon" text={"😐 " + (startOfDay(due(t)) === startOfDay(Date.now()) ? "HOY · " + fmtTime(due(t)) : "PRÓXIMA · " + Math.ceil((due(t) - Date.now()) / DAY) + " d")} />
    : st === "done" ? <Badge kind="done" text={onTime(t) ? "CUMPLIDA A TIEMPO" : "CUMPLIDA CON ATRASO"} />
    : <Badge kind="ok" text={"😊 EN PLAZO · " + Math.ceil((due(t) - Date.now()) / DAY) + " d"} />;
  const col = st === "over" ? C.red : st === "soon" ? C.amber : st === "done" ? C.muted : C.accent;
  const ac = areaColor(t);
  return (
    <Card onPress={onPress} style={ac ? { borderLeftWidth: 6, borderLeftColor: ac } : null}>
      <Between>{badge}<Text style={S.small}>{fmt(due(t))}</Text></Between>
      <Text style={S.title}>{t.title}</Text>
      {areaInfo(t.area) ? <Text style={{ fontSize: 12, fontWeight: "700", color: areaInfo(t.area).color }}>{areaInfo(t.area).name.toUpperCase()}</Text> : null}
      <TfTag tf={t.tf} proc={t.proc} />
      <View style={{ height: 6, borderRadius: 3, backgroundColor: C.surface2 }}><View style={{ width: p + "%", height: 6, borderRadius: 3, backgroundColor: col }} /></View>
      {t.delegado ? <View style={{ alignSelf: "flex-start", backgroundColor: "#EFE7FB", borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 }}><Text style={{ color: "#5B3A8E", fontSize: 11, fontWeight: "800" }}>DELEGADA A {String((member(members, t.delegado) || {}).name || "").toUpperCase()}</Text></View> : null}
      {t.delegado ? <View style={{ alignSelf: "flex-start", backgroundColor: "#EFE7FB", borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 }}><Text style={{ color: "#5B3A8E", fontSize: 11, fontWeight: "800" }}>DERIVADA A {String((member(members, t.delegado) || {}).name || "").toUpperCase()}</Text></View> : null}
      <Text style={S.small}>{(m ? m.name : "Sin asignar") + (t.apoyo ? " + " + ((member(members, t.apoyo) || {}).name || "") : "") + " · " + p + "%"}{t.created_by && t.created_by !== "m-cerda" ? " · creada por el integrante" : ""}{t.no_shows ? " · no se presentó (" + t.no_shows + ")" : ""}</Text>
      {onEdit ? <Row><Btn small title="✏️ Corregir texto" onPress={onEdit} /></Row> : null}
    </Card>
  );
}

// Puede corregir el texto de una tarea quien la creó (y el Comandante); el resto no.
export function esCreador(t, d) { const me = d && d.me; return !!(me && t && (me.role === "admin" || (t.created_by && t.created_by === me.id))); }
export function CorregirTarea({ t, d, onClose }) {
  const [title, setTitle] = useState(t.title || "");
  const [evid, setEvid] = useState(t.evidencia || "");
  const [busy, setBusy] = useState(false);
  async function save() {
    if (!title.trim()) return Alert.alert("Escribe el texto de la tarea.");
    setBusy(true);
    const ok = await run(() => supabase.from("tasks").update({ title: title.trim(), evidencia: evid.trim() }).eq("id", t.id), "Tarea corregida");
    setBusy(false); if (ok) onClose();
  }
  return (
    <Sheet visible title="Corregir texto de la tarea" onClose={onClose}>
      <Note kind="info" text="Solo quien creó la tarea puede corregir su texto. El plazo y el responsable no cambian." />
      <Field label="Tarea" value={title} onChangeText={setTitle} multiline />
      <Dictar label="Dictar" onText={(x) => setTitle((v) => (v ? v.trim() + " " : "") + x)} />
      <Field label="Producto / evidencia (opcional)" value={evid} onChangeText={setEvid} multiline />
      <Btn title={busy ? "Guardando…" : "Guardar corrección"} kind="primary" disabled={busy} onPress={save} />
    </Sheet>
  );
}

/* ================= Detalle de tarea ================= */
export function TaskDetail({ t, d, isAdmin, onClose, open }) {
  const m = member(d.members, t.member_id); const st = status(t);
  const meId = d.me && d.me.id;
  const puedeActuar = isAdmin || t.member_id === meId || t.apoyo === meId || t.delegado === meId;
  const pend = d.prorrogas.find((p) => p.task_id === t.id && p.status === "pendiente");
  const stages = t.stages || [];
  async function toggleStage(i) {
    const s2 = stages.map((s, j) => ({ n: s.n, done: j === i ? !s.done : !!s.done }));
    const pr = Math.round(100 * s2.filter((s) => s.done).length / s2.length);
    await run(() => supabase.from("tasks").update({ stages: s2, progress: pr }).eq("id", t.id));
  }
  async function setProgress(p) { await run(() => supabase.from("tasks").update({ progress: p }).eq("id", t.id)); }
  async function setDone(v) {
    const log = (t.log || []).concat([{ t: v ? "cumplida" : "reabierta", at: Date.now() }]);
    if (await run(() => supabase.from("tasks").update({ done: v, done_at: v ? new Date().toISOString() : null, progress: v ? 100 : t.progress, log }).eq("id", t.id), v ? "Tarea cumplida" : "Tarea reabierta")) onClose();
  }
  async function ack() { await run(() => supabase.from("tasks").update({ overdue_ack_at: new Date().toISOString() }).eq("id", t.id), "Recibido. El Comandante verá que leíste el aviso."); }
  async function del() {
    Alert.alert("Eliminar tarea", "No se puede deshacer y sale de las notas.", [{ text: "Cancelar" },
      { text: "Eliminar", style: "destructive", onPress: async () => { if (await run(() => supabase.from("tasks").delete().eq("id", t.id), "Tarea eliminada")) onClose(); } }]);
  }
  async function toReplacement() {
    const r = member(d.members, m.reemplazo_id);
    const log = (t.log || []).concat([{ t: "reasignada", at: Date.now(), from: m.id, to: r.id }]);
    if (await run(() => supabase.from("tasks").update({ member_id: r.id, log }).eq("id", t.id), "Asignada a " + r.name)) onClose();
  }
  const waText = st === "over"
    ? "Hito · Tarea vencida\n" + first(m) + ", “" + t.title + "” venció el " + fmt(due(t)) + ". Debes presentarte en la oficina del Comandante para explicar por qué no se cumplió."
    : "Hito · Recordatorio\n" + first(m) + ", tu tarea “" + t.title + "” vence el " + fmt(due(t)) + ". Avance: " + (t.progress || 0) + "%.";
  const pi = procInfo(t.proc, d.config.owners);
  return (
    <Sheet visible title={t.title} onClose={onClose}>
      <Row><TfTag tf={t.tf} proc={t.proc} /><Text style={S.small}>{pi ? pi.name : TF[t.tf].name}</Text></Row>
      <Card>
        <Between><Text style={S.small}>{t.apoyo ? "Responsable principal" : "Responsable"}</Text><Text style={[S.title, { flexShrink: 1, textAlign: "right" }]}>{m ? m.name : "Sin asignar"}</Text></Between>
        {t.delegado ? <Between><Text style={{ fontSize: 13, color: "#5B3A8E", fontWeight: "700" }}>Delegada a</Text><Text style={[S.title, { flexShrink: 1, textAlign: "right", color: "#5B3A8E" }]}>{mname(d.members, t.delegado)}</Text></Between> : null}
        {t.delegado ? <Between><Text style={{ fontSize: 13, color: "#5B3A8E", fontWeight: "700" }}>Derivada a</Text><Text style={[S.title, { flexShrink: 1, textAlign: "right", color: "#5B3A8E" }]}>{mname(d.members, t.delegado)}</Text></Between> : null}
        {(t.participantes || []).length ? <Between><Text style={S.small}>Participantes</Text><Text style={[S.title, { flexShrink: 1, textAlign: "right" }]}>{t.participantes.map((x) => mname(d.members, x)).join(", ")}</Text></Between> : null}
        {t.apoyo ? <Between><Text style={S.small}>Responsable secundario</Text><Text style={[S.title, { flexShrink: 1, textAlign: "right" }]}>{mname(d.members, t.apoyo)}</Text></Between> : null}
        <Between><Text style={S.small}>Plazo</Text><Text style={S.title}>{fmt(due(t))}</Text></Between>
        <Between><Text style={S.small}>Estado</Text><Text style={S.title}>{{ over: "Vencida", soon: "Próxima a vencer", ok: "En plazo", done: onTime(t) ? "Cumplida a tiempo" : "Cumplida con atraso" }[st]}</Text></Between>
        {t.dirige ? <Between><Text style={S.small}>Dirige</Text><Text style={[S.title, { flexShrink: 1, textAlign: "right" }]}>{mname(d.members, t.dirige)}</Text></Between> : null}
        {t.controla ? <Between><Text style={S.small}>Controla</Text><Text style={[S.title, { flexShrink: 1, textAlign: "right" }]}>{mname(d.members, t.controla)}</Text></Between> : null}
        {t.evidencia ? <Between><Text style={S.small}>Evidencia</Text><Text style={[S.title, { flexShrink: 1, textAlign: "right" }]}>{t.evidencia}</Text></Between> : null}
      </Card>
      {t.escalar ? <Note kind="bad" text="Marcada para escalamiento." /> : null}
      {!t.done && d.me && (isAdmin || t.member_id === d.me.id || t.delegado === d.me.id || t.apoyo === d.me.id) ? <Derivar t={t} d={d} open={open} /> : null}
      {!t.done && d.me && (isAdmin || t.member_id === d.me.id) ? <Delegar t={t} d={d} /> : null}
      {isAdmin && t.grupo ? (() => { const g = d.tasks.filter((x) => x.grupo === t.grupo).sort((a, b) => (a.done - b.done) || mname(d.members, a.member_id).localeCompare(mname(d.members, b.member_id))); return (
        <Card>
          <Text style={S.label}>Asignada a {g.length} personas{t.grupo_label ? " (" + t.grupo_label + ")" : ""} · cumplieron {g.filter((x) => x.done).length}</Text>
          {g.map((x) => <Pressable key={x.id} onPress={() => open({ kind: "task", id: x.id })}><Text style={{ color: x.done ? C.accent : status(x) === "over" ? C.red : C.ink, paddingVertical: 3 }}>{x.done ? "✓ " : "○ "}{mname(d.members, x.member_id)}</Text></Pressable>)}
        </Card>); })() : null}
      {isAdmin && !t.done ? <Btn title={t.escalar ? "Quitar escalamiento" : "Marcar para escalamiento"} onPress={() => run(() => supabase.from("tasks").update({ escalar: !t.escalar }).eq("id", t.id))} /> : null}
      {st === "over" && !isAdmin ? (
        <Card tone="inv">
          <Text style={{ color: C.invHi, fontWeight: "800", fontSize: 12 }}>TAREA VENCIDA</Text>
          <Text style={{ color: C.invFg, fontSize: 15, lineHeight: 21 }}>Ya no se puede pedir prórroga. Debes presentarte en la oficina del Comandante para explicar por qué se venció y por qué no se cumplió. Él definirá el nuevo plazo.</Text>
          {t.overdue_ack_at ? <Text style={{ color: C.invMuted }}>Aviso leído el {fmt(new Date(t.overdue_ack_at).getTime())}.</Text> : <Btn title="Entendido, iré a la oficina" onPress={ack} />}
        </Card>
      ) : null}
      {!puedeActuar ? <Note kind="info" text="Modo consulta: puedes ver esta tarea, pero solo su responsable o el Comandante pueden modificarla." /> : null}
      {!puedeActuar ? null : flujo(t.proc) ? <Procedimiento t={t} d={d} open={open} canEdit={!t.done} canDerive={!!d.me && (isAdmin || t.member_id === d.me.id)} /> : !t.done && stages.length ? (
        <Card>
          <Text style={S.label}>Etapas del procedimiento · {t.progress || 0}%</Text>
          {stages.map((s, i) => <Chip key={i} label={(s.done ? "✓ " : "○ ") + (i + 1) + ". " + s.n} on={!!s.done} color={C.accent} onPress={() => toggleStage(i)} />)}
        </Card>
      ) : !t.done ? (
        <Card><Text style={S.label}>Avance · {t.progress || 0}%</Text><Chips options={[0, 25, 50, 75].map((x) => [x, x + "%"])} value={t.progress || 0} onChange={setProgress} /></Card>
      ) : null}
      {!puedeActuar ? null : t.done ? <Btn title="Reabrir" onPress={() => setDone(false)} /> : <Btn title="Marcar como cumplida" kind="primary" onPress={() => setDone(true)} />}
      {puedeActuar && !t.done && !isAdmin && st !== "over" ? (pend ? <Note kind="warn" text={"Prórroga pedida para el " + fmt(new Date(pend.requested_due).getTime()) + ". Esperando respuesta del Comandante."} /> : <Btn title="Pedir prórroga" onPress={() => open({ kind: "pedirProrroga", t })} />) : null}
      {!isAdmin && t.created_by && d.me && t.created_by === d.me.id ? (
        <Row><Btn title="Editar" style={{ flex: 1 }} onPress={() => open({ kind: "taskForm", t })} /><Btn title="Eliminar" kind="danger" style={{ flex: 1 }} onPress={del} /></Row>
      ) : null}
      {isAdmin && !t.done ? (
        <>
          {st === "over" ? <Btn title="Resolver vencida (¿se presentó?)" kind="dark" onPress={() => open({ kind: "resolver", t })} /> : null}
          {pend ? <Btn title="Revisar solicitud de prórroga" kind="dark" onPress={() => open({ kind: "decidir", p: pend, t })} /> : null}
          {m && m.reemplazo_id && member(d.members, m.reemplazo_id) ? <Btn title={"Pasar a su reemplazo: " + member(d.members, m.reemplazo_id).name} onPress={toReplacement} /> : null}
          <Btn title="Notificar por WhatsApp y correo" kind="primary" onPress={() => open({ kind: "notificar", msg: msgTarea(d, t) })} />
          <Text style={S.label}>{st === "over" ? "Citación por WhatsApp" : "Recordatorio por WhatsApp"}</Text>
          <Card tone="warn"><Text style={S.body}>{waText}</Text></Card>
          <Btn title="Enviar por WhatsApp" kind="primary" onPress={() => openWa(m && m.phone, waText)} />
          <Row><Btn title="Editar" style={{ flex: 1 }} onPress={() => open({ kind: "taskForm", t })} /><Btn title="Eliminar" kind="danger" style={{ flex: 1 }} onPress={del} /></Row>
        </>
      ) : null}
      {(t.log || []).length ? (
        <Card>
          <Text style={S.label}>Historial</Text>
          {(t.log || []).slice().reverse().map((x, i) => (
            <Between key={i}><Text style={[S.small, { flex: 1 }]}>{{ creada: "Creada", cumplida: "Marcada como cumplida", reabierta: "Reabierta", reasignada: "Reasignada a " + mname(d.members, x.to), prorroga: "Prórroga " + x.decision + (x.to ? ": " + fmt(x.to) : ""), citacion: x.came ? "Se presentó. Nuevo plazo " + fmt(x.to) : "No se presentó a la citación" }[x.t] || x.t}</Text><Text style={S.small}>{fmtDay(x.at)}</Text></Between>
          ))}
        </Card>
      ) : null}
    </Sheet>
  );
}

/* ================= Formulario de tarea (Comandante) ================= */
// Envío de trabajos entre integrantes: misma organización directo; otra organización pasa por Jefe Adm. y Cdte.
export const MSG_SOL = {
  creada: "La tarea quedó publicada para la persona.",
  pend_ja: "Es de otra organización: primero la aprueba el Jefe Administrativo y después el Comandante. Recién ahí le llega a la persona.",
  pend_cdte: "Es de otra organización: la aprueba el Comandante y recién ahí le llega a la persona.",
  pend_destino: "Le llegó como solicitud: puede aceptarla, modificarla, derivarla o rechazarla.",
  derivada: "Derivación hecha.",
};
const orgDe = (d, id) => { const m = member(d.members, id) || {}; return UNIT_AREA[m.parte_unit || m.unit] || null; };
export const mismaOrg = (d, a, b) => !!orgDe(d, a) && orgDe(d, a) === orgDe(d, b);
function avisoEnvio(d, who) {
  if (!who || who === d.me.id) return "La tarea queda a tu nombre.";
  if (["m-passalacqua", "m-cerda"].includes(who)) return mname(d.members, who) + " la recibirá como solicitud y podrá aceptarla, modificarla, derivarla o rechazarla.";
  if (mismaOrg(d, d.me.id, who)) return "Es de tu organización: le llega directo.";
  return d.me.id === "m-passalacqua" ? "Es de otra organización: la aprueba el Comandante antes de publicarse." : "Es de otra organización: antes de publicarse la aprueba el Jefe Administrativo y después el Comandante.";
}

/* ===== Días inhábiles: fin de semana y feriados de Chile (editable; se suman los de d.config.feriados "AAAA-MM-DD") ===== */
const FERIADOS = {
  "2026-10-31": "Día de las Iglesias Evangélicas", "2026-11-01": "Día de Todos los Santos", "2026-12-08": "Inmaculada Concepción", "2026-12-25": "Navidad",
  "2027-01-01": "Año Nuevo", "2027-03-26": "Viernes Santo", "2027-03-27": "Sábado Santo", "2027-05-21": "Glorias Navales", "2027-07-16": "Virgen del Carmen",
  "2027-12-08": "Inmaculada Concepción", "2027-12-25": "Navidad",
};
const isoDia = (ms) => { const x = new Date(ms); return x.getFullYear() + "-" + String(x.getMonth() + 1).padStart(2, "0") + "-" + String(x.getDate()).padStart(2, "0"); };
export function inhabil(ms, cfg) {
  const x = new Date(ms); const k = isoDia(ms); const extra = (cfg && cfg.feriados) || [];
  if (FERIADOS[k]) return "feriado (" + FERIADOS[k] + ")";
  if (extra.includes(k)) return "feriado";
  if (x.getDay() === 6) return "sábado"; if (x.getDay() === 0) return "domingo";
  return null;
}
export function siguienteHabil(ms, cfg) { let t = ms; for (let i = 0; i < 10 && inhabil(t, cfg); i++) t = addDays(t, 1); return t; }
function PlazoInhabil({ dueS, setDueS, cfg, ok, setOk }) {
  const dd = fromInput(dueS); const m = dd ? inhabil(dd, cfg) : null;
  if (!m || ok) return null;
  const sug = siguienteHabil(dd, cfg);
  return (
    <Card tone="warn" style={{ gap: 6 }}>
      <Text style={{ color: C.amberInk, fontWeight: "800" }}>📅 El plazo cae en {m}: {fmtDay(dd)}</Text>
      <Text style={S.small}>Nadie trabaja ese día; conviene pasarlo al siguiente día hábil: <Text style={{ fontWeight: "800" }}>{fmtDay(sug)}</Text>.</Text>
      <Row><Btn small kind="primary" title={"Pasar al " + fmtDay(sug)} onPress={() => setDueS(toInput(sug))} />{setOk ? <Btn small title="Dejar así" onPress={() => setOk(true)} /> : null}</Row>
    </Card>);
}

/* ===== Detector de tareas repetidas: compara palabras clave (sin tildes, sin palabras vacías, por raíz de 5 letras) ===== */
const VACIAS = new Set("para con por sin las los del que una uno unos unas este esta estos estas como cada entre sobre desde hasta segun ante bajo tras ser sus nos les mas muy ya hay asi otro otra otros otras todo toda todos todas favor realizar hacer ver efectuar".split(" "));
export function claves(txt) {
  return Array.from(new Set(norm(txt).replace(/[^a-z0-9ñ ]/g, " ").split(/\s+/).filter((w) => w.length >= 3 && !VACIAS.has(w)).map((w) => /^\d+$/.test(w) ? w : w.slice(0, 5))));
}
export function similares(d, txt, excluir) {
  const q = claves(txt); if (q.length < 2) return [];
  const desde = Date.now() - 90 * DAY;
  return d.tasks.filter((x) => x.id !== excluir && (!x.done || new Date(x.done_at || x.due || 0).getTime() >= desde))
    .map((x) => { const k = claves(x.title); const comunes = q.filter((w) => k.includes(w)).length; return { x, comunes, score: comunes / Math.min(q.length, Math.max(k.length, 1)) }; })
    .filter((r) => r.comunes >= 2 && r.score >= 0.4)
    .sort((a, b) => b.score - a.score || (a.x.done ? 1 : 0) - (b.x.done ? 1 : 0)).slice(0, 5);
}
function Parecidas({ d, lista, onAbrir, onBase }) {
  if (!lista.length) return null;
  return (
    <Card tone="warn" style={{ gap: 6 }}>
      <Text style={{ color: C.amberInk, fontWeight: "800", fontSize: 12 }}>⚠️ PARECIDAS A ESTA · revisa que no esté asignada</Text>
      {lista.map(({ x, score }) => {
        const st = status(x);
        const cara = x.done ? "✓" : st === "over" ? "😟" : st === "soon" ? "😐" : "😊";
        return (
          <View key={x.id} style={{ borderTopWidth: 1, borderTopColor: "#F2D58A", paddingTop: 6 }}>
            <Text style={{ fontWeight: "700", color: C.ink }}>{cara} {x.title}</Text>
            <Text style={S.small}>{mname(d.members, x.member_id)}{x.delegado ? " → " + mname(d.members, x.delegado) : ""} · {x.done ? "cumplida " + fmtDay(new Date(x.done_at || x.due).getTime()) : "plazo " + fmtDay(due(x))} · {Math.round(score * 100)}% parecida</Text>
            <Row><Btn small title="Abrir" onPress={() => onAbrir(x)} /><Btn small title="Usar como base" onPress={() => onBase(x)} /></Row>
          </View>);
      })}
    </Card>);
}

export function TaskForm({ t, d, onClose }) {
  const [title, setTitle] = useState(t ? t.title : "");
  const isAdmin = !!(d.me && d.me.role === "admin");
  const myArea = d.me ? UNIT_AREA[d.me.unit] || "" : "";
  const [area, setArea] = useState(t ? t.area || "" : (isAdmin ? "" : myArea));
  const initP = !t && area && areaInfo(area) ? procInfo(areaInfo(area).proc) : null;
  const [tf, setTf] = useState(t ? t.tf : (initP ? initP.tf : "TF6"));
  const [proc, setProc] = useState(t ? t.proc : (initP ? initP.code : "ADM-LOG"));
  const [who, setWho] = useState(t ? t.member_id : (d.me && d.me.role !== "admin" ? d.me.id : (procInfo("ADM-LOG", d.config.owners) || {}).owner));
  const [touched, setTouched] = useState(!!t);
  const [dueS, setDueS] = useState(toInput(t ? due(t) : addDays(startOfDay(Date.now()), 3) + 12 * 3600000));
  const [q, setQ] = useState(""); const [err, setErr] = useState("");
  const [evid, setEvid] = useState(t ? t.evidencia || "" : "");
  const [modo, setModo] = useState("persona");
  const [apoyo, setApoyo] = useState(t ? t.apoyo || null : null);
  const [q2, setQ2] = useState("");
  const [gArea, setGArea] = useState(null);
  const [ctl, setCtl] = useState(t ? t.controla || "" : "m-cerda");
  const [pub, setPub] = useState(t ? !!t.publico : false);
  const [dir, setDir] = useState(t ? t.dirige || null : null);
  const [part, setPart] = useState(t ? t.participantes || [] : []);
  const [dupOk, setDupOk] = useState(false); const [dupAviso, setDupAviso] = useState(null); const [habilOk, setHabilOk] = useState(false);
  const parecidas = useMemo(() => t ? [] : similares(d, title, null), [title, d.tasks, t]);
  const usarBase = (x) => { setTitle(x.title); if (x.area) setArea(x.area); if (x.tf) setTf(x.tf); if (x.proc) setProc(x.proc); if (x.evidencia) setEvid(x.evidencia); setDupOk(true); setDupAviso(null); };
  const pi = procInfo(proc, d.config.owners);
  function pickProc(code) { setProc(code); const p = procInfo(code, d.config.owners); if (!touched && isAdmin && p && p.owner) setWho(p.owner); }
  const cands = d.members.filter((m) => m.activo !== false && (!q || norm(m.name + " " + m.cargo + " " + m.unit).includes(norm(q)))).slice(0, q ? 30 : 12);
  async function save(force) {
    const dd = fromInput(dueS);
    if (!title.trim()) return setErr("Escribe un título.");
    if (!dd) return setErr("Escribe el plazo como dd-mm-aaaa hh:mm.");
    if (!habilOk && inhabil(dd, d.config) && (!t || Math.abs(dd - due(t)) > 60000)) return setErr("El plazo cae en " + inhabil(dd, d.config) + ". Pásalo al día hábil siguiente o toca “Dejar así”.");
    if (!t && !dupOk && force !== true) { const fuerte = parecidas.find((r) => !r.x.done && r.score >= 0.6); if (fuerte) return setDupAviso(fuerte.x); }
    const body = { title: title.trim(), area: area || null, tf, proc, member_id: (isAdmin || !t ? who : d.me.id) || null, due: new Date(dd).toISOString() };
    if (!t && !isAdmin) body.created_by = d.me.id;
    body.evidencia = evid.trim(); body.participantes = part.filter((x) => x !== body.member_id); if (isAdmin) { body.publico = pub; body.dirige = dir || null; body.controla = ctl || null; body.apoyo = modo === "persona" && apoyo && apoyo !== body.member_id ? apoyo : null; }
    if (!t || t.proc !== proc) body.stages = stagesFor(proc);
    if (!t && isAdmin && modo !== "persona") {
      const hoy = new Date().toISOString().slice(0, 10);
      const people = d.members.filter((m) => inParte(m, hoy) && (modo === "todos" || UNIT_AREA[m.parte_unit || m.unit] === gArea));
      if (modo === "area" && !gArea) return setErr("Elige el área.");
      if (!people.length) return setErr("No hay personas en esa selección.");
      const grupo = "g" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      const label = modo === "todos" ? "Todos" : (areaInfo(gArea) || {}).name;
      const rows = people.map((m) => ({ ...body, member_id: m.id, grupo, grupo_label: label, log: [{ t: "creada", at: Date.now() }] }));
      return Alert.alert("Asignar a " + people.length + " personas", "Se creará una tarea para cada una (" + label + "). ¿Continuar?", [
        { text: "Cancelar", style: "cancel" },
        { text: "Crear", onPress: async () => { if (await run(() => supabase.from("tasks").insert(rows), people.length + " tareas creadas")) onClose(); } }]);
    }
    if (!t && !isAdmin && body.member_id && body.member_id !== d.me.id) {
      const datos = { title: body.title, area: body.area || "", tf: body.tf, proc: body.proc, due: body.due, stages: body.stages || [], evidencia: body.evidencia, participantes: body.participantes };
      const { data: est, error } = await supabase.rpc("crear_tarea_para", { p_datos: datos, p_destino: body.member_id });
      if (error) return setErr(errMsg(error));
      Alert.alert(est === "creada" ? "Tarea enviada" : "Enviada para aprobación", MSG_SOL[est] || "Listo.");
      return onClose();
    }
    const ok = t ? await run(() => supabase.from("tasks").update(body).eq("id", t.id), "Tarea actualizada")
      : await run(() => supabase.from("tasks").insert({ ...body, log: [{ t: "creada", at: Date.now() }] }), "Tarea creada");
    if (ok) { if (part.length || body.member_id !== (d.me && d.me.id)) onClose({ kind: "notificar", msg: msgTarea(d, { ...(t || {}), ...body }) }); else onClose(); }
  }
  return (
    <Sheet visible title={t ? "Editar tarea" : "Nueva tarea"} onClose={onClose}>
      <Field label="Título" value={title} onChangeText={setTitle} placeholder="Ej.: Informe de inventario trimestral" />
      <Dictar label="Dictar título" onText={(t) => setTitle((x) => (x ? x + " " : "") + t)} />
      {!t ? <Parecidas d={d} lista={parecidas} onAbrir={(x) => onClose({ kind: "task", id: x.id })} onBase={usarBase} /> : null}
      <Text style={S.label}>Área</Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{AREAS.map((a) => <Chip key={a[0]} label={a[1]} on={area === a[0]} color={AREA_COLORS[a[2]]} onPress={() => { setArea(a[0]); const p = procInfo(a[4], d.config.owners); if (p) { setTf(p.tf); setProc(p.code); } if (!touched && isAdmin) setWho(a[3]); }} />)}</View>
      <Text style={S.label}>Tarea fundamental (TF)</Text>
      <Chips options={TFK.map((k) => [k, k + " " + TF[k].short])} value={tf} colors={TF_COLORS} onChange={(k) => { setTf(k); pickProc(TF[k].procs[0][0]); }} />
      <Text style={S.label}>Proceso</Text>
      <Chips options={TF[tf].procs.map((p) => [p[0], p[0].includes("-") ? p[0] + " · " + p[1] : p[1]])} value={proc} onChange={pickProc} />
      {pi && pi.stages.length ? <Note text={"Etapas: " + pi.stages.join(" → ")} /> : null}
      {isAdmin && !t ? <><Text style={S.label}>Asignar a</Text><Chips options={[["persona", "Una persona"], ["area", "Un área completa"], ["todos", "Todos"]]} value={modo} onChange={setModo} /></> : null}
      {isAdmin && !t && modo === "area" ? <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{AREAS.map((a) => <Chip key={a[0]} label={a[1]} on={gArea === a[0]} color={AREA_COLORS[a[2]]} onPress={() => setGArea(a[0])} />)}</View> : null}
      {isAdmin && !t && modo === "todos" ? <Note text="Se crea una tarea para cada persona del parte de fuerza; en el detalle verás quién cumplió." /> : null}
      {isAdmin && (t || modo === "persona") ? <>
      <Text style={S.label}>Responsable: {mname(d.members, who)}</Text>
      <TextInput value={q} onChangeText={setQ} placeholder="Buscar persona por nombre, cargo o unidad" placeholderTextColor="#8A968F" style={{ minHeight: 44, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 12 }} />
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{cands.map((m) => <Chip key={m.id} label={m.name} on={m.id === who} onPress={() => { setWho(m.id); setTouched(true); }} />)}</View>
      <Text style={S.label}>Responsable secundario (opcional): {apoyo ? mname(d.members, apoyo) : "—"}</Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
        {(() => { const r = (member(d.members, who) || {}).reemplazo_id; return r && r !== apoyo ? <Chip label={"Su reemplazo: " + mname(d.members, r)} onPress={() => setApoyo(r)} /> : null; })()}
        {apoyo ? <Chip label="Quitar secundario" onPress={() => setApoyo(null)} /> : null}
      </View>
      <TextInput value={q2} onChangeText={setQ2} placeholder="Buscar responsable secundario" placeholderTextColor="#8A968F" style={{ minHeight: 44, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 12 }} />
      {q2 ? <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{d.members.filter((m) => m.activo !== false && m.id !== who && norm(m.name + " " + m.cargo + " " + m.unit).includes(norm(q2))).slice(0, 20).map((m) => <Chip key={m.id} label={m.name} on={m.id === apoyo} onPress={() => { setApoyo(m.id); setQ2(""); }} />)}</View> : null}
      </> : !isAdmin && !t ? <>
        <Text style={S.label}>Para: {who === d.me.id ? "mí mismo" : mname(d.members, who)}</Text>
        <TextInput value={q} onChangeText={setQ} placeholder="Buscar a quién enviar el trabajo" placeholderTextColor="#8A968F" style={{ minHeight: 44, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 12 }} />
        <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
          <Chip label="Para mí" on={who === d.me.id} onPress={() => { setWho(d.me.id); setTouched(true); }} />
          {cands.filter((m) => m.id !== d.me.id).map((m) => <Chip key={m.id} label={m.name} on={m.id === who} onPress={() => { setWho(m.id); setTouched(true); }} />)}
        </View>
        <Note kind={who !== d.me.id && !mismaOrg(d, d.me.id, who) || ["m-passalacqua", "m-cerda"].includes(who) ? "warn" : "info"} text={avisoEnvio(d, who)} />
      </> : !isAdmin ? <Note text="La tarea queda a tu nombre y el Comandante la verá con el color de tu área." /> : null}
      {isAdmin && !t && modo !== "persona" ? null : <Participantes d={d} value={part} onChange={setPart} isAdmin={isAdmin} />}
      <Field label="Producto / evidencia (opcional)" value={evid} onChangeText={setEvid} placeholder="Ej.: informe, acta, PPT" />
      {isAdmin ? <Btn small title="Aplicar esquema procesos y riesgo (jefe de área · OCGR · Operaciones)" onPress={() => {
        const jefe = (areaInfo(area) || {}).owner; if (jefe) { setWho(jefe); setTouched(true); }
        const j = jefe || who; setApoyo(j === "m-barbara-llancavil-cortez" ? "m-urquieta" : "m-barbara-llancavil-cortez");
        setPart(j === "m-urquieta" || j === "m-barbara-llancavil-cortez" ? [] : ["m-urquieta"]); setCtl("m-passalacqua"); setDir("m-cerda"); setModo("persona");
      }} /> : null}
      {isAdmin ? <><Text style={S.label}>Controla</Text><Chips options={[["m-cerda", "Comandante"], ["m-passalacqua", "Jefe Administrativo"], ["m-azocar", "Jefe Plana Mayor"], ["m-urquieta", "Operaciones"], ["m-barbara-llancavil-cortez", "OCGR"]]} value={ctl} onChange={setCtl} /></> : null}
      {isAdmin ? <><Text style={S.label}>Dirige</Text><Chips options={[["", "—"], ["m-cerda", "Cdte. de Zona"], ["m-passalacqua", "Jefe Administrativo"]]} value={dir || ""} onChange={(v) => setDir(v || null)} /></> : null}
      {isAdmin ? <Chip label={pub ? "✓ Visible para todos en la Carta Gantt" : "Solo responsables la ven (tocar para mostrar a todos en la Gantt)"} on={pub} onPress={() => setPub(!pub)} /> : null}
      <Field label="Plazo (dd-mm-aaaa hh:mm)" value={dueS} onChangeText={(v) => { setHabilOk(false); setDueS(v); }} />
      <Chips options={[[1, "+1 día"], [3, "+3 días"], [7, "+1 semana"], [14, "+2 semanas"]]} value={null} onChange={(n) => { setHabilOk(false); setDueS(toInput(addDays(startOfDay(Date.now()), n) + 12 * 3600000)); }} />
      <PlazoInhabil dueS={dueS} setDueS={(v) => { setHabilOk(false); setDueS(v); }} cfg={d.config} ok={habilOk} setOk={setHabilOk} />
      {dupAviso ? <Card style={{ borderColor: C.red, gap: 6 }}>
        <Text style={{ color: C.red, fontWeight: "800" }}>Ya existe una tarea muy similar</Text>
        <Text style={S.body}>“{dupAviso.title}”</Text>
        <Text style={S.small}>Asignada a {mname(d.members, dupAviso.member_id)}{dupAviso.delegado ? " (derivada a " + mname(d.members, dupAviso.delegado) + ")" : ""} · plazo {fmt(due(dupAviso))}. ¿Crear igual?</Text>
        <Row><Btn small title="Ver la existente" onPress={() => onClose({ kind: "task", id: dupAviso.id })} /><Btn small title="Cancelar" onPress={() => setDupAviso(null)} /><Btn small kind="primary" title="Crear igual" onPress={() => { setDupOk(true); setDupAviso(null); save(true); }} /></Row>
      </Card> : null}
      {err ? <Note kind="bad" text={err} /> : null}
      {isAdmin ? <Note kind="info" text="Si vence sin cumplirse, al responsable se le cita a tu oficina y a ti te aparece “Resolver vencida”." /> : null}
      <Btn title={t ? "Guardar cambios" : "Crear tarea"} kind="primary" onPress={save} />
    </Sheet>
  );
}

/* ================= Prórroga: pedir (integrante) ================= */
export function PedirProrroga({ t, d, onClose }) {
  const [req, setReq] = useState(toInput(addDays(due(t), 3)));
  const [motivo, setMotivo] = useState(MOTIVOS[0]); const [arg, setArg] = useState(""); const [err, setErr] = useState("");
  async function send() {
    const r = fromInput(req);
    if (!r || r <= due(t)) return setErr("La fecha debe ser posterior al plazo actual.");
    if (!arg.trim()) return setErr("Explica tu argumento.");
    if (await run(() => supabase.from("prorrogas").insert({ task_id: t.id, requested_due: new Date(r).toISOString(), motivo, argumento: arg.trim() }), "Solicitud enviada al Comandante")) onClose();
  }
  return (
    <Sheet visible title="Pedir prórroga" onClose={onClose}>
      <Card><Text style={S.title}>{t.title}</Text><Text style={S.small}>Plazo actual: {fmt(due(t))} · avance {t.progress || 0}%</Text></Card>
      <Field label="Nueva fecha que pides (dd-mm-aaaa hh:mm)" value={req} onChangeText={setReq} />
      <Text style={S.label}>Motivo principal</Text>
      <Chips options={MOTIVOS} value={motivo} onChange={setMotivo} />
      <Field label="Argumento" value={arg} onChangeText={setArg} multiline placeholder="Qué pasó y qué respaldo tienes" />
      {err ? <Note kind="bad" text={err} /> : null}
      <Note kind="info" text="El plazo actual sigue vigente hasta que el Comandante responda." />
      <Btn title="Enviar solicitud" kind="primary" onPress={send} />
    </Sheet>
  );
}

/* ================= Prórroga: decidir (Comandante) ================= */
export function DecidirProrroga({ p, t, d, onClose }) {
  const m = member(d.members, t.member_id);
  const [other, setOther] = useState(toInput(addDays(due(t), 1))); const [comment, setComment] = useState(""); const [err, setErr] = useState("");
  const [asig, setAsig] = useState(false); const [sel, setSel] = useState([]); const [fechaAsig, setFechaAsig] = useState("pedida");
  const [borrar, setBorrar] = useState(false);
  async function borrarSol() {
    const r = await supabase.from("prorrogas").delete().eq("id", p.id).select("id");
    if (r.error) return setErr(errMsg(r.error));
    if (!r.data || !r.data.length) return setErr("No se pudo borrar (sin permiso).");
    onClose(); Alert.alert("Solicitud borrada", "El plazo de la tarea no cambió.");
  }
  async function asignar() {
    if (!sel.length) return setErr("Elige al menos una persona.");
    const kind = fechaAsig === "pedida" ? "aprobada" : fechaAsig === "otra" ? "otra fecha" : "rechazada";
    const to = kind === "aprobada" ? new Date(p.requested_due).getTime() : kind === "otra fecha" ? fromInput(other) : null;
    if (kind === "otra fecha" && (!to || to <= due(t))) return setErr("La otra fecha debe ser posterior al plazo actual.");
    const nombres = sel.map((x) => mname(d.members, x)).join(", ");
    const r1 = await supabase.from("prorrogas").update({ status: kind, decided_due: to ? new Date(to).toISOString() : null, comment: (comment.trim() ? comment.trim() + " · " : "") + "Derivada a " + nombres, decided_at: new Date().toISOString() }).eq("id", p.id);
    if (r1.error) return setErr(errMsg(r1.error));
    const tl = Object.assign({}, t, { log: (t.log || []).concat([{ t: "prorroga", at: Date.now(), decision: kind, to, motivo: p.motivo }]) });
    const { error, est } = await asignarVarios(tl, d, sel, to);
    if (error) return setErr(errMsg(error));
    const plazoTxt = fmt(to || due(t)); const dm = member(d.members, sel[0]);
    const msgD = "Hito · Trabajo asignado\n" + first(dm) + ", se te deriva “" + t.title + "”" + (sel.length > 1 ? " junto a " + sel.slice(1).map((x) => mname(d.members, x)).join(", ") : "") + ". Plazo: " + plazoTxt + "." + (comment.trim() ? " " + comment.trim() : "");
    const msgO = "Hito · Prórroga resuelta\n" + first(m) + ", “" + t.title + "” queda derivada a " + nombres + ". Plazo: " + plazoTxt + "." + (comment.trim() ? " " + comment.trim() : "");
    onClose();
    if (est !== "derivada") return Alert.alert("Enviada al Comandante", "La derivación a " + nombres + " queda pendiente de su aprobación.");
    Alert.alert("Asignada a " + nombres, "Todos la ven en Mis tareas. ¿Avisar por WhatsApp?", [{ text: "Ahora no" },
      { text: "A " + first(dm), onPress: () => openWa(dm && dm.phone, msgD) }, { text: "A " + first(m), onPress: () => openWa(m && m.phone, msgO) }]);
  }
  async function decide(kind) {
    const to = kind === "aprobada" ? new Date(p.requested_due).getTime() : kind === "otra fecha" ? fromInput(other) : null;
    if (kind === "otra fecha" && (!to || to <= due(t))) return setErr("La otra fecha debe ser posterior al plazo actual.");
    if (kind === "rechazada" && !comment.trim()) return setErr("Escribe el motivo del rechazo.");
    const r1 = await supabase.from("prorrogas").update({ status: kind, decided_due: to ? new Date(to).toISOString() : null, comment: comment.trim(), decided_at: new Date().toISOString() }).eq("id", p.id);
    if (r1.error) return setErr(errMsg(r1.error));
    const log = (t.log || []).concat([{ t: "prorroga", at: Date.now(), decision: kind, to, motivo: p.motivo }]);
    const upd = { log }; if (to) upd.due = new Date(to).toISOString();
    const r2 = await supabase.from("tasks").update(upd).eq("id", t.id);
    if (r2.error) return setErr(errMsg(r2.error));
    const msg = kind === "rechazada" ? "Hito · Prórroga rechazada\n" + first(m) + ", se mantiene el plazo de “" + t.title + "”: " + fmt(due(t)) + ". " + comment.trim()
      : "Hito · Prórroga " + (kind === "aprobada" ? "aprobada" : "con otra fecha") + "\n" + first(m) + ", el nuevo plazo de “" + t.title + "” es " + fmt(to) + "." + (comment.trim() ? " " + comment.trim() : "");
    onClose();
    Alert.alert("Decisión guardada", "¿Avisar por WhatsApp?", [{ text: "Ahora no" }, { text: "Enviar", onPress: () => openWa(m && m.phone, msg) }]);
  }
  return (
    <Sheet visible title="Solicitud de prórroga" onClose={onClose}>
      <Card tone="inv"><Text style={{ color: C.invFg, fontWeight: "800" }}>{t.title}</Text><Text style={{ color: C.invMuted }}>{mname(d.members, t.member_id)}</Text></Card>
      <Row><Card style={{ flex: 1 }}><Text style={S.small}>Plazo actual</Text><Text style={S.title}>{fmtDay(due(t))}</Text></Card><Card tone="warn" style={{ flex: 1 }}><Text style={S.small}>Pide</Text><Text style={S.title}>{fmtDay(new Date(p.requested_due).getTime())}</Text></Card></Row>
      <Card><Badge text={p.motivo} /><Text style={S.body}>{p.argumento}</Text></Card>
      <Card>
        <Text style={S.label}>Contexto</Text>
        <Text style={S.small}>Avance: {t.progress || 0}%</Text>
        <Text style={S.small}>Otras tareas abiertas: {d.tasks.filter((x) => x.member_id === t.member_id && !x.done && x.id !== t.id).length}</Text>
        <Text style={S.small}>Prórrogas pedidas este mes: {d.prorrogas.filter((x) => x.member_id === t.member_id && new Date(x.created_at).getMonth() === new Date().getMonth()).length}</Text>
      </Card>
      <Field label="Si das otra fecha (dd-mm-aaaa hh:mm)" value={other} onChangeText={setOther} />
      <Field label="Comentario (obligatorio al rechazar)" value={comment} onChangeText={setComment} />
      {err ? <Note kind="bad" text={err} /> : null}
      <Row><Btn title="Rechazar" kind="danger" style={{ flex: 1 }} onPress={() => decide("rechazada")} /><Btn title="Otra fecha" style={{ flex: 1 }} onPress={() => decide("otra fecha")} /><Btn title="Aprobar" kind="primary" style={{ flex: 1 }} onPress={() => decide("aprobada")} /></Row>
      {d.me && d.me.role === "admin" ? (!borrar ? <Btn title="🗑 Borrar solicitud" kind="danger" onPress={() => setBorrar(true)} /> : (
        <Card style={{ borderColor: C.red }}>
          <Text style={{ color: C.red, fontWeight: "800" }}>¿Borrar esta solicitud de prórroga?</Text>
          <Text style={S.small}>Se elimina sin aprobar ni rechazar (por ejemplo, si está duplicada). La tarea mantiene su plazo actual.</Text>
          <Row><Btn title="No" style={{ flex: 1 }} onPress={() => setBorrar(false)} /><Btn title="Sí, borrar" kind="danger" style={{ flex: 1 }} onPress={borrarSol} /></Row>
        </Card>)) : null}
      {!asig ? <Btn title="↪ Derivar / delegar a otros responsables" onPress={() => setAsig(true)} /> : (
        <Card style={{ borderColor: "#B9A2E0" }}>
          <Text style={{ color: "#5B3A8E", fontWeight: "800" }}>Derivar / delegar</Text>
          <Text style={S.small}>{mname(d.members, t.member_id)} sigue a cargo; quienes elijas quedan como responsables y la ven en Mis tareas.</Text>
          <ElegirVarios d={d} t={t} sel={sel} setSel={setSel} hint="Buscar persona o equipo (ej. apoyo, mantención)" />
          <Text style={S.label}>Plazo</Text>
          <Chips options={[["pedida", "Fecha pedida (" + fmtDay(new Date(p.requested_due).getTime()) + ")"], ["otra", "Otra fecha (arriba)"], ["mantener", "Mantener plazo"]]} value={fechaAsig} onChange={setFechaAsig} />
          <Row><Btn title="Cancelar" style={{ flex: 1 }} onPress={() => { setAsig(false); setSel([]); }} /><Btn title={"Asignar" + (sel.length ? " (" + sel.length + ")" : "")} kind="primary" style={{ flex: 1 }} onPress={asignar} /></Row>
        </Card>)}
    </Sheet>
  );
}

/* ================= Resolver vencida (Comandante) ================= */
export function Resolver({ t, d, onClose }) {
  const m = member(d.members, t.member_id);
  const [came, setCame] = useState(true); const [note, setNote] = useState(""); const [plazo, setPlazo] = useState(3);
  const [custom, setCustom] = useState(toInput(addDays(startOfDay(Date.now()), 3) + 18 * 3600000)); const [err, setErr] = useState("");
  async function close() {
    let upd, msg;
    if (came === "mio") {
      const to = plazo ? addDays(startOfDay(Date.now()), plazo) + 18 * 3600000 : fromInput(custom);
      if (!to || to <= Date.now()) return setErr("Elige un nuevo plazo en el futuro.");
      upd = { delegado: d.me.id, delegado_por: d.me.id, due: new Date(to).toISOString(), late: true, overdue_ack_at: null, log: (t.log || []).concat([{ t: "derivada al Comandante tras vencer", at: Date.now(), to, note: note.trim() }]) };
      msg = "Hito · Tarea derivada\n" + first(m) + ", la tarea “" + t.title + "” (vencida el " + fmtDay(due(t)) + ") queda derivada al Comandante, con nuevo plazo " + fmt(to) + ".";
    } else if (came === "ok") {
      upd = { done: true, done_at: new Date().toISOString(), progress: 100, overdue_ack_at: null, log: (t.log || []).concat([{ t: "cumplida", at: Date.now(), tras_vencer: true, note: note.trim() }]) };
      msg = "Hito · Tarea cerrada\n" + first(m) + ", se registró como completa la tarea “" + t.title + "” (vencida el " + fmtDay(due(t)) + ").";
    } else if (came) {
      const to = plazo ? addDays(startOfDay(Date.now()), plazo) + 18 * 3600000 : fromInput(custom);
      if (!to || to <= Date.now()) return setErr("Elige un nuevo plazo en el futuro.");
      upd = { due: new Date(to).toISOString(), late: true, overdue_ack_at: null, log: (t.log || []).concat([{ t: "citacion", at: Date.now(), came: true, to, note: note.trim() }]) };
      msg = "Hito · Nuevo plazo\n" + first(m) + ", tras la reunión, el nuevo plazo de “" + t.title + "” es " + fmt(to) + ".";
    } else {
      upd = { no_shows: (t.no_shows || 0) + 1, log: (t.log || []).concat([{ t: "citacion", at: Date.now(), came: false }]) };
      msg = "Hito · Citación pendiente\n" + first(m) + ", aún no te presentas por “" + t.title + "”, vencida el " + fmtDay(due(t)) + ". Preséntate en la oficina del Comandante.";
    }
    const r = await supabase.from("tasks").update(upd).eq("id", t.id);
    if (r.error) return setErr(errMsg(r.error));
    onClose();
    Alert.alert(came === "mio" ? "Tarea derivada a ti" : came === "ok" ? "Tarea completa registrada" : came ? "Nuevo plazo registrado" : "Inasistencia registrada", "¿Avisar por WhatsApp?", [{ text: "Ahora no" }, { text: "Enviar", onPress: () => openWa(m && m.phone, msg) }]);
  }
  return (
    <Sheet visible title="Resolver tarea vencida" onClose={onClose}>
      <Card tone="inv"><Text style={{ color: C.invFg, fontWeight: "800" }}>{m ? m.name : "Sin asignar"}</Text><Text style={{ color: C.invMuted }}>“{t.title}” venció el {fmt(due(t))}{t.overdue_ack_at ? " · leyó el aviso" : ""}</Text></Card>
      {d.me && (d.me.role === "admin" || d.me.id === t.member_id) ? <Delegar t={t} d={d} onDone={onClose} /> : null}
      <Text style={S.label}>1. ¿Cómo la resuelves?</Text>
      <Chips options={[["ok", "✓ Tarea completa"], [true, "Se presentó: nuevo plazo"], [false, "No se presentó"], ...(d.me && d.me.role === "admin" ? [["mio", "↪ Derivar a mí"]] : [])]} value={came} onChange={setCame} />
      {came === "mio" ? (
        <>
          <Note kind="info" text={"La tarea queda derivada a ti: " + (m ? m.name : "el responsable") + " sigue como responsable y tú la ejecutas. Cuenta como atrasada en las notas."} />
          <Field label="Observación (opcional)" value={note} onChangeText={setNote} multiline />
          <Text style={S.label}>Nuevo plazo</Text>
          <Chips options={[[1, "+1 día"], [3, "+3 días"], [7, "+1 semana"], [0, "Otra fecha"]]} value={plazo} onChange={setPlazo} />
          {plazo === 0 ? <Field label="Fecha (dd-mm-aaaa hh:mm)" value={custom} onChangeText={setCustom} /> : null}
        </>
      ) : came === "ok" ? (
        <>
          <Note text="La tarea queda cumplida con fecha de hoy. Como se cerró después del plazo, cuenta como cumplida con atraso en las notas." />
          <Field label="Observación (opcional)" value={note} onChangeText={setNote} multiline />
        </>
      ) : came ? (
        <>
          <Field label="2. Por qué no la cumplió" value={note} onChangeText={setNote} multiline />
          <Text style={S.label}>3. ¿Cuánto plazo le das?</Text>
          <Chips options={[[1, "+1 día"], [3, "+3 días"], [7, "+1 semana"], [0, "Otra fecha"]]} value={plazo} onChange={setPlazo} />
          {plazo === 0 ? <Field label="Fecha (dd-mm-aaaa hh:mm)" value={custom} onChangeText={setCustom} /> : null}
        </>
      ) : <Note kind="bad" text="La tarea sigue vencida y queda registrada la inasistencia. Seguirá en tu lista hasta que se presente." />}
      {err ? <Note kind="bad" text={err} /> : null}
      <Btn title={came === "mio" ? "Derivar a mí" : came === "ok" ? "Marcar tarea completa" : "Cerrar mi tarea"} kind={came === "ok" || came === "mio" ? "primary" : "dark"} onPress={close} />
    </Sheet>
  );
}

/* ================= Evento ================= */
/* Notificar por WhatsApp y correo */
export function NotificarSheet({ d, msg, onClose }) {
  const ms = [...new Set((msg.ids || []).filter(Boolean))].map((id) => d.members.find((m) => m.id === id) || { id, name: id });
  const texto = firmaTexto(d, msg.body);
  const wa = "*" + msg.subject + "*\n\n" + texto;
  const conMail = ms.filter((m) => m.email).length;
  return (
    <Sheet visible title="Notificar" onClose={onClose}>
      <Card><Text style={S.small}>{msg.subject}</Text><Text style={S.body} numberOfLines={6}>{msg.body}</Text></Card>
      <Btn title={"Correo a todos (" + conMail + " de " + ms.length + " con correo)"} kind="primary" onPress={() => notificarCorreo(d, msg.ids, msg.subject, msg.body)} />
      <Btn title="WhatsApp a un grupo o chat (compartir)" onPress={() => Share.share({ message: wa })} />
      <Text style={S.label}>WhatsApp a cada persona</Text>
      {ms.length ? ms.map((m) => (
        <Between key={m.id}>
          <Text style={[S.small, { flex: 1, color: C.ink }]}>{m.name}{m.phone ? "" : " · sin teléfono"}</Text>
          {m.phone ? <Btn small title="WhatsApp" onPress={() => openWa(m.phone, wa)} /> : null}
        </Between>)) : <Empty text="No hay destinatarios." />}
      {ms.some((m) => !m.phone || !m.email) ? <Note kind="info" text="A quien le falte teléfono o correo se lo puedes agregar en Equipo → Personas." /> : null}
    </Sheet>);
}

/* Participantes adicionales (tareas y eventos) con alta rápida de teléfono */
export function Participantes({ d, value, onChange, isAdmin }) {
  const [q, setQ] = useState(""); const [tel, setTel] = useState({}); const [mail, setMail] = useState({});
  const sel = value || [];
  const cands = q ? d.members.filter((m) => m.activo !== false && m.nivel !== "X" && !sel.includes(m.id) && norm(m.name + " " + m.cargo + " " + m.unit).includes(norm(q))).slice(0, 20) : [];
  async function saveTel(m) {
    const v = (tel[m.id] || "").trim(); if (phoneDigits(v).length < 8) return Alert.alert("Escribe un número válido", "Ej.: +56 9 1234 5678");
    if (await run(() => supabase.from("members").update({ phone: v }).eq("id", m.id), "Teléfono guardado")) setTel({ ...tel, [m.id]: undefined });
  }
  async function saveMail(m) {
    const v = (mail[m.id] || "").trim().toLowerCase(); if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v)) return Alert.alert("Escribe un correo válido", "Ej.: nombre.apellido@ejercito.cl");
    if (await run(() => supabase.from("members").update({ email: v }).eq("id", m.id), "Correo guardado")) setMail({ ...mail, [m.id]: undefined });
  }
  return (<>
    <Text style={S.label}>Participantes ({sel.length})</Text>
    {sel.map((id) => { const m = d.members.find((x) => x.id === id) || { id, name: id };
      return (
        <View key={id} style={{ backgroundColor: C.surface2, borderRadius: 10, padding: 8, gap: 4 }}>
          <Between><Text style={[S.small, { fontWeight: "700", color: C.ink, flexShrink: 1 }]}>{m.name}</Text><Pressable onPress={() => onChange(sel.filter((x) => x !== id))}><Text style={{ color: C.red, fontWeight: "800", paddingHorizontal: 6 }}>Quitar</Text></Pressable></Between>
          {m.phone ? <Text style={S.small}>Tel. {m.phone}</Text> : isAdmin ? (
            <Row><TextInput value={tel[id] || ""} onChangeText={(v) => setTel({ ...tel, [id]: v })} placeholder="Sin teléfono · agregar +56 9…" placeholderTextColor="#8A968F" keyboardType="phone-pad" style={{ flex: 1, minHeight: 38, borderRadius: 8, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 10 }} /><Btn small title="Guardar" onPress={() => saveTel(m)} /></Row>
          ) : <Text style={[S.small, { color: C.amberInk }]}>Sin teléfono registrado</Text>}
          {m.email ? <Text style={S.small}>Correo {m.email}</Text> : isAdmin ? (
            <Row><TextInput value={mail[id] || ""} onChangeText={(v) => setMail({ ...mail, [id]: v })} placeholder="Sin correo · agregar nombre@ejercito.cl" placeholderTextColor="#8A968F" keyboardType="email-address" autoCapitalize="none" style={{ flex: 1, minHeight: 38, borderRadius: 8, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 10 }} /><Btn small title="Guardar" onPress={() => saveMail(m)} /></Row>
          ) : null}
        </View>); })}
    <TextInput value={q} onChangeText={setQ} placeholder="+ Agregar participante (buscar por nombre, cargo o unidad)" placeholderTextColor="#8A968F" style={{ minHeight: 44, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 12 }} />
    {cands.length ? <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{cands.map((m) => <Chip key={m.id} label={m.name + (m.phone ? "" : " · sin tel.")} onPress={() => { onChange([...sel, m.id]); setQ(""); }} />)}</View> : null}
  </>);
}

export function EventForm({ d, isAdmin, onClose, e }) {
  const [title, setTitle] = useState(e ? e.title : ""); const [type, setType] = useState(e ? e.type || EVTYPES[0] : EVTYPES[0]);
  const [at, setAt] = useState(toInput(e ? new Date(e.at).getTime() : Date.now())); const [detail, setDetail] = useState(e ? e.detail || "" : ""); const [err, setErr] = useState("");
  const [resp, setResp] = useState(e ? e.responsable || null : null); const [q, setQ] = useState("");
  const [part, setPart] = useState(e ? e.participantes || [] : []);
  const cands = q ? d.members.filter((m) => m.activo !== false && m.nivel !== "X" && norm(m.name + " " + m.cargo + " " + m.unit).includes(norm(q))).slice(0, 20) : [];
  async function save() {
    const a = fromInput(at);
    if (!title.trim() || !a) return setErr("Completa qué pasó y la fecha.");
    const body = { title: title.trim(), type, at: new Date(a).toISOString(), detail: detail.trim(), responsable: resp, participantes: part };
    const ok = e
      ? await run(() => supabase.from("events").update(body).eq("id", e.id), "Evento actualizado")
      : await run(() => supabase.from("events").insert({ ...body, by_member: d.me ? d.me.id : null }), "Evento anotado");
    if (ok) { if (resp || part.length) onClose({ kind: "notificar", msg: msgEvento(d, { ...(e || {}), ...body }) }); else onClose(); }
  }
  async function del() { if (await run(() => supabase.from("events").delete().eq("id", e.id), "Evento eliminado")) onClose(); }
  return (
    <Sheet visible title={e ? "Editar evento" : "Anotar evento"} onClose={onClose}>
      {!e ? <Note kind="info" text="Un evento registra algo que pasó o va a pasar. No tiene plazo ni cuenta para las notas. Queda tu nombre como autor." /> : null}
      <Field label="Qué pasó" value={title} onChangeText={setTitle} />
      <Text style={S.label}>Tipo</Text>
      <Chips options={EVTYPES} value={type} onChange={setType} />
      <Field label="Fecha y hora (dd-mm-aaaa hh:mm)" value={at} onChangeText={setAt} />
      <Field label="Detalle" value={detail} onChangeText={setDetail} multiline />
      <Text style={S.label}>Responsable (opcional): {resp ? mname(d.members, resp) : "—"}</Text>
      <Field label="" value={q} onChangeText={setQ} placeholder="Buscar persona por nombre, cargo o unidad" />
      {cands.length ? <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{cands.map((m) => <Chip key={m.id} label={m.name} on={m.id === resp} onPress={() => { setResp(m.id); setQ(""); }} />)}</View> : null}
      {resp ? <Btn small title="Quitar responsable" onPress={() => setResp(null)} /> : null}
      <Participantes d={d} value={part} onChange={setPart} isAdmin={isAdmin} />
      {err ? <Note kind="bad" text={err} /> : null}
      <Btn title={e ? "Guardar cambios" : "Guardar evento"} kind="blue" onPress={save} />
      {e ? <Btn title="Eliminar evento" kind="danger" onPress={del} /> : null}
    </Sheet>
  );
}

/* ================= Aviso del mural ================= */
export function PostForm({ onClose, d }) {
  const admin = !!(d && d.me && d.me.role === "admin");
  const [title, setTitle] = useState(""); const [body, setBody] = useState(""); const [cat, setCat] = useState("avisos"); const [pinned, setPinned] = useState(false);
  async function save() {
    if (!title.trim()) return Alert.alert("Escribe un título");
    if (await run(() => supabase.from("posts").insert({ title: title.trim(), body: body.trim(), cat, pinned: admin ? pinned : false, autor: d && d.me ? d.me.id : null }), "Aviso publicado")) onClose();
  }
  return (
    <Sheet visible title="Nuevo aviso" onClose={onClose}>
      <Field label="Título" value={title} onChangeText={setTitle} />
      <Field label="Texto" value={body} onChangeText={setBody} multiline />
      <Chips options={CATS} value={cat} onChange={setCat} />
      {admin ? <Chips options={[[false, "Normal"], [true, "Fijar arriba"]]} value={pinned} onChange={setPinned} /> : null}
      <Btn title="Publicar" kind="primary" onPress={save} />
    </Sheet>
  );
}

/* ================= Integrante (Comandante) ================= */
export function MemberForm({ m, d, onClose }) {
  if (m.nuevo) return <NuevoIntegrante d={d} onClose={onClose} />;
  const [name, setName] = useState(m.name); const [cargo, setCargo] = useState(m.cargo || ""); const [phone, setPhone] = useState(m.phone || ""); const [email, setEmail] = useState(m.email || "");
  const open = d.tasks.filter((t) => t.member_id === m.id && !t.done);
  const procs = [].concat(...TFK.map((k) => TF[k].procs.filter((p) => (procInfo(p[0], d.config.owners) || {}).owner === m.id).map((p) => p[0])));
  async function save() { if (await run(() => supabase.from("members").update({ name: name.trim(), cargo: cargo.trim(), phone: phone.trim(), email: email.trim().toLowerCase() || null }).eq("id", m.id), "Datos guardados")) onClose(); }
  function resetear() {
    Alert.alert("Resetear acceso", "Se libera el acceso de " + m.name + ". Sus tareas y datos no se borran. Después debe abrir Hito, tocar “Crear mi acceso” con su número y elegir un PIN nuevo. ¿Continuar?", [
      { text: "Cancelar", style: "cancel" },
      { text: "Resetear", onPress: async () => {
        const { data, error } = await supabase.rpc("reset_acceso", { p_member: m.id });
        if (error) return Alert.alert("No se pudo resetear", errMsg(error));
        onClose();
        Alert.alert(data === "sin_cuenta" ? "No tenía acceso creado" : "Acceso reseteado", "¿Avisarle por WhatsApp cómo crear su PIN nuevo?", [
          { text: "Ahora no", style: "cancel" },
          { text: "Avisar", onPress: () => openWa(m.phone, "Hito · Zona de Bienestar Arica\n" + first(m) + ", tu acceso fue reseteado. Abre Hito, toca “Crear mi acceso”, escribe tu número y elige un PIN nuevo de al menos 6 dígitos. Luego toca “Ingresar”.") }]);
      } }]);
  }
  return (
    <Sheet visible title={m.name} onClose={onClose}>
      <Card>
        <Text style={S.small}>{m.unit || "Sin unidad"}</Text>
        {m.reemplazo ? <Text style={S.small}>Reemplazo: {m.reemplazo}</Text> : null}
        {procs.length ? <Text style={S.small}>Responsable de: {procs.join(", ")}</Text> : null}
        {m.wa_name ? <Text style={S.small}>En tu WhatsApp: {m.wa_name}</Text> : null}
        <Text style={S.small}>{m.user_id ? "Ya tiene acceso a la app." : "Aún no crea su acceso."} {open.length ? open.length + " tareas abiertas." : ""}</Text>
      </Card>
      {d.me && d.me.role === "admin" ? <>
        <Field label="Nombre" value={name} onChangeText={setName} />
        <Field label="Cargo" value={cargo} onChangeText={setCargo} />
        <Field label="WhatsApp (con este número entra a la app)" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
        <Field label="Correo (para avisos por correo)" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" placeholder="nombre.apellido@ejercito.cl" />
        <Btn title="Guardar" kind="primary" onPress={save} />
        {m.phone ? <Btn title="Invitar por WhatsApp" onPress={() => openWa(m.phone, "Hito · Zona de Bienestar Arica\n" + first(m) + ", instala la app Hito y crea tu acceso con este número y un PIN de 6 dígitos. Ahí verás tus tareas, plazos y avisos.")} /> : null}
        {m.user_id && m.id !== d.me.id ? <Btn title="🔑 Resetear acceso (PIN)" kind="danger" onPress={resetear} /> : null}
      </> : null}
    </Sheet>
  );
}

const slugId = (s) => "m-" + norm(s).replace(/^(gdb|crl|tcl|may|cap|tte|ste|som|sof|sg1|sg2|cb1|cb2|cbo|slc|ecp|ecl|pac|paj|pah)\s+/, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
function NuevoIntegrante({ d, onClose }) {
  const units = []; d.members.forEach((x) => { if (x.unit && !units.includes(x.unit) && !/WhatsApp/i.test(x.unit)) units.push(x.unit); });
  const [grado, setGrado] = useState("SG2"); const [nombre, setNombre] = useState(""); const [unit, setUnit] = useState(null);
  const [cargo, setCargo] = useState(""); const [phone, setPhone] = useState(""); const [hasta, setHasta] = useState(""); const [err, setErr] = useState("");
  const GR = ["CAP", "TTE", "SOF", "SG1", "SG2", "CB1", "CB2", "CBO", "ECP", "ECL", "PAC", "PAJ", "PAH"];
  async function save() {
    const n = nombre.trim();
    if (n.split(/\s+/).length < 2) return setErr("Escribe nombre y apellidos.");
    if (!unit) return setErr("Elige la unidad.");
    const dig = phone.replace(/\D/g, "");
    if (dig && dig.length < 8) return setErr("Revisa el número de WhatsApp.");
    const full = grado + " " + n;
    let id = slugId(full); if (d.members.some((x) => x.id === id)) id += "-" + Date.now().toString(36).slice(-4);
    const fono = dig ? "+56 9 " + dig.slice(-8, -4) + " " + dig.slice(-4) : "";
    if (dig && d.members.some((x) => x.phone_digits && x.phone_digits.slice(-8) === dig.slice(-8))) return setErr("Ese número ya está registrado en otra ficha.");
    const iso = toIso2(hasta);
    if (hasta.trim() && !iso) return setErr("Fecha de término como dd-mm-aaaa.");
    const ref = d.members.find((x) => x.unit === unit) || {};
    const row = { id, name: full, grado, cargo: cargo.trim(), unit, unit_order: ref.unit_order || 99, nivel: "C", phone: fono, role: "member", parte: true, parte_hasta: iso || null };
    if (await run(() => supabase.from("members").insert(row), full + " agregado")) onClose();
  }
  return (
    <Sheet visible title="Agregar integrante" onClose={onClose}>
      <Text style={S.label}>Grado</Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{GR.map((g) => <Chip key={g} label={g} on={grado === g} onPress={() => setGrado(g)} />)}</View>
      <Field label="Nombre y apellidos" value={nombre} onChangeText={setNombre} placeholder="Ej.: Andrés Cantergiani Concha" />
      <Text style={S.label}>Unidad</Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{units.map((u) => <Chip key={u} label={u} on={unit === u} onPress={() => setUnit(u)} />)}</View>
      <Field label="Cargo" value={cargo} onChangeText={setCargo} placeholder="Ej.: Operador de mercado público" />
      <Field label="WhatsApp (con este número entra a la app)" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="9 1234 5678" />
      <Field label="Fecha de término en el parte (opcional, dd-mm-aaaa)" value={hasta} onChangeText={setHasta} placeholder="31-12-2026" />
      {err ? <Note kind="bad" text={err} /> : null}
      <Btn title="Agregar" kind="primary" onPress={save} />
      <Note kind="info" text="Después podrá entrar con “Crear mi acceso” usando ese número y un PIN propio." />
    </Sheet>
  );
}
const toIso2 = (s) => { const x = String(s || "").trim().match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/); return x ? x[3] + "-" + x[2].padStart(2, "0") + "-" + x[1].padStart(2, "0") : null; };

/* ================= Vistas ================= */

function filasTareas(d, list) {
  const st = (t) => t.done ? "Cumplida" : due(t) < Date.now() ? "Vencida" : "Pendiente";
  return [["Tarea", "Área", "Responsable", "Secundario", "Plazo", "Estado", "Avance %", "Proceso"]].concat(
    list.map((t) => [t.title, (areaInfo(t.area) || {}).name || "", mname(d.members, t.member_id), t.apoyo ? mname(d.members, t.apoyo) : "", fmt(due(t)), st(t), t.progress || 0, t.proc || ""]));
}

/* Botones rápidos: Tareas pendientes / Tareas completadas */
function BotonesRapidos({ vista, setVista, nPend, nComp }) {
  const B = ({ k, l, n, c }) => (
    <Pressable onPress={() => setVista(vista === k ? null : k)} style={{ flex: 1, minHeight: 64, borderRadius: 14, padding: 12, justifyContent: "center", backgroundColor: vista === k ? c : C.surface, borderWidth: 2, borderColor: c }}>
      <Text style={{ fontSize: 16, fontWeight: "800", color: vista === k ? "#fff" : c }}>{l}</Text>
      <Text style={{ fontSize: 12, color: vista === k ? "#fff" : C.muted }}>{n} tareas{vista === k ? " · tocar para volver" : ""}</Text>
    </Pressable>);
  return <Row><B k="pend" l="Tareas pendientes" n={nPend} c="#2F5DA8" /><B k="comp" l="Tareas completadas" n={nComp} c={C.accent} /></Row>;
}
function ListaRapida({ d, open, tasks, vista }) {
  const [q, setQ] = useState("");
  const list = tasks.filter((t) => (vista === "comp" ? t.done : !t.done) && (!q || norm(t.title + " " + mname(d.members, t.member_id)).includes(norm(q))))
    .sort((a, b) => vista === "comp" ? new Date(b.done_at || 0) - new Date(a.done_at || 0) : due(a) - due(b));
  return (
    <View style={{ gap: 8 }}>
      <TextInput value={q} onChangeText={setQ} placeholder="Buscar tarea o responsable" placeholderTextColor="#8A968F" style={{ minHeight: 44, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 12 }} />
      {list.length ? list.map((t) => {
        const st = status(t); const col = areaColor(t);
        return (
          <Card key={t.id} onPress={() => open({ kind: "task", id: t.id })} style={col ? { borderLeftWidth: 6, borderLeftColor: col } : null}>
            <View style={{ position: "relative", justifyContent: "center", alignSelf: "flex-start", maxWidth: "100%" }}>
              <Text numberOfLines={vista === "comp" ? 1 : 3} style={[S.title, vista === "comp" ? { color: C.muted } : null]}>{t.title}</Text>
              {vista === "comp" ? <View pointerEvents="none" style={{ position: "absolute", left: 0, right: 0, top: "50%", height: 2, backgroundColor: C.red }} /> : null}
            </View>
            <Text style={S.small}>{mname(d.members, t.member_id)}{(areaInfo(t.area) || {}).name ? " · " + areaInfo(t.area).name : ""}</Text>
            <Text style={[S.small, { color: vista === "comp" ? C.accent : st === "over" ? C.red : st === "soon" ? C.amber : C.ink2, fontWeight: "700" }]}>
              {vista === "comp" ? "Completada" + (t.done_at ? " el " + fmt(new Date(t.done_at).getTime()) : "") : (st === "over" ? "😟 Vencida · " : st === "soon" ? "😐 Plazo " : "😊 Plazo ") + fmt(due(t)) + " · avance " + (t.progress || 0) + "%"}
            </Text>
            {esCreador(t, d) ? <Row><Btn small title="✏️ Corregir texto" onPress={() => open({ kind: "corregir", t })} /></Row> : null}
          </Card>); }) : <Empty text={vista === "comp" ? "Aún no hay tareas completadas." : "No hay tareas pendientes."} />}
    </View>);
}

/* Catálogo presupuestario por centro de costo (montos editables por STE Rodríguez, TCL Cerda y ECP Sandoval) */
function Catalogo({ d, ccKey, nombre }) {
  const [abierto, setAbierto] = useState(false);
  const [draft, setDraft] = useState({});
  const puede = !!(d.me && (d.me.role === "admin" || EDITORES_CATALOGO.includes(d.me.id)));
  const filas = (d.catalogo || []).filter((x) => x.cc_key === ccKey);
  const montos = {}; filas.forEach((x) => (montos[x.codigo] = Number(x.monto) || 0));
  Object.entries(draft).forEach(([k, v]) => { const n = Number(String(v).replace(/[^0-9]/g, "")); if (!isNaN(n)) montos[k] = n; });
  const clp = (n) => new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(Number(n) || 0);
  const ultima = filas.slice().sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at))[0];
  async function guardar(code) {
    if (draft[code] === undefined) return;
    const raw = String(draft[code]).replace(/[. $]/g, "");
    if (raw && !/^\d+$/.test(raw)) return Alert.alert("Monto inválido", "Usa solo números.");
    const { error } = await supabase.from("cc_catalogo").upsert({ cc_key: ccKey, codigo: code, monto: raw ? Number(raw) : 0, updated_by: d.me.id, updated_at: new Date().toISOString() }, { onConflict: "cc_key,codigo" });
    if (error) return Alert.alert("No se pudo guardar", errMsg(error));
    setDraft((x) => { const y = { ...x }; delete y[code]; return y; });
  }
  const totalGeneral = CLASIFICADOR.filter((r) => r[2] === 0 && r[0] !== "35").reduce((a, r) => a + totalDe(r[0], montos), 0);
  return (
    <View style={{ marginTop: 6 }}>
      <Pressable onPress={() => setAbierto(!abierto)} style={{ paddingVertical: 8 }}>
        <Text style={{ color: C.accent, fontWeight: "800", fontSize: 15 }}>Catálogo {abierto ? "▲" : "▼"}</Text>
      </Pressable>
      {abierto ? (
        <View style={{ borderWidth: 1, borderColor: C.line, borderRadius: 10, overflow: "hidden" }}>
          <View style={{ backgroundColor: C.surface2, padding: 8 }}>
            <Text style={{ fontWeight: "800", color: C.ink }}>Instalaciones de Bienestar · 5659 · {nombre}</Text>
            <Text style={S.small}>{puede ? "Escribe el monto y toca fuera del recuadro para guardar." : "Solo STE Rodríguez, TCL Cerda y ECP Sandoval pueden ingresar montos."}{ultima ? " Última actualización: " + fmtDay(new Date(ultima.updated_at).getTime()) + " por " + mname(d.members, ultima.updated_by) + "." : ""}</Text>
          </View>
          {CLASIFICADOR.map(([code, name, lvl]) => {
            const hoja = esHoja(code); const tot = totalDe(code, montos);
            const head = lvl === 0;
            return (
              <View key={code} style={{ flexDirection: "row", alignItems: "center", paddingVertical: head ? 7 : 4, paddingHorizontal: 8, borderTopWidth: 1, borderColor: C.line, backgroundColor: head ? "#FBEBC8" : C.surface }}>
                <Text style={{ flex: 1, paddingLeft: lvl * 12, fontSize: head ? 13 : 12, fontWeight: lvl < 2 ? "800" : "400", color: C.ink }}>{name}</Text>
                <Text style={{ width: 74, textAlign: "right", fontSize: 11, color: C.muted, fontWeight: lvl < 2 ? "800" : "400" }}>{code}</Text>
                {hoja && puede ? (
                  <TextInput value={draft[code] !== undefined ? draft[code] : (montos[code] ? String(montos[code]) : "")} onChangeText={(v) => setDraft((x) => ({ ...x, [code]: v }))} onBlur={() => guardar(code)} onSubmitEditing={() => guardar(code)}
                    placeholder="0" placeholderTextColor="#8A968F" keyboardType="numeric" style={{ width: 110, marginLeft: 6, minHeight: 32, borderRadius: 6, borderWidth: 1, borderColor: draft[code] !== undefined ? C.amber : C.line2, paddingHorizontal: 6, textAlign: "right", fontSize: 12, backgroundColor: "#fff" }} />
                ) : <Text style={{ width: 110, marginLeft: 6, textAlign: "right", fontSize: 12, fontWeight: hoja ? "400" : "800", color: tot ? C.ink : C.muted }}>{tot ? clp(tot) : "—"}</Text>}
              </View>);
          })}
          <View style={{ flexDirection: "row", padding: 8, backgroundColor: C.inv }}>
            <Text style={{ flex: 1, color: C.invFg, fontWeight: "800" }}>TOTAL GASTOS (21 a 29)</Text>
            <Text style={{ color: C.invFg, fontWeight: "800" }}>{clp(totalGeneral)}</Text>
          </View>
          <View style={{ padding: 8 }}>
            <Descargar titulo={"Catálogo " + nombre} build={() => ({ hojas: [{ nombre: "Catálogo", filas: [["Código", "Cuenta", "Monto"]].concat(CLASIFICADOR.map(([c, n]) => [c, n, totalDe(c, montos)])).concat([["", "TOTAL GASTOS (21 a 29)", totalGeneral]]) }] })} />
          </View>
        </View>) : null}
    </View>);
}

/* Solicitudes de trabajo: por resolver (Jefe Adm., Cdte. o quien recibe) y enviadas por mí */
const EST_SOL = { pend_ja: "Esperando al Jefe Administrativo", pend_cdte: "Esperando al Comandante", pend_destino: "Esperando a quien la recibe", aprobada: "Aprobada y publicada", rechazada: "Rechazada" };
const paraSol = (d, s) => ((s.datos || {}).destinos || [s.destino]).map((x) => mname(d.members, x)).join(", ");
export function SolicitudesPanel({ d }) {
  const me = d.me || {}; const admin = me.role === "admin";
  const [sel, setSel] = useState(null);
  const sol = d.solicitudes || [];
  const porMi = sol.filter((s) => (s.estado === "pend_destino" && s.destino === me.id) || (s.estado === "pend_ja" && me.id === "m-passalacqua") || (s.estado === "pend_cdte" && admin));
  const mias = sol.filter((s) => s.solicitante === me.id).slice(0, 6);
  if (!porMi.length && !mias.length) return null;
  return (
    <View style={{ gap: 8 }}>
      {porMi.map((s) => (
        <Card key={s.id} tone="warn" onPress={() => setSel(s)}>
          <Text style={{ color: C.amberInk, fontWeight: "800", fontSize: 12 }}>{s.estado === "pend_destino" ? "TE ENVIARON UN TRABAJO · ACEPTA, MODIFICA, DERIVA O RECHAZA" : (s.datos || {}).destinos ? "POR APROBAR · DERIVAR / DELEGAR A " + s.datos.destinos.length + " RESPONSABLE" + (s.datos.destinos.length > 1 ? "S" : "") : "POR APROBAR · " + (s.tipo === "derivacion" ? "DERIVACIÓN" : "TAREA") + " A OTRA ORGANIZACIÓN"}</Text>
          <Text style={S.title}>{(s.datos || {}).title}</Text>
          <Text style={S.small}>De {mname(d.members, s.solicitante)} → para {paraSol(d, s)}{(s.datos || {}).due ? " · plazo " + fmt(new Date(s.datos.due).getTime()) : ""}{s.ja_por && s.estado === "pend_cdte" ? " · ✓ aprobada por el Jefe Adm." : ""}</Text>
        </Card>))}
      {mias.length ? <Card>
        <Text style={S.label}>Trabajos que enviaste</Text>
        {mias.map((s) => <Text key={s.id} style={[S.small, { color: s.estado === "rechazada" ? C.red : s.estado === "aprobada" ? C.accent : C.amberInk }]}>• {(s.datos || {}).title} → {paraSol(d, s)}: {EST_SOL[s.estado]}{s.motivo ? " (" + s.motivo + ")" : ""}</Text>)}
      </Card> : null}
      {sel ? <ResolverSolicitud d={d} s={sel} onClose={() => setSel(null)} /> : null}
    </View>);
}
function ResolverSolicitud({ d, s, onClose }) {
  const dat = s.datos || {};
  const [title, setTitle] = useState(dat.title || ""); const [dueS, setDueS] = useState(toInput(dat.due ? new Date(dat.due).getTime() : Date.now() + 3 * DAY));
  const [motivo, setMotivo] = useState(""); const [deriv, setDeriv] = useState(false); const [q, setQ] = useState(""); const [busy, setBusy] = useState(false);
  const esDestino = s.estado === "pend_destino";
  async function go(aprobar, derivarA) {
    if (!aprobar && !motivo.trim()) return Alert.alert("Indica el motivo del rechazo");
    const dd = fromInput(dueS); if (!dd) return Alert.alert("Plazo inválido", "Usa dd-mm-aaaa hh:mm");
    const cambios = {}; if (title.trim() && title.trim() !== dat.title) cambios.title = title.trim(); if (new Date(dd).toISOString() !== new Date(dat.due || 0).toISOString()) cambios.due = new Date(dd).toISOString();
    setBusy(true);
    const { data, error } = await supabase.rpc("resolver_solicitud", { p_id: s.id, p_aprobar: aprobar, p_motivo: motivo.trim(), p_datos: Object.keys(cambios).length ? cambios : null, p_derivar_a: derivarA || null });
    setBusy(false);
    if (error) return Alert.alert("No se pudo", errMsg(error));
    Alert.alert({ aprobada: derivarA ? "Derivada a " + mname(d.members, derivarA) : "Publicada", pend_cdte: "Aprobada: ahora la revisa el Comandante", rechazada: "Rechazada" }[data] || "Listo");
    onClose();
  }
  const cands = d.members.filter((m) => m.activo !== false && m.nivel !== "X" && !/WhatsApp/i.test(m.unit || "") && (!q || norm(m.name + " " + m.cargo + " " + m.unit).includes(norm(q)))).slice(0, q ? 25 : 10);
  return (
    <Sheet visible title={esDestino ? "Trabajo recibido" : "Aprobar trabajo a otra organización"} onClose={onClose}>
      <Card><Text style={S.small}>De: {mname(d.members, s.solicitante)}</Text><Text style={S.small}>Para: {paraSol(d, s)}</Text><Text style={S.small}>{dat.destinos ? "Derivar / delegar una tarea existente (el primero es el ejecutor)" : s.tipo === "derivacion" ? "Derivación de una tarea existente" : "Tarea nueva"} · {EST_SOL[s.estado]}</Text></Card>
      <Field label="Tarea (puedes modificarla)" value={title} onChangeText={setTitle} multiline />
      <Field label="Plazo (dd-mm-aaaa hh:mm)" value={dueS} onChangeText={setDueS} />
      <PlazoInhabil dueS={dueS} setDueS={setDueS} cfg={d.config} />
      {dat.evidencia ? <Text style={S.small}>Producto: {dat.evidencia}</Text> : null}
      <Btn title={busy ? "Guardando…" : esDestino ? "✓ Aceptar" : s.estado === "pend_ja" ? "✓ Aprobar y pasar al Comandante" : "✓ Aprobar y publicar"} kind="primary" disabled={busy} onPress={() => go(true)} />
      {esDestino ? <Btn title="↪ Derivar a otra persona" onPress={() => setDeriv(!deriv)} /> : null}
      {deriv ? <>
        <TextInput value={q} onChangeText={setQ} placeholder="Buscar persona" placeholderTextColor="#8A968F" style={{ minHeight: 44, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 12 }} />
        <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{cands.map((m) => <Chip key={m.id} label={m.name} onPress={() => go(true, m.id)} />)}</View>
      </> : null}
      <Field label="Motivo (para rechazar)" value={motivo} onChangeText={setMotivo} multiline />
      <Btn title="✕ Rechazar" kind="danger" disabled={busy} onPress={() => go(false)} />
    </Sheet>);
}

export function HoyAdmin({ d, open, ro }) {
  const [tfF, setTfF] = useState(null);
  const openT = d.tasks.filter((t) => !t.done);
  const over = openT.filter((t) => status(t) === "over");
  const pend = d.prorrogas.filter((p) => p.status === "pendiente");
  const load = {}; openT.forEach((t) => { if (due(t) >= Date.now() && due(t) <= Date.now() + 7 * DAY && t.member_id) load[t.member_id] = (load[t.member_id] || 0) + 1; });
  const heavy = Object.keys(load).sort((a, b) => load[b] - load[a]).find((k) => load[k] >= 3);
  const [arF, setArF] = useState(null);
  const grpOf = (t) => (areaInfo(t.area) || {}).group;
  const [vf, setVf] = useState("todas");
  const [rap, setRap] = useState(null);
  const base = vf === "cumplidas" ? d.tasks.filter((t) => t.done).sort((a, b) => new Date(b.done_at || 0) - new Date(a.done_at || 0)).slice(0, 80)
    : vf === "mias" ? openT.filter((t) => t.member_id === d.me.id || t.apoyo === d.me.id || t.delegado === d.me.id) : vf === "vencidas" ? openT.filter((t) => status(t) === "over") : openT;
  const seenG = new Set();
  const list = base.filter((t) => (!tfF || grpOf(t) === tfF) && (!arF || t.area === arF)).sort((a, b) => vf === "cumplidas" ? 0 : due(a) - due(b))
    .filter((t) => { if (!t.grupo) return true; if (seenG.has(t.grupo)) return false; seenG.add(t.grupo); return true; });
  if (rap) return (
    <View style={{ gap: 12 }}>
      <BotonesRapidos vista={rap} setVista={setRap} nPend={openT.length} nComp={d.tasks.length - openT.length} />
      <ListaRapida d={d} open={open} tasks={d.tasks} vista={rap} />
    </View>);
  return (
    <View style={{ gap: 12 }}>
      <BotonesRapidos vista={rap} setVista={setRap} nPend={openT.length} nComp={d.tasks.length - openT.length} />
      {openT.filter((t) => t.escalar).length ? <Card tone="inv"><Text style={{ color: C.invHi, fontWeight: "800", fontSize: 12 }}>REQUIEREN ESCALAMIENTO · {openT.filter((t) => t.escalar).length}</Text>{openT.filter((t) => t.escalar).map((t) => <Pressable key={t.id} onPress={() => open({ kind: "task", id: t.id })}><Text style={{ color: C.invFg, paddingVertical: 3 }}>• {t.title} · {mname(d.members, t.member_id)}</Text></Pressable>)}</Card> : null}
      {(d.avisos || []).filter((a) => !a.revisado).length ? (
        <Card tone="warn">
          <Between><Text style={[S.title, { flex: 1 }]}>Cambios hechos por integrantes sin tu autorización ({(d.avisos || []).filter((a) => !a.revisado).length})</Text></Between>
          {(d.avisos || []).filter((a) => !a.revisado).slice(0, 8).map((a) => (
            <Pressable key={a.id} onPress={() => { if (a.task_id && d.tasks.find((t) => t.id === a.task_id)) open({ kind: "task", id: a.task_id }); }}>
              <Text style={[S.small, { color: C.ink }]}><Text style={{ fontWeight: "800" }}>{mname(d.members, a.actor)}</Text> · {fmt(new Date(a.created_at).getTime())}</Text>
              <Text style={S.small}>“{a.titulo}”: {a.detalle}</Text>
            </Pressable>))}
          {ro ? null : <Btn small title="Marcar todo como revisado" onPress={() => run(() => supabase.from("avisos_admin").update({ revisado: true }).eq("revisado", false))} />}
        </Card>) : null}
      <Descargar titulo="Tareas ZB Arica" build={() => ({ hojas: [{ nombre: "Abiertas", filas: filasTareas(d, d.tasks.filter((t) => !t.done)) }, { nombre: "Vencidas", filas: filasTareas(d, d.tasks.filter((t) => !t.done && due(t) < Date.now())) }, { nombre: "Cumplidas", filas: filasTareas(d, d.tasks.filter((t) => t.done)) }] })} label="Tareas" />
      {(d.riesgos || []).filter((r) => !r.cierre && nivelR(r) === "ALTO").length ? <Note kind="bad" text={(d.riesgos || []).filter((r) => !r.cierre && nivelR(r) === "ALTO").length + " riesgo(s) ALTO abiertos · revisa la pestaña Control."} /> : null}
      {heavy ? (() => {
        const hm = member(d.members, heavy) || {};
        const lst = openT.filter((t) => t.member_id === heavy && due(t) >= Date.now() && due(t) <= Date.now() + 7 * DAY).sort((x, y) => due(x) - due(y));
        const cuerpo = "Usted tiene " + lst.length + " tareas por ejecutar en los próximos 7 días:\n\n" + lst.map((t, i) => (i + 1) + ". " + t.title + " (plazo " + fmt(due(t)) + ")").join("\n") + "\n\nFavor priorizar y actualizar el avance en Hito.";
        return (
          <Card tone="inv" onPress={ro ? undefined : () => open({ kind: "notificar", msg: { ids: [heavy], subject: "Hito ZB Arica · " + lst.length + " tareas por ejecutar en los próximos 7 días", body: cuerpo } })}>
            <Text style={{ color: C.invHi, fontWeight: "800", fontSize: 12 }}>ALERTA DE CARGA{ro ? "" : " · toca para avisarle"}</Text>
            <Text style={{ color: C.invFg }}>{hm.name || mname(d.members, heavy)} tiene {load[heavy]} plazos en los próximos 7 días.</Text>
            {!ro ? <Row style={{ flexWrap: "wrap", marginTop: 6 }}>
              <Btn small title="WhatsApp" kind="primary" onPress={() => openWa(hm.phone, firmaTexto(d, "Estimado " + (hm.name || "") + ":\n" + cuerpo))} />
              <Btn small title="Correo (Outlook)" onPress={() => notificarCorreo(d, [heavy], "Hito ZB Arica · " + lst.length + " tareas por ejecutar en los próximos 7 días", cuerpo)} />
            </Row> : null}
          </Card>);
      })() : null}
      <SolicitudesPanel d={d} />
      <Semaforo d={d} open={open} tasks={openT} />
      {(ro ? [] : pend).map((p) => { const t = d.tasks.find((x) => x.id === p.task_id); return t ? (
        <Card key={p.id} tone="warn" onPress={() => open({ kind: "decidir", p, t })}><Text style={{ color: C.amberInk, fontWeight: "800", fontSize: 12 }}>SOLICITUD DE PRÓRROGA</Text><Text style={S.title}>{mname(d.members, t.member_id)}: {t.title}</Text><Text style={S.small}>Pide hasta el {fmtDay(new Date(p.requested_due).getTime())} · {p.motivo}</Text></Card>) : null; })}
      {(ro ? [] : over).map((t) => (
        <Card key={t.id} tone="inv" onPress={() => open({ kind: "resolver", t })}>
          <Text style={{ color: C.invHi, fontWeight: "800", fontSize: 12 }}>TU TAREA · RESOLVER VENCIDA</Text>
          <Text style={{ color: C.invFg, fontWeight: "700" }}>{mname(d.members, t.member_id)}: ¿se presentó? ¿qué plazo le das?</Text>
          <Text style={{ color: C.invMuted, fontSize: 12 }}>“{t.title}” venció el {fmtDay(due(t))}{t.overdue_ack_at ? " · leyó el aviso" : ""}{t.no_shows ? " · no se presentó " + t.no_shows : ""}</Text>
        </Card>))}
      <Text style={S.h2}>Plazos del equipo</Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}><Chip label="Todas" on={!tfF} onPress={() => { setTfF(null); setArF(null); }} />{AREA_GROUPS.map(([k, n]) => <Chip key={k} label={n + " (" + openT.filter((t) => grpOf(t) === k).length + ")"} on={tfF === k} color={AREA_COLORS[k]} onPress={() => { setTfF(tfF === k ? null : k); setArF(null); }} />)}</View>
      {tfF ? <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{AREAS.filter((a) => a[2] === tfF).map((a) => <Chip key={a[0]} label={a[1] + " (" + openT.filter((t) => t.area === a[0]).length + ")"} on={arF === a[0]} color={AREA_COLORS[a[2]]} onPress={() => setArF(arF === a[0] ? null : a[0])} />)}</View> : null}
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{[["todas", "Todas"], ["mias", "Mías"], ["vencidas", "Vencidas"], ["cumplidas", "Cumplidas"]].map(([k, l]) => <Chip key={k} label={l} on={vf === k} onPress={() => setVf(k)} />)}</View>
      {list.length ? list.map((t) => t.grupo ? <GrupoCard key={t.id} t={t} d={d} onPress={() => open({ kind: "task", id: t.id })} /> : <TaskCard key={t.id} t={t} members={d.members} onPress={() => open({ kind: "task", id: t.id })} onEdit={esCreador(t, d) ? () => open({ kind: "corregir", t }) : null} />) : <Empty text={vf === "todas" ? "No hay tareas abiertas. Crea la primera con “+ Nueva tarea”." : "Nada en esta vista."} />}
    </View>
  );
}

/* Semáforo: tocar Vencidas / Próx. 48 h / En plazo agrupa esas tareas por área con fondo rojo, amarillo o verde */
const SEM = {
  over: { l: "Vencidas", f: "😟", c: C.red, bg: "#FBE4DA", bd: "#F2B8A6", ink: "#8A2A07" },
  soon: { l: "Próx. 48 h", f: "😐", c: C.amber, bg: "#FFF4D6", bd: "#F2D58A", ink: "#7A4A12" },
  ok: { l: "En plazo", f: "😊", c: C.accent, bg: "#E3F1E8", bd: "#B5D8C2", ink: "#1F5D4C" },
};
export function Semaforo({ d, open, tasks }) {
  const [sel, setSel] = useState(null);
  const by = (k) => tasks.filter((t) => status(t) === k).sort((a, b) => due(a) - due(b));
  const lst = sel ? by(sel) : [];
  const grupos = [];
  lst.forEach((t) => { const n = (areaInfo(t.area) || {}).name || "Sin área"; let g = grupos.find((x) => x.n === n); if (!g) { g = { n, items: [] }; grupos.push(g); } g.items.push(t); });
  return (
    <View style={{ gap: 8 }}>
      <Row>
        {Object.keys(SEM).map((k) => {
          const on = sel === k; const n = by(k).length;
          return (
            <Pressable key={k} accessibilityRole="button" onPress={() => setSel(on ? null : k)} style={{ flex: 1, gap: 2, padding: 14, borderRadius: 16, borderWidth: 1, backgroundColor: on ? SEM[k].c : SEM[k].bg, borderColor: on ? SEM[k].c : SEM[k].bd }}>
              <Text style={{ fontSize: 24, fontWeight: "800", color: on ? "#fff" : SEM[k].c }}>{SEM[k].f} {n}</Text>
              <Text style={[S.small, { color: on ? "#fff" : SEM[k].ink, fontWeight: "700" }]}>{SEM[k].l}{on ? " ▲" : " ▼"}</Text>
            </Pressable>);
        })}
      </Row>
      {sel ? (
        <View style={{ gap: 6 }}>
          <Text style={[S.small, { color: SEM[sel].ink, fontWeight: "800" }]}>{SEM[sel].l.toUpperCase()} · {lst.length} tarea(s){grupos.length > 1 ? " en " + grupos.length + " áreas" : ""} · toca de nuevo para cerrar</Text>
          {!lst.length ? <Empty text="No hay tareas en este grupo." /> : null}
          {grupos.map((g) => (
            <View key={g.n} style={{ gap: 6 }}>
              <Text style={{ fontSize: 12, fontWeight: "800", color: SEM[sel].ink, marginTop: 4 }}>{g.n.toUpperCase()} ({g.items.length})</Text>
              {g.items.map((t) => (
                <Card key={t.id} onPress={() => open({ kind: "task", id: t.id })} style={{ backgroundColor: SEM[sel].bg, borderColor: SEM[sel].bd, gap: 2 }}>
                  <Text style={[S.title, { color: SEM[sel].ink }]}>{SEM[sel].f} {t.title}</Text>
                  <Text style={[S.small, { color: SEM[sel].ink }]}>{mname(d.members, t.member_id)} · {sel === "over" ? "venció " : "plazo "}{fmt(due(t))} · {t.progress || 0}%</Text>
                </Card>))}
            </View>))}
        </View>
      ) : null}
    </View>
  );
}

export function MisTareas({ d, open }) {
  const mine = d.tasks.filter((t) => d.me && (t.member_id === d.me.id || t.apoyo === d.me.id || t.delegado === d.me.id || (t.participantes || []).includes(d.me.id)));
  const openT = mine.filter((t) => !t.done), done = mine.filter((t) => t.done).slice(-10).reverse();
  const over = openT.filter((t) => status(t) === "over");
  const [rap, setRap] = useState(null);
  if (rap) return (
    <View style={{ gap: 12 }}>
      <BotonesRapidos vista={rap} setVista={setRap} nPend={openT.length} nComp={mine.length - openT.length} />
      <ListaRapida d={d} open={open} tasks={mine} vista={rap} />
    </View>);
  return (
    <View style={{ gap: 12 }}>
      <BotonesRapidos vista={rap} setVista={setRap} nPend={openT.length} nComp={mine.length - openT.length} />
      <SolicitudesPanel d={d} />
      <Semaforo d={d} open={open} tasks={openT} />
      {over.map((t) => (
        <Card key={t.id} tone="inv" onPress={() => open({ kind: "task", id: t.id })}>
          <Text style={{ color: C.invHi, fontWeight: "800", fontSize: 12 }}>TAREA VENCIDA · PRESÉNTATE EN LA OFICINA</Text>
          <Text style={{ color: C.invFg, fontWeight: "700" }}>{t.title}</Text>
          <Text style={{ color: C.invMuted, fontSize: 12 }}>Venció el {fmt(due(t))}. Debes explicar al Comandante por qué no se cumplió.</Text>
        </Card>))}
      <Text style={S.h2}>Mis tareas</Text>
      <Descargar titulo={"Mis tareas " + ((d.me && d.me.name) || "")} build={() => ({ hojas: [{ nombre: "Mis tareas", filas: filasTareas(d, mine) }] })} />
      {openT.filter((t) => status(t) !== "over").map((t) => <TaskCard key={t.id} t={t} members={d.members} onPress={() => open({ kind: "task", id: t.id })} onEdit={esCreador(t, d) ? () => open({ kind: "corregir", t }) : null} />)}
      {!openT.length ? <Empty text="No tienes tareas abiertas." /> : null}
      {done.length ? <><Text style={S.h2}>Cumplidas recientemente</Text>{done.map((t) => <TaskCard key={t.id} t={t} members={d.members} onPress={() => open({ kind: "task", id: t.id })} onEdit={esCreador(t, d) ? () => open({ kind: "corregir", t }) : null} />)}</> : null}
      <Card>
        <Text style={S.title}>¿No vas a estar?</Text>
        <Text style={S.small}>Avisa feriado, permiso, comisión, curso o licencia por días o semanas completas. Queda en el parte de fuerza y le llega al Comandante.</Text>
        <Btn title="Avisar que no estaré" kind="primary" onPress={() => open({ kind: "ausencia" })} />
        {(d.novedades || []).filter((n) => d.me && n.member_id === d.me.id && n.hasta >= isoDay(startOfDay(Date.now()))).map((n) => (
          <Between key={n.id}><Text style={[S.small, { flex: 1 }]}>{n.motivo} · {n.desde.split("-").reverse().join("-")} al {n.hasta.split("-").reverse().join("-")}</Text>
            <Pressable onPress={() => run(() => supabase.from("novedades").delete().eq("id", n.id), "Aviso retirado")}><Text style={{ color: C.red, fontSize: 12, padding: 4 }}>Quitar</Text></Pressable></Between>))}
      </Card>
    </View>
  );
}

const MESES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
const DOW = ["L", "M", "M", "J", "V", "S", "D"];
function addMonths(ms, n) { const d = new Date(ms); const day = d.getDate(); const r = new Date(d.getFullYear(), d.getMonth() + n, 1); r.setDate(Math.min(day, new Date(r.getFullYear(), r.getMonth() + 1, 0).getDate())); return startOfDay(r.getTime()); }
function monthGrid(y, m) { const first = new Date(y, m, 1).getTime(); const st = weekStart(first); return [...Array(42)].map((_, i) => addDays(st, i)); }

export function Calendario({ d, open, isAdmin }) {
  const [vista, setVista] = useState("mes");
  const [day, setDay] = useState(startOfDay(Date.now()));
  const today = startOfDay(Date.now());
  const meId = d.me && d.me.id;
  const tasks = d.tasks; // la base ya entrega solo lo visible para cada persona (su organización)
  const cnt = useMemo(() => {
    const m = {};
    tasks.forEach((t) => { const k = startOfDay(due(t)); const c = m[k] || (m[k] = { t: 0, e: 0, v: 0 }); c.t++; if (!t.done && status(t) === "over") c.v++; });
    d.events.forEach((e) => { const k = startOfDay(new Date(e.at).getTime()); (m[k] || (m[k] = { t: 0, e: 0, v: 0 })).e++; });
    return m;
  }, [d.tasks, d.events, isAdmin, meId]);
  const sel = day;
  const dt = new Date(day); const Y = dt.getFullYear(), MO = dt.getMonth();
  const ws = weekStart(day);
  const days = [...Array(7)].map((_, i) => addDays(ws, i));
  const step = (n) => setDay(vista === "semana" ? addDays(day, 7 * n) : vista === "mes" ? addMonths(day, n) : addMonths(day, 12 * n));
  const titulo = vista === "semana" ? fmtDay(ws) + " – " + fmtDay(addDays(ws, 6)) : vista === "mes" ? MESES[MO] + " " + Y : String(Y);
  const items = tasks.filter((t) => startOfDay(due(t)) === sel).map((t) => ({ k: "t", at: due(t), o: t }))
    .concat(d.events.filter((e) => startOfDay(new Date(e.at).getTime()) === sel).map((e) => ({ k: "e", at: new Date(e.at).getTime(), o: e }))).sort((a, b) => a.at - b.at);
  async function delEvent(e) { await run(() => supabase.from("events").delete().eq("id", e.id), "Evento eliminado"); }
  const heat = (c) => !c ? "transparent" : c.v ? C.redSoft : c.t >= 3 ? "#BFD6CB" : c.t ? C.accentSoft : C.blueSoft;
  return (
    <View style={{ gap: 12 }}>
      <Row style={{ flexWrap: "wrap" }}>
        <Chips options={[["mes", "📅 Mes"], ["semana", "Semana"], ["anio", "Año"]]} value={vista} onChange={setVista} />
        <Btn small title="Hoy" onPress={() => setDay(today)} />
      </Row>
      <Between><Btn small title="‹" onPress={() => step(-1)} /><Text style={S.h2}>{titulo}</Text><Btn small title="›" onPress={() => step(1)} /></Between>
      {vista === "semana" ? (
        <Row style={{ gap: 4 }}>
          {days.map((x) => {
            const on = x === sel; const c = cnt[x];
            return (
              <Pressable key={x} onPress={() => setDay(x)} style={{ flex: 1, minHeight: 62, borderRadius: 12, backgroundColor: on ? C.inv : C.surface, borderWidth: x === today && !on ? 1 : 0, borderColor: C.accent, alignItems: "center", justifyContent: "center" }}>
                <Text style={{ fontSize: 11, color: on ? C.invFg : C.muted }}>{DOW[(new Date(x).getDay() + 6) % 7]}</Text>
                <Text style={{ fontSize: 17, fontWeight: "700", color: on ? C.invFg : C.ink }}>{new Date(x).getDate()}</Text>
                <Row style={{ gap: 3 }}><View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: c && c.t ? (c.v ? C.red : C.accent) : "transparent" }} /><View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: c && c.e ? C.blue : "transparent" }} /></Row>
              </Pressable>);
          })}
        </Row>
      ) : vista === "mes" ? (
        <View style={{ backgroundColor: C.surface, borderRadius: 14, borderWidth: 1, borderColor: C.line, padding: 6 }}>
          <Row style={{ gap: 2 }}>{DOW.map((x, i) => <Text key={i} style={{ flex: 1, textAlign: "center", fontSize: 11, color: C.muted, fontWeight: "700" }}>{x}</Text>)}</Row>
          {[0, 1, 2, 3, 4, 5].map((w) => (
            <Row key={w} style={{ gap: 2, marginTop: 2 }}>
              {monthGrid(Y, MO).slice(w * 7, w * 7 + 7).map((x) => {
                const inM = new Date(x).getMonth() === MO; const on = x === sel; const c = cnt[x];
                return (
                  <Pressable key={x} onPress={() => setDay(x)} style={{ flex: 1, minHeight: 54, borderRadius: 8, padding: 3, backgroundColor: on ? C.inv : heat(c), borderWidth: x === today && !on ? 1.5 : 0, borderColor: C.accent, opacity: inM ? 1 : 0.35 }}>
                    <Text style={{ fontSize: 12, fontWeight: "700", color: on ? C.invFg : C.ink }}>{new Date(x).getDate()}</Text>
                    {c && c.t ? <Text style={{ fontSize: 10, fontWeight: "800", color: on ? C.invFg : c.v ? C.redInk : C.accent }}>{c.t} tarea{c.t > 1 ? "s" : ""}</Text> : null}
                    {c && c.e ? <Text style={{ fontSize: 10, color: on ? C.invFg : C.blueInk }}>{c.e} ev.</Text> : null}
                  </Pressable>);
              })}
            </Row>))}
          <Text style={[S.small, { marginTop: 6 }]}>Verde: plazos · rojo: hay vencidas · azul: solo eventos. Toca un día para ver el detalle.</Text>
        </View>
      ) : (
        <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", rowGap: 10 }}>
          {MESES.map((mn, mi) => {
            const tot = Object.keys(cnt).filter((k) => { const x = new Date(Number(k)); return x.getFullYear() === Y && x.getMonth() === mi; }).reduce((a, k) => a + cnt[k].t, 0);
            return (
              <View key={mi} style={{ width: "48.5%", backgroundColor: C.surface, borderRadius: 12, borderWidth: 1, borderColor: mi === new Date(today).getMonth() && Y === new Date(today).getFullYear() ? C.accent : C.line, padding: 6 }}>
                <Pressable onPress={() => { setDay(startOfDay(new Date(Y, mi, 1).getTime())); setVista("mes"); }}>
                  <Between><Text style={{ fontWeight: "800", color: C.ink, fontSize: 13 }}>{mn}</Text><Text style={{ fontSize: 10, color: C.muted }}>{tot ? tot + " plazos" : ""}</Text></Between>
                </Pressable>
                {[0, 1, 2, 3, 4, 5].map((w) => (
                  <Row key={w} style={{ gap: 1 }}>
                    {monthGrid(Y, mi).slice(w * 7, w * 7 + 7).map((x) => {
                      const inM = new Date(x).getMonth() === mi; const c = inM ? cnt[x] : null;
                      return (
                        <Pressable key={x} disabled={!inM} onPress={() => { setDay(x); setVista("mes"); }} style={{ flex: 1, height: 18, borderRadius: 4, alignItems: "center", justifyContent: "center", backgroundColor: x === today ? C.inv : heat(c) }}>
                          <Text style={{ fontSize: 9, color: !inM ? "transparent" : x === today ? C.invFg : C.ink }}>{new Date(x).getDate()}</Text>
                        </Pressable>);
                    })}
                  </Row>))}
              </View>);
          })}
        </View>
      )}
      {vista !== "anio" ? <Text style={S.h2}>{fmtDay(sel)}</Text> : null}
      {vista === "anio" ? <Note kind="info" text="Toca un mes o un día para abrirlo en la vista Mes." /> : items.length ? items.map((it) => it.k === "t" ? (
        <Card key={it.o.id} onPress={() => open({ kind: "task", id: it.o.id })} style={areaColor(it.o) ? { borderLeftWidth: 6, borderLeftColor: areaColor(it.o) } : null}><Row><Text style={S.small}>{fmtTime(it.at)}</Text><Badge text="TAREA" />{areaInfo(it.o.area) ? <Text style={{ fontSize: 11, fontWeight: "800", color: areaColor(it.o) }}>{areaInfo(it.o.area).name}</Text> : null}</Row><Text style={S.title}>{it.o.title}</Text><Text style={S.small}>{mname(d.members, it.o.member_id)}{it.o.apoyo ? " + " + mname(d.members, it.o.apoyo) : ""} · {it.o.tf}{it.o.proc ? " · " + it.o.proc : ""}</Text>{esCreador(it.o, d) ? <Row><Btn small title="✏️ Corregir texto" onPress={() => open({ kind: "corregir", t: it.o })} />{isAdmin ? <Btn small title="Editar / cambiar responsable" onPress={() => open({ kind: "taskForm", t: it.o })} /> : null}</Row> : null}</Card>
      ) : (
        <Card key={it.o.id} tone="event"><Row><Text style={S.small}>{(it.o.type || "").toLowerCase() === "cumpleaños" || (it.o.title || "").startsWith("🎂") ? "Todo el día" : fmtTime(it.at)}</Text><Badge kind="event" text="EVENTO" /><Text style={{ color: C.blueInk, fontSize: 12 }}>{it.o.type}</Text></Row>
          <Text style={S.title}>{it.o.title}</Text>{it.o.detail ? <Text style={S.body}>{it.o.detail}</Text> : null}
          {it.o.responsable ? <Text style={[S.small, { fontWeight: "700", color: C.blueInk }]}>Responsable: {mname(d.members, it.o.responsable)}</Text> : null}
          {(it.o.participantes || []).length ? <Text style={S.small}>Participantes: {it.o.participantes.map((x) => mname(d.members, x)).join(", ")}</Text> : null}
          <Between><Text style={S.small}>Anotado por {mname(d.members, it.o.by_member)}</Text>{isAdmin || it.o.by_member === (d.me && d.me.id) ? <Row><Btn small title="Editar" onPress={() => open({ kind: "event", e: it.o })} /><Btn small title="Notificar" onPress={() => open({ kind: "notificar", msg: msgEvento(d, it.o) })} /><Btn small title="Eliminar" onPress={() => delEvent(it.o)} /></Row> : null}</Between></Card>
      )) : <Empty text="Sin plazos ni eventos este día." />}
      <Btn title="+ Anotar evento" kind="blue" onPress={() => open({ kind: "event" })} />
      <SyncCal />
    </View>
  );
}

// Enlace secreto .ics para suscribirse desde Google Calendar u Outlook (se actualiza solo)
function SyncCal() {
  const [show, setShow] = useState(false); const [tk, setTk] = useState(null); const [busy, setBusy] = useState(false);
  const link = tk ? SUPABASE_URL + "/functions/v1/calendario?t=" + tk : "";
  async function get(renovar) {
    setBusy(true);
    const { data, error } = await supabase.rpc("mi_token_calendario", { renovar: !!renovar });
    setBusy(false);
    if (error || !data) return Alert.alert("No se pudo obtener el enlace", error ? errMsg(error) : "Intenta de nuevo.");
    setTk(data);
  }
  async function share() {
    if (Platform.OS === "web" && navigator.clipboard) { try { await navigator.clipboard.writeText(link); return Alert.alert("Enlace copiado", "Pégalo en Google Calendar u Outlook."); } catch (e) {} }
    Share.share({ message: link });
  }
  if (!show) return <Card onPress={() => { setShow(true); if (!tk) get(false); }}><Text style={S.title}>Sincronizar con Google Calendar / Outlook</Text><Text style={S.small}>Tus plazos y los eventos aparecen en tu calendario y se actualizan solos.</Text></Card>;
  return (
    <Card>
      <Text style={S.title}>Sincronizar con Google Calendar / Outlook</Text>
      <Text style={S.small}>Este es tu enlace personal. No lo compartas: quien lo tenga ve tus plazos. Si se filtra, renuévalo.</Text>
      <Text selectable style={{ fontSize: 12, color: C.ink, backgroundColor: C.surface2, padding: 8, borderRadius: 8 }}>{busy ? "Generando…" : link || "—"}</Text>
      {link ? <Btn title="Copiar / compartir enlace" kind="primary" onPress={share} /> : null}
      <Text style={S.label}>Google Calendar (desde un computador)</Text>
      <Text style={S.small}>Copia el enlace → abre Google Calendar → “Otros calendarios +” → “Desde URL” → pega y “Añadir calendario”. Luego aparece también en la app de Google Calendar del celular.</Text>
      <Btn small title="Abrir Google Calendar (agregar por URL)" onPress={() => Linking.openURL("https://calendar.google.com/calendar/r/settings/addbyurl")} />
      <Text style={S.label}>Outlook</Text>
      <Text style={S.small}>Copia el enlace → Outlook Calendario → “Agregar calendario” → “Suscribirse desde la web” → pega, ponle nombre “Hito” e importa.</Text>
      <Btn small title="Abrir Outlook (suscribirse desde la web)" onPress={() => Linking.openURL("https://outlook.office.com/calendar/addcalendar")} />
      <Text style={S.small}>Google y Outlook revisan el enlace cada algunas horas; los cambios no son instantáneos. Para avisos al minuto usa los avisos de la app.</Text>
      <Btn small title="Renovar enlace (el anterior deja de funcionar)" onPress={() => Alert.alert("Renovar enlace", "El enlace anterior dejará de funcionar y tendrás que suscribirte de nuevo.", [{ text: "Cancelar", style: "cancel" }, { text: "Renovar", onPress: () => get(true) }])} />
    </Card>
  );
}

export function Mural({ d, isAdmin, open }) {
  const [cat, setCat] = useState("todo");
  const [vista, setVista] = useState("avisos");
  const list = d.posts.filter((p) => cat === "todo" || p.cat === cat).sort((a, b) => (b.pinned - a.pinned) || (new Date(b.created_at) - new Date(a.created_at)));
  const selector = <Chips options={[["avisos", "Avisos"], ["glosario", "📖 Glosario"]]} value={vista} onChange={setVista} />;
  if (vista === "glosario") return <View style={{ gap: 12 }}>{selector}<Glosario d={d} isAdmin={isAdmin} /></View>;
  return (
    <View style={{ gap: 12 }}>
      {selector}
      <Btn title="+ Nuevo aviso" kind="primary" onPress={() => open({ kind: "post" })} />
      <Chips options={[["todo", "Todo"]].concat(CATS)} value={cat} onChange={setCat} />
      {list.length ? list.map((p) => (
        <Card key={p.id} tone={p.pinned ? "warn" : undefined}>
          <Between><Text style={{ fontSize: 11, fontWeight: "800", color: p.pinned ? C.red : C.accent }}>{(p.pinned ? "FIJADO · " : "") + ((CATS.find((c) => c[0] === p.cat) || [, "Aviso"])[1]).toUpperCase()}</Text><Text style={S.small}>{fmtDay(new Date(p.created_at).getTime())}</Text></Between>
          <Text style={S.title}>{p.title}</Text>{p.body ? <Text style={S.body}>{p.body}</Text> : null}
          {p.autor ? <Text style={S.small}>Publicado por {mname(d.members, p.autor)}</Text> : null}
          {!isAdmin && p.autor && d.me && p.autor === d.me.id ? <Row><Btn small title="Eliminar" kind="danger" onPress={() => run(() => supabase.from("posts").delete().eq("id", p.id))} /></Row> : null}
          {isAdmin ? <Row><Btn small title={p.pinned ? "Desfijar" : "Fijar"} onPress={() => run(() => supabase.from("posts").update({ pinned: !p.pinned }).eq("id", p.id))} /><Btn small title="Eliminar" kind="danger" onPress={() => run(() => supabase.from("posts").delete().eq("id", p.id))} /></Row> : null}
        </Card>)) : <Empty text="No hay avisos en el mural." />}
    </View>
  );
}

export function Equipo({ d, open, isAdmin }) {
  const [tab, setTab] = useState("personas"); const [q, setQ] = useState(""); const [openU, setOpenU] = useState({}); const [profile, setProfile] = useState(null); const [profileEditor, setProfileEditor] = useState(null); const canEditProfiles = !!(d.me && (d.me.role === "admin" || d.me.id === "m-perez"));
  const [ccPick, setCcPick] = useState(null); const [ccQuery, setCcQuery] = useState("");
  const [saldoPick, setSaldoPick] = useState(null); const [saldoDraft, setSaldoDraft] = useState("");
  const canEditCcOwners = !!(d.me && d.me.role === "admin");
  const canEditBalances = !!(d.me && (d.me.role === "admin" || norm(d.me.cargo || "") === norm("Oficial de finanzas")));
  const currentMembers = d.members.filter((m) => m.activo !== false);
  const people = veTodo(d) || (d.me && d.me.id === "m-viviana-urrutia-salinas") ? currentMembers : currentMembers.filter((m) => UNIT_AREA[m.parte_unit || m.unit] === miArea(d));
  const units = []; people.forEach((m) => { if (!units.includes(m.unit || "")) units.push(m.unit || ""); });
  const qq = norm(q);
  const [sinTel, setSinTel] = useState(false); const [sinMail, setSinMail] = useState(false);
  const list = people.filter((m) => (!qq || norm(m.name + " " + m.cargo + " " + m.unit).includes(qq)) && (!sinTel || !m.phone) && (!sinMail || !m.email));
  async function setOwner(code, id) {
    const o = { ...(d.config.owners || {}), [code]: id };
    await run(() => supabase.from("config").upsert({ key: "owners", value: o }), "Responsable de " + code + " actualizado");
  }
  const ccKey = (c) => String(c.codigo) + "|" + String(c.centro);
  async function setCcOwner(c, id) {
    const owners = { ...(d.config.cc_owners || {}), [ccKey(c)]: id };
    if (await run(() => supabase.from("config").upsert({ key: "cc_owners", value: owners }), "Responsable actualizado")) setCcPick(null);
  }
  async function saveCcBalance(c) {
    const raw = saldoDraft.trim().replace(/[. ]/g, "");
    if (!raw || [...raw].some((ch) => ch < "0" || ch > "9")) { Alert.alert("Monto inválido", "Ingresa el saldo disponible en pesos, usando solo números."); return; }
    const result = await run(() => supabase.rpc("actualizar_saldo_disponible", { p_cc_key: ccKey(c), p_monto: Number(raw) }), "Saldo disponible actualizado");
    if (result) setSaldoPick(null);
  }
  const fmtSaldo = (amount) => new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(Number(amount) || 0);
  const [pick, setPick] = useState(null); const [pq, setPq] = useState("");
  return (
    <View style={{ gap: 12 }}>
      <Chips options={[["personas", "Personas"], ["procesos", "Procesos"], ["cc", "Centros de costo"], ["saldo", "Saldo disponible"]]} value={tab} onChange={setTab} />
      {tab === "personas" ? (
        <>
          <Card tone="inv">
            <Text style={{ color: C.invFg, fontWeight: "800", fontSize: 15 }}>Dependencia y puestos de trabajo</Text>
            <Text style={{ color: C.invMuted, marginTop: 6 }}>Jefatura Administrativa → Oficina de Operaciones: {mname(d.members, "m-urquieta")} · puesto principal.</Text>
            <Text style={{ color: C.invMuted, marginTop: 4 }}>OCGR: {mname(d.members, "m-barbara-llancavil-cortez")} a cargo; {mname(d.members, "m-urquieta")} cumple apoyo secundario.</Text>
          </Card>
          <TextInput value={q} onChangeText={setQ} placeholder="Buscar por nombre, cargo o unidad" placeholderTextColor="#8A968F" style={{ minHeight: 46, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 14 }} />
          {isAdmin || (d.me && d.me.role === "admin") ? <Btn title="＋ Agregar integrante" kind="primary" onPress={() => open({ kind: "member", m: { nuevo: true } })} /> : null}
          <DescargarDescriptores d={d} />
          <Text style={S.small}>{currentMembers.length} integrantes · {currentMembers.filter((m) => m.phone).length} con WhatsApp · {currentMembers.filter((m) => m.user_id).length} con acceso</Text>
          <Row><Chip label={"Sin teléfono (" + currentMembers.filter((m) => !m.phone && m.nivel !== "X").length + ")"} on={sinTel} onPress={() => setSinTel(!sinTel)} /><Chip label={"Sin correo (" + currentMembers.filter((m) => !m.email && m.nivel !== "X").length + ")"} on={sinMail} onPress={() => setSinMail(!sinMail)} /></Row>
          {sinTel || sinMail ? <Note kind="info" text="Toca a una persona para agregarle su número o correo; queda disponible para WhatsApp y avisos por correo." /> : null}
          {units.map((u) => { const ms = list.filter((m) => (m.unit || "") === u); if (!ms.length) return null; const isOpen = !!qq || sinTel || sinMail || openU[u];
            return (
              <Card key={u} style={{ padding: 0, gap: 0 }}>
                <Pressable onPress={() => setOpenU({ ...openU, [u]: !openU[u] })} style={{ padding: 14 }}><Between><Text style={[S.title, { flex: 1 }]}>{u || "Sin unidad"}</Text><Text style={S.small}>{ms.length} pers. {isOpen ? "▲" : "▼"}</Text></Between></Pressable>
                {isOpen ? ms.map((m) => (
                  <View key={m.id} style={{ paddingHorizontal: 14, paddingVertical: 10, borderTopWidth: 1, borderColor: C.line, flexDirection: "row", alignItems: "center", gap: 10 }}>
                    <Pressable onPress={() => open({ kind: "member", m })} style={{ flexDirection: "row", alignItems: "center", gap: 10, flex: 1 }}>
                      <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: C.accentSoft, alignItems: "center", justifyContent: "center" }}><Text style={{ color: C.accent, fontWeight: "800", fontSize: 12 }}>{initials(m.name)}</Text></View>
                      <Text numberOfLines={2} style={{ fontWeight: "700", color: C.ink, flex: 1 }}>{m.name}</Text>
                    </Pressable>
                    <Pressable onPress={() => { setProfile({ cargo: m.cargo, unit: m.unit, definition: perfilCargo(m, d.profiles || []) }); setProfileEditor(null); }} accessibilityRole="button" accessibilityLabel={"Ver perfil de cargo de " + (m.cargo || m.name)} style={{ flex: 1, paddingVertical: 4 }}>
                      <Text numberOfLines={2} style={[S.small, { color: C.accent, textDecorationLine: "underline" }]}>{m.cargo || "Ver perfil del cargo"}</Text>
                    </Pressable>
                    <Text style={S.small}>{m.user_id ? "● app" : m.phone ? "WA" : "sin n.º"}</Text>
                  </View>)) : null}
              </Card>); })}
        </>
      ) : tab === "procesos" ? (
        <>
          {isAdmin ? <Note kind="info" text="Cada proceso tiene un responsable; las tareas nuevas de ese proceso se le asignan. Toca un proceso para cambiarlo." /> : <Note kind="info" text="Consulta los responsables y diagramas de los procesos." />}
          <Card onPress={() => Linking.openURL("https://mapa-procesos-zb-arica-2026.sergiocerda22.chatgpt.site")}>
            <Text style={S.title}>Mapa de procesos ZB Arica 2026 (consulta)</Text>
            <Text style={S.small}>Mapa general, inventario de procesos y trazabilidad con la TD 2026. Abre en el navegador. Referencial: no reemplaza procedimientos firmados ni la validación del CORI.</Text>
          </Card>
          {TFK.map((k) => (
            <View key={k} style={{ gap: 8 }}>
              <Row><TfTag tf={k} /><Text style={S.h2}>{TF[k].short}</Text></Row>
              {TF[k].procs.map((p) => { const pi = procInfo(p[0], d.config.owners);
                return (
                  <Card key={p[0]} onPress={isAdmin ? () => { setPick(p[0]); setPq(""); } : undefined}>
                    <Text style={S.title}>{(p[0].includes("-") ? p[0] + " · " : "") + p[1]}</Text>
                    {p[3].length ? <Text style={S.small}>{p[3].join(" → ")}</Text> : null}
                    {flujo(p[0]) ? <Text style={S.small}>{flujo(p[0]).pasos.length} pasos · {flujo(p[0]).pasos.filter((x) => x.pc).length} puntos de control</Text> : null}
                    {tieneDiagrama(p[0]) ? <Pressable onPress={() => verDiagrama(p[0])}><Text style={{ color: C.accent, fontWeight: "800", paddingVertical: 2 }}>Ver diagrama</Text></Pressable> : null}
                    <Between><Text style={S.small}>Responsable: {mname(d.members, pi.owner)}</Text>{pi.owner !== pi.defOwner ? <Badge kind="soon" text="CAMBIADO" /> : null}</Between>
                    {isAdmin && pick === p[0] ? (
                      <View style={{ gap: 8 }}>
                        <TextInput value={pq} onChangeText={setPq} placeholder="Buscar nuevo responsable" placeholderTextColor="#8A968F" style={{ minHeight: 42, borderRadius: 10, borderWidth: 1, borderColor: C.line2, paddingHorizontal: 10 }} />
                        <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{d.members.filter((m) => m.activo !== false && pq && norm(m.name + " " + m.cargo).includes(norm(pq))).slice(0, 12).map((m) => <Chip key={m.id} label={m.name} onPress={() => { setOwner(p[0], m.id); setPick(null); }} />)}</View>
                      </View>) : null}
                  </Card>); })}
            </View>))}
        </>
      ) : tab === "cc" ? (
        <>
          <Note kind="info" text="Toca “Cambiar responsable” para actualizar quién está a cargo de cada centro de costo." />
          {((d.config.zona && d.config.zona.cc) || []).map((c) => {
            const key = ccKey(c);
            const ownerId = (d.config.cc_owners || {})[key];
            const ownerName = ownerId ? mname(d.members, ownerId) : c.responsable || "Sin asignar";
            const editing = ccPick === key;
            return (
              <Card key={key}>
                <Between><Text style={[S.title, { flex: 1 }]}>{c.centro}</Text><Text style={S.small}>{c.codigo}</Text></Between>
                <Text style={S.small}>Responsable: {ownerName}</Text>
                {canEditCcOwners ? editing ? (
                  <View style={{ gap: 6 }}>
                    <TextInput value={ccQuery} onChangeText={setCcQuery} placeholder="Buscar nuevo responsable" placeholderTextColor="#8A968F" style={{ minHeight: 42, borderRadius: 10, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 10 }} />
                    <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                      {d.members.filter((m) => m.activo !== false && m.nivel !== "X" && ccQuery && norm(m.name + " " + m.cargo + " " + m.unit).includes(norm(ccQuery))).slice(0, 15).map((m) => <Chip key={m.id} label={m.name} on={ownerId === m.id} onPress={() => setCcOwner(c, m.id)} />)}
                    </View>
                    <Btn small title="Cancelar" onPress={() => setCcPick(null)} />
                  </View>
                ) : <Btn small title="Cambiar responsable" onPress={() => { setCcPick(key); setCcQuery(""); }} /> : null}
              </Card>
            );
          })}
        </>
      ) : (
        <>
          <Note kind="info" text="El saldo disponible se comparte con el equipo. Solo el Oficial de Finanzas y el Comandante pueden actualizarlo." />
          {((d.config.zona && d.config.zona.cc) || []).map((c) => {
            const key = ccKey(c);
            const saldo = (d.config.saldos_disponibles || {})[key];
            const editing = saldoPick === key;
            return (
              <Card key={key}>
                <Between><Text style={[S.title, { flex: 1 }]}>{c.centro}</Text><Text style={S.small}>{c.codigo}</Text></Between>
                <Text style={{ fontSize: 17, fontWeight: "800", color: C.accent, marginTop: 4 }}>Saldo disponible: {saldo && saldo.monto !== null && saldo.monto !== undefined ? fmtSaldo(saldo.monto) : "Sin registrar"}</Text>
                {saldo && saldo.actualizado_en ? <Text style={S.small}>Actualizado {fmtDay(new Date(saldo.actualizado_en).getTime())}{saldo.actualizado_por ? " por " + mname(d.members, saldo.actualizado_por) : ""}</Text> : null}
                {canEditBalances ? editing ? (
                  <View style={{ gap: 6 }}>
                    <TextInput value={saldoDraft} onChangeText={setSaldoDraft} placeholder="Monto en pesos (CLP)" placeholderTextColor="#8A968F" keyboardType="numeric" style={{ minHeight: 44, borderRadius: 10, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 12 }} />
                    <Row><Btn small title="Guardar saldo" kind="primary" onPress={() => saveCcBalance(c)} /><Btn small title="Cancelar" onPress={() => setSaldoPick(null)} /></Row>
                  </View>
                ) : <Btn small title={saldo ? "Actualizar saldo" : "Ingresar saldo"} onPress={() => { setSaldoDraft(saldo && saldo.monto !== undefined ? String(saldo.monto) : ""); setSaldoPick(key); }} /> : null}
                <Catalogo d={d} ccKey={key} nombre={c.centro} />
              </Card>
            );
          })}
        </>
      )}
      {profile ? (
        <Sheet visible title={profileEditor ? "Completar perfil de cargo" : (profile.definition ? profile.definition.title : "Perfil del cargo")} onClose={() => { setProfile(null); setProfileEditor(null); }}>
          {profileEditor ? (
            <>
              <Card>
                <Text style={S.title}>{profileEditor.cargo || "Cargo sin identificar"}</Text>
                <Text style={S.small}>Perfil asociado al puesto</Text>
              </Card>
              <Field label="Nombre del perfil" value={profileEditor.title} onChangeText={(title) => setProfileEditor((x) => ({ ...x, title }))} placeholder="Ej.: JEFE DE SECCIÓN" />
              {profileEditor.sections.map((section, index) => (
                <View key={section.heading} style={{ gap: 6 }}>
                  <Text style={S.label}>{section.heading.toUpperCase()}</Text>
                  <TextInput
                    value={section.text}
                    onChangeText={(value) => setProfileEditor((x) => ({ ...x, sections: x.sections.map((item, i) => i === index ? { ...item, text: value } : item) }))}
                    multiline
                    textAlignVertical="top"
                    placeholder={"Escribe aquí: " + section.heading}
                    placeholderTextColor="#8A968F"
                    style={{ minHeight: 90, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, padding: 12, color: C.ink }}
                  />
                </View>
              ))}
              <Row>
                <Btn title="Guardar perfil" kind="primary" style={{ flex: 1 }} onPress={async () => {
                  if (!profileEditor.title.trim()) { Alert.alert("Falta el nombre", "Escribe el nombre del perfil."); return; }
                  const cargo = (profileEditor.cargo || "").trim();
                  const definition = { cargo_key: profileEditor.unit ? norm(cargo).trim() + "::" + norm(profileEditor.unit).trim() : norm(cargo), cargo, title: profileEditor.title.trim(), sections: profileEditor.sections, updated_by: d.me.id, updated_at: new Date().toISOString() };
                  if (await run(() => supabase.from("position_profiles").upsert(definition, { onConflict: "cargo_key" }), "Perfil de cargo guardado.")) {
                    setProfile({ cargo, unit: profileEditor.unit, definition: { ...definition, manual: true } });
                    setProfileEditor(null);
                  }
                }} />
                <Btn title="Cancelar" style={{ flex: 1 }} onPress={() => setProfileEditor(null)} />
              </Row>
            </>
          ) : (
            <>
              <Card>
                <Text style={S.title}>{profile.cargo || "Cargo sin identificar"}</Text>
                <Text style={S.small}>Perfil asociado al puesto</Text>
              </Card>
              {profile.definition ? <DescargarDescriptores d={d} profile={profile} /> : null}
              {profile.definition ? profile.definition.sections.map((section, index) => (
                <View key={section.heading + index} style={{ gap: 6 }}>
                  <Text style={S.label}>{section.heading.toUpperCase()}</Text>
                  <Text style={S.body}>{section.text}</Text>
                </View>
              )) : (
                <>
                  <Note kind="info" text={canEditProfiles ? "Este cargo aún no tiene perfil. Puedes escribirlo aquí manualmente." : "Aún no hay un perfil asociado a este cargo."} />
                  {canEditProfiles ? <Btn title="Agregar perfil manualmente" kind="primary" onPress={() => setProfileEditor({ cargo: profile.cargo || "", unit: profile.unit || "", title: profile.cargo || "", sections: PERFIL_SECTION_LABELS.map((heading) => ({ heading, text: "" })) })} /> : null}
                </>
              )}
              {canEditProfiles && profile.definition && profile.definition.manual ? <Btn title="Editar perfil manual" onPress={() => setProfileEditor({ cargo: profile.cargo || "", unit: profile.unit || "", title: profile.definition.title, sections: [...new Set([...(profile.definition.sections || []).map(section => section.heading), ...PERFIL_SECTION_LABELS])].map((heading) => ({ heading, text: ((profile.definition.sections || []).find((section) => section.heading === heading) || {}).text || "" })) })} /> : null}
            </>
          )}
        </Sheet>
      ) : null}
    </View>
  );
}

export function Notas({ d }) {
  const [per, setPer] = useState("w"); const [off, setOff] = useState(0);
  let s, e, label;
  if (per === "w") { s = addDays(weekStart(Date.now()), off * 7); e = addDays(s, 7); label = fmtDay(s) + " – " + fmtDay(addDays(e, -1)); }
  else { const x = new Date(); const a = new Date(x.getFullYear(), x.getMonth() + off, 1); s = a.getTime(); e = new Date(a.getFullYear(), a.getMonth() + 1, 1).getTime(); label = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"][a.getMonth()] + " " + a.getFullYear(); }
  const ev = d.tasks.filter((t) => due(t) >= s && due(t) < e && (t.done || due(t) < Date.now()));
  const okT = ev.filter(onTime).length; const g = grade(okT, ev.length);
  const rows = d.members.filter((m) => m.activo !== false).map((m) => { const mine = ev.filter((t) => t.member_id === m.id); const ok = mine.filter(onTime).length; return { m, tot: mine.length, ok, g: grade(ok, mine.length) }; }).filter((r) => r.tot).sort((a, b) => b.g - a.g);
  const gc = (x) => x == null ? [C.surface2, C.muted] : x >= 5.5 ? [C.accent, "#fff"] : x >= 4 ? [C.amberSoft, C.amberInk] : [C.red, "#fff"];
  // Racha: semanas seguidas (hasta la semana mostrada) con todas las tareas cumplidas a tiempo
  const finRef = per === "w" ? s : addDays(weekStart(e - 1), 0);
  const racha = (id) => {
    let n = 0;
    for (let k = 0; k < 26; k++) {
      const ws = addDays(finRef, -7 * k), we = addDays(ws, 7);
      const mine = d.tasks.filter((t) => t.member_id === id && due(t) >= ws && due(t) < we && (t.done || due(t) < Date.now()));
      if (!mine.length) { if (k === 0) continue; break; }
      if (mine.every(onTime)) n++; else break;
    }
    return n;
  };
  rows.forEach((r) => { r.perfecto = r.tot > 0 && r.ok === r.tot; r.racha = racha(r.m.id); });
  const estrella = rows.filter((r) => r.perfecto).sort((a, b) => b.ok - a.ok || b.racha - a.racha)[0];
  const nPerf = rows.filter((r) => r.perfecto).length;
  return (
    <View style={{ gap: 12 }}>
      <Chips options={[["w", "Semana"], ["m", "Mes"]]} value={per} onChange={(k) => { setPer(k); setOff(0); }} />
      <Between><Btn small title="‹" onPress={() => setOff(off - 1)} /><Text style={S.h2}>{label}</Text><Btn small title="›" disabled={off >= 0} onPress={() => setOff(off + 1)} /></Between>
      <Card tone="inv" style={{ flexDirection: "row", alignItems: "center", gap: 16 }}>
        <Text style={{ fontSize: 42, fontWeight: "800", color: C.invFg }}>{gfmt(g)}</Text>
        <View style={{ flex: 1 }}><Text style={{ color: C.invFg, fontWeight: "700" }}>Nota del equipo</Text><Text style={{ color: C.invMuted }}>{ev.length ? okT + " de " + ev.length + " tareas cumplidas a tiempo" : "Sin tareas evaluables en este periodo"}</Text></View>
      </Card>
      {rows.length ? <Card style={{ backgroundColor: "#FFF8E1", borderColor: "#F2D58A" }}>
        <Text style={{ fontWeight: "800", color: "#7A4A12" }}>{per === "w" ? "Esta semana" : "Este mes"}: 😊😊 {nPerf} cumplieron todo · 😟😟 {rows.length - nPerf} quedaron debiendo</Text>
        {estrella ? <Text style={{ marginTop: 4, color: "#7A4A12" }}>⭐ Estrella {per === "w" ? "de la semana" : "del mes"}: <Text style={{ fontWeight: "800" }}>{estrella.m.name}</Text> ({estrella.ok} tareas a tiempo{estrella.racha > 1 ? " · 🔥 " + estrella.racha + " semanas seguidas" : ""})</Text> : null}
      </Card> : null}
      {rows.map((r) => (
        <Card key={r.m.id} style={{ flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: r.perfecto ? "#E3F1E8" : "#FBE4DA", borderColor: r.perfecto ? "#B5D8C2" : "#F2B8A6" }}>
          <Text style={{ fontSize: 26 }}>{r.perfecto ? "😊😊" : "😟😟"}</Text>
          <View style={{ flex: 1 }}><Text style={S.title}>{estrella && estrella.m.id === r.m.id ? "⭐ " : ""}{r.m.name}</Text>{r.racha > 1 ? <Text style={{ fontSize: 12, fontWeight: "800", color: "#B4380A" }}>🔥 {r.racha} semanas seguidas cumpliendo todo</Text> : null}<Text style={S.small}>{r.ok} de {r.tot} a tiempo · {Math.round(100 * r.ok / r.tot)}%</Text></View>
          <View style={{ backgroundColor: gc(r.g)[0], borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6 }}><Text style={{ color: gc(r.g)[1], fontSize: 18, fontWeight: "800" }}>{gfmt(r.g)}</Text></View>
        </Card>))}
      <Note text="😊😊 cumplió todas sus tareas a tiempo · 😟😟 dejó alguna atrasada o sin cumplir · 🔥 semanas seguidas cumpliendo todo · ⭐ quien más tareas cumplió a tiempo sin fallar. Nota = 1,0 + 6,0 × % de tareas cumplidas a tiempo. Con prórroga aprobada cuenta la nueva fecha; una tarea resuelta tras citación cuenta como atrasada." />
    </View>
  );
}

/* ================= Asistente IA (solo Comandante) ================= */
export function Asistente({ d }) {
  const [msgs, setMsgs] = useState([]);
  const [txt, setTxt] = useState("");
  const [busy, setBusy] = useState(false);
  const procs = useMemo(() => {
    const out = [];
    TFK.forEach((k) => TF[k].procs.forEach((p) => { const i = procInfo(p[0], d.config.owners); out.push({ code: i.code, tf: i.tf, name: i.name, owner: i.owner, stages: i.stages }); }));
    return out;
  }, [d.config.owners]);
  async function send(q) {
    const text = (q || txt).trim();
    if (!text || busy) return;
    const next = msgs.concat([{ role: "user", content: text }]);
    setMsgs(next); setTxt(""); setBusy(true);
    const { data, error } = await supabase.functions.invoke("asistente", { body: { messages: next.filter((m) => m.role !== "info"), procs } });
    let reply = "";
    if (error) reply = "No pude conectar con el asistente. " + (error.message || "");
    else if (data && data.error) reply = data.error;
    else reply = (data && data.text) || "Listo.";
    const add = [{ role: "assistant", content: reply }];
    if (data && data.actions && data.actions.length) add.push({ role: "info", content: "Hecho: " + data.actions.join(" · ") });
    setMsgs(next.concat(add)); setBusy(false);
  }
  const ideas = d.me && d.me.role !== "admin" ? ["¿Qué tareas tengo pendientes y cuándo vencen?", "Hazme un cuadro con mis tareas por plazo", "Ayúdame a redactar el informe de avance de mi tarea más próxima"] : ["¿Qué tareas están vencidas y de quién?", "Hazme un cuadro de cumplimiento por área", "Crea una tarea para el responsable de Habitacional: informe mensual de mantenimiento, plazo el viernes 12:00", "Publica en el mural que el lunes hay formación a las 08:00", "Resume el estado de la Zona esta semana"];
  return (
    <>
      <Note kind="info" text={d.me && d.me.role === "admin" ? "Puede consultar, crear tareas, cambiar plazos, anotar eventos y publicar en el mural. Pídele cuadros y descárgalos en Excel, Word o PPT." : "Consulta tus tareas, pide ayuda para redactar o planificar y pide cuadros para descargar. Si cambias una tarea, el Comandante recibe un aviso."} />
      {msgs.length === 0 ? ideas.map((q) => (
        <Pressable key={q} onPress={() => send(q)}><Card><Text style={S.body}>{q}</Text></Card></Pressable>
      )) : null}
      {msgs.map((m, i) => (
        <View key={i} style={{ alignSelf: m.role === "user" ? "flex-end" : "stretch", maxWidth: m.role === "user" ? "85%" : "100%", backgroundColor: m.role === "user" ? C.accent : m.role === "info" ? C.accentSoft : C.surface, borderRadius: 14, padding: 12, borderWidth: m.role === "assistant" ? 1 : 0, borderColor: C.line }}>
          <Text selectable style={{ color: m.role === "user" ? "#fff" : C.ink, fontSize: 15, lineHeight: 21 }}>{m.content}</Text>
        </View>
      ))}
      {busy ? <Text style={S.small}>Pensando…</Text> : null}
      <Field label="Pídele algo al asistente" value={txt} onChangeText={setTxt} multiline placeholder="Escribe o dicta tu pedido… Ej.: “Crea tres tareas: …”" />
      <Dictar label="Dictar al asistente (micrófono)" onText={(t) => setTxt((x) => (x ? x + " " : "") + t)} />
      <Btn title={busy ? "Un momento…" : "Enviar"} kind="primary" disabled={busy || !txt.trim()} onPress={() => send()} />
      {msgs.some((m) => m.role === "assistant") ? <Descargar titulo="Asistente Hito" label="Descargar respuesta" build={() => {
        const last = msgs.filter((m) => m.role === "assistant").slice(-1)[0] || { content: "" };
        const tabs = tablasDeTexto(last.content);
        return { notas: tabs.length ? "" : last.content, hojas: tabs.length ? tabs : [{ nombre: "Conversación", filas: [["Quién", "Mensaje"]].concat(msgs.filter((m) => m.role !== "info").map((m) => [m.role === "user" ? "Yo" : "Asistente", m.content])) }] };
      }} /> : null}
      {msgs.length ? <Btn title="Nueva conversación" onPress={() => setMsgs([])} /> : null}
    </>
  );
}

/* ================= Parte de fuerza (Comandante) ================= */
const PF_COLS = [{ n: "Permiso", forma: false }, { n: "Feriado", forma: false }, { n: "Licencia médica", forma: false }, { n: "Comisión", forma: false }, { n: "Curso", forma: false }];
const SALIDAS = ["Traslado", "Retiro", "Término de contrato", "Otro"];
const OFS = ["GDB", "CRL", "TCL", "MAY", "CAP", "TTE", "STE", "ALF", "SBTE"];
const CPS = ["SOM", "SOF", "SG1", "SG2", "CB1", "CB2", "CBO"];
function categoria(m) {
  const g = (m.grado || String(m.name || "").split(/\s+/)[0] || "").toUpperCase();
  if (OFS.includes(g)) return "OF"; if (CPS.includes(g)) return "CP"; if (g === "SLC" || g === "SLD") return "TR"; return "EC";
}
const CATS_PF = [["OF", "Oficiales"], ["CP", "Cuadro Permanente"], ["TR", "Tropa"], ["EC", "Empleados civiles y honorarios"]];
const isoDay = (ms) => new Date(ms - new Date(ms).getTimezoneOffset() * 60000).toISOString().slice(0, 10);
export function inParte(m, fecha) {
  if (m.activo === false) return false;
  const on = m.parte === null || m.parte === undefined ? m.nivel !== "X" : m.parte;
  return on && (!m.parte_desde || m.parte_desde <= fecha) && (!m.parte_hasta || fecha < m.parte_hasta);
}
// Ven toda la Zona (en modo consulta): Jefe Administrativo, SOF Azócar y SG1 Urquieta. Solo el Comandante (admin) modifica.
export const SUPERVISORES = ["m-passalacqua", "m-azocar", "m-urquieta"];
export const veTodo = (d) => !!d.me && (d.me.role === "admin" || SUPERVISORES.includes(d.me.id));
export const miArea = (d) => (d.me ? UNIT_AREA[d.me.parte_unit || d.me.unit] || null : null);
// Pueden ver y modificar el parte completo: Cdte, Jefe Administrativo, Sra. Viviana Urrutia, SOF Pérez y SOF Azócar.
export const JEFES_PARTE = ["m-cerda", "m-passalacqua", "m-viviana-urrutia-salinas", "m-perez", "m-azocar"];
// Jefes de sección: controlan el parte de su gente (sus áreas).
export function areasJefe(d) {
  if (!d.me) return [];
  const a = AREAS.filter((x) => x[3] === d.me.id).map((x) => x[0]);
  if (a.includes("REC")) a.push("CRA", "COEM");
  if (a.includes("ASI")) a.push("JI");
  return [...new Set(a)];
}
export const puedeParte = (d) => !!d.me && (d.me.role === "admin" || JEFES_PARTE.includes(d.me.id) || SUPERVISORES.includes(d.me.id));

/* Integrante: solo marca su propio Sí / No */
function MiParte({ d }) {
  const hoy = isoDay(startOfDay(Date.now()));
  const cols = (d.config.parte_cols && d.config.parte_cols.length ? d.config.parte_cols : PF_COLS);
  const [local, setLocal] = useState(null);
  const me = d.me;
  const rec = local || (d.parte || []).find((p) => p.fecha === hoy && p.member_id === me.id) || null;
  const nov = (d.novedades || []).find((n) => n.member_id === me.id && n.desde <= hoy && hoy <= n.hasta);
  async function mark(forma, motivo) {
    const row = { fecha: hoy, member_id: me.id, forma, motivo: motivo || "", by_member: me.id, updated_at: new Date().toISOString() };
    setLocal(row);
    const { error } = await supabase.from("parte_fuerza").upsert(row, { onConflict: "fecha,member_id" });
    if (error) { setLocal(null); Alert.alert("No se pudo guardar", errMsg(error)); }
  }
  return (
    <View style={{ gap: 12 }}>
      <Text style={[S.h2, { textTransform: "capitalize" }]}>{fmtDay(Date.now())}</Text>
      <Card>
        <Text style={S.title}>{me.name}</Text>
        <Text style={S.small}>{me.cargo}</Text>
        <Text style={[S.label, { marginTop: 6 }]}>¿Formas hoy?</Text>
        <Row>
          <Pressable onPress={() => mark(true, "")} style={{ flex: 1, alignItems: "center", paddingVertical: 14, borderRadius: 12, backgroundColor: rec && rec.forma === true ? C.accent : C.surface2 }}><Text style={{ fontWeight: "800", fontSize: 18, color: rec && rec.forma === true ? "#fff" : C.ink2 }}>Sí</Text></Pressable>
          <Pressable onPress={() => mark(false, rec && !rec.forma ? rec.motivo : "")} style={{ flex: 1, alignItems: "center", paddingVertical: 14, borderRadius: 12, backgroundColor: rec && rec.forma === false ? C.red : C.surface2 }}><Text style={{ fontWeight: "800", fontSize: 18, color: rec && rec.forma === false ? "#fff" : C.ink2 }}>No</Text></Pressable>
        </Row>
        {rec && rec.forma === false ? <><Text style={S.label}>Motivo</Text><View style={{ flexDirection: "row", flexWrap: "wrap" }}>{cols.map((c) => <Chip key={c.n} label={c.n} on={rec.motivo === c.n} color={c.forma ? C.accent : C.red} onPress={() => mark(!!c.forma, c.n)} />)}</View></> : null}
        {rec ? <Note text={"Registrado: " + (rec.forma ? "formas" : "no formas" + (rec.motivo ? " (" + rec.motivo + ")" : "")) + ". El mando ya lo ve en el parte."} /> : nov ? <Note kind="info" text={"Tienes una novedad registrada: " + nov.motivo + ". Si hoy sí formas, marca Sí."} /> : <Note kind="warn" text="Aún no marcas el parte de hoy." />}
      </Card>
      <Note kind="info" text="Solo puedes marcar tu propio parte. Para ausencias de varios días usa “Avisar que no estaré” en Mis tareas." />
    </View>);
}

export function ParteFuerza({ d }) {
  const [vista, setVista] = useState("diario");
  // Las áreas que controla el jefe de sección las confirma la base de datos (si aún no está habilitado, ve solo su parte)
  const [secDb, setSecDb] = useState([]);
  useEffect(() => { if (puedeParte(d) || !areasJefe(d).length) return; supabase.rpc("mis_areas_jefe").then(({ data, error }) => setSecDb(!error && Array.isArray(data) ? data : [])); }, [d.me && d.me.id]);
  if (!puedeParte(d)) {
    const sec = secDb;
    if (!sec.length) return <MiParte d={d} />;
    return <><Chips options={[["diario", "Parte de mi sección"], ["mio", "Mi parte"]]} value={vista === "mio" ? "mio" : "diario"} onChange={setVista} />{vista === "mio" ? <MiParte d={d} /> : <ParteDiario d={d} sec={sec} />}</>;
  }
  const cols0 = (d.config.parte_cols && d.config.parte_cols.length ? d.config.parte_cols : PF_COLS);
  if (vista === "mensual") return <><Chips options={[["diario", "Parte diario"], ["mensual", "Asistencia mensual"]]} value={vista} onChange={setVista} /><ParteMensual d={d} cols={cols0} /></>;
  return <><Chips options={[["diario", "Parte diario"], ["mensual", "Asistencia mensual"]]} value={vista} onChange={setVista} /><ParteDiario d={d} /></>;
}
function ParteDiario({ d, sec }) {
  const [day, setDay] = useState(startOfDay(Date.now()));
  const [open, setOpen] = useState({});
  const [saving, setSaving] = useState(false);
  const [local, setLocal] = useState({});
  const [sheet, setSheet] = useState(null);
  const fecha = isoDay(day);
  const cols = (d.config.parte_cols && d.config.parte_cols.length ? d.config.parte_cols : PF_COLS);
  const colOf = (n) => cols.find((c) => c.n === n);
  const [filtroFuerza, setFiltroFuerza] = useState("todos");
  const soloMil = filtroFuerza === "militares";
  const soloCiv = filtroFuerza === "civiles";
  const people = d.members.filter((m) => inParte(m, fecha) && (filtroFuerza === "todos" || (soloMil ? categoria(m) !== "EC" : categoria(m) === "EC")) && (!sec || sec.includes(UNIT_AREA[m.parte_unit || m.unit])));
  const uof = (m) => m.parte_unit || m.unit;
  const rec = {}; (d.parte || []).filter((p) => p.fecha === fecha).forEach((p) => (rec[p.member_id] = p));
  const nov = {}; (d.novedades || []).filter((n) => n.desde <= fecha && fecha <= n.hasta).forEach((n) => (nov[n.member_id] = n));
  const val = (id) => {
    if (local[fecha + id] !== undefined) return local[fecha + id];
    if (rec[id]) return rec[id];
    if (nov[id]) { const c = colOf(nov[id].motivo); return { forma: c ? !!c.forma : false, motivo: nov[id].motivo, auto: true }; }
    return null;
  };
  const stat = (list) => { let f = 0, x = 0; list.forEach((m) => { const v = val(m.id); if (v && v.forma) f++; else if (v && v.forma === false) x++; }); return { t: list.length, f, x, s: list.length - f - x }; };
  const tot = stat(people);
  const unitOrder = {}; d.members.forEach((m) => { if (unitOrder[m.unit] === undefined || m.unit_order < unitOrder[m.unit]) unitOrder[m.unit] = m.unit_order; });
  const units = [];
  people.forEach((m) => { let u = units.find((x) => x.unit === uof(m)); if (!u) units.push((u = { unit: uof(m), list: [] })); u.list.push(m); });
  units.sort((a, b) => (unitOrder[a.unit] ?? 50) - (unitOrder[b.unit] ?? 50));
  const motCount = {}; people.forEach((m) => { const v = val(m.id); if (v && v.motivo) motCount[v.motivo] = (motCount[v.motivo] || 0) + 1; });
  async function mark(m, forma, motivo) {
    const row = { fecha, member_id: m.id, forma, motivo: motivo || "", by_member: d.me.id, updated_at: new Date().toISOString() };
    setLocal((x) => ({ ...x, [fecha + m.id]: row }));
    const { error } = await supabase.from("parte_fuerza").upsert(row, { onConflict: "fecha,member_id" });
    if (error) Alert.alert("No se pudo guardar", errMsg(error));
  }
  async function todosForman() {
    const rows = people.filter((m) => !val(m.id)).map((m) => ({ fecha, member_id: m.id, forma: true, motivo: "", by_member: d.me.id, updated_at: new Date().toISOString() }));
    if (!rows.length) return;
    setSaving(true);
    const add = {}; rows.forEach((r) => (add[fecha + r.member_id] = r)); setLocal((x) => ({ ...x, ...add }));
    const { error } = await supabase.from("parte_fuerza").upsert(rows, { onConflict: "fecha,member_id" });
    setSaving(false);
    if (error) Alert.alert("No se pudo guardar", errMsg(error));
  }
  function enviar() {
    const lines = ["PARTE DE FUERZA · ZB ARICA" + (soloMil ? " · SOLO MILITARES" : soloCiv ? " · SOLO CIVILES" : ""), fmtDay(day).toUpperCase(), "", (soloCiv ? "CIVILES " : "FUERZA ") + tot.t + " · FORMAN " + tot.f + " · FALTAN " + tot.x + (tot.s ? " · SIN REGISTRO " + tot.s : ""), ""];
    CATS_PF.forEach(([k, n]) => { const st = stat(people.filter((m) => categoria(m) === k)); if (st.t) lines.push(n + ": " + st.t + " / " + st.f + " / " + st.x); });
    if (Object.keys(motCount).length) { lines.push("", "NOVEDADES"); Object.entries(motCount).forEach(([k, n]) => lines.push("• " + k + ": " + n)); }
    const falt = people.filter((m) => { const v = val(m.id); return v && (v.forma === false || v.motivo); });
    if (falt.length) { lines.push(""); falt.forEach((m) => lines.push("- " + m.name + " (" + (val(m.id).motivo || "sin motivo") + ")")); }
    Share.share({ message: lines.join("\n") }).catch(() => {});
  }
  const Box = ({ l, n, c }) => (
    <View style={{ flex: 1, backgroundColor: C.surface, borderRadius: 14, borderWidth: 1, borderColor: C.line, padding: 12, alignItems: "center" }}>
      <Text style={{ fontSize: 12, fontWeight: "800", color: C.muted, letterSpacing: 0.6 }}>{l}</Text>
      <Text style={{ fontSize: 30, fontWeight: "800", color: c }}>{n}</Text>
    </View>);
  const cell = { width: 62, textAlign: "center", fontSize: 13, color: C.ink };
  return (
    <>
      <Between>
        <Btn small title="‹ Anterior" onPress={() => setDay(addDays(day, -1))} />
        <Text style={[S.h2, { textTransform: "capitalize", flex: 1, textAlign: "center" }]}>{fmtDay(day)}</Text>
        <Btn small title="Siguiente ›" onPress={() => setDay(addDays(day, 1))} />
      </Between>
      <Chips options={[["todos", "Todos"], ["militares", "Solo militares"], ["civiles", "Solo civiles"]]} value={filtroFuerza} onChange={setFiltroFuerza} />
      {soloMil || soloCiv ? <Btn title={soloMil ? "Enviar parte militares" : "Enviar parte civiles"} kind="primary" onPress={enviar} /> : null}
      {soloMil ? <Note kind="info" text="Mostrando solo Oficiales, Cuadro Permanente y Tropa. Los empleados civiles y honorarios quedan ocultos y fuera del total." /> : soloCiv ? <Note kind="info" text="Mostrando solo Empleados civiles y honorarios. El personal militar queda oculto y fuera del total." /> : null}
      <Row><Box l={soloMil ? "FUERZA MIL." : soloCiv ? "CIVILES" : "FUERZA"} n={tot.t} c={C.ink} /><Box l="FORMAN" n={tot.f} c={C.accent} /><Box l="FALTAN" n={tot.x} c={C.red} /></Row>
      {tot.s ? <Note kind="warn" text={tot.s + " sin registrar todavía."} /> : <Note text="Parte completo." />}
      <Card>
        <Text style={S.label}>Por categoría</Text>
        <Row><Text style={[S.small, { flex: 1 }]}> </Text><Text style={[cell, S.small]}>Fuerza</Text><Text style={[cell, S.small]}>Forman</Text><Text style={[cell, S.small]}>Faltan</Text></Row>
        {CATS_PF.map(([k, n]) => { const st = stat(people.filter((m) => categoria(m) === k)); return st.t ? (
          <Row key={k}><Text style={{ flex: 1, color: C.ink, fontSize: 13 }}>{n}</Text><Text style={cell}>{st.t}</Text><Text style={[cell, { color: C.accent }]}>{st.f}</Text><Text style={[cell, { color: C.red }]}>{st.x}</Text></Row>) : null; })}
        <Row><Text style={{ flex: 1, fontWeight: "800", color: C.ink }}>Total</Text><Text style={[cell, { fontWeight: "800" }]}>{tot.t}</Text><Text style={[cell, { fontWeight: "800", color: C.accent }]}>{tot.f}</Text><Text style={[cell, { fontWeight: "800", color: C.red }]}>{tot.x}</Text></Row>
      </Card>
      <Card>
        <Between><Text style={S.label}>Novedades</Text>{sec ? null : <Btn small title="+ Columna" onPress={() => setSheet({ k: "col" })} />}</Between>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <Row>
            {cols.map((c) => (
              <View key={c.n} style={{ minWidth: 86, padding: 8, borderRadius: 10, backgroundColor: c.forma ? C.accentSoft : C.redSoft, alignItems: "center", marginRight: 6 }}>
                <Text style={{ fontSize: 11, fontWeight: "700", color: C.ink2 }} numberOfLines={1}>{c.n}</Text>
                <Text style={{ fontSize: 22, fontWeight: "800", color: c.forma ? C.accent : C.red }}>{motCount[c.n] || 0}</Text>
                <Text style={{ fontSize: 10, color: C.muted }}>{c.forma ? "cuenta forma" : "cuenta falta"}</Text>
              </View>))}
          </Row>
        </ScrollView>
        <Row><Btn small title="+ Novedad con fechas" onPress={() => setSheet({ k: "nov" })} /><Btn small title="Enviar parte" kind="primary" onPress={enviar} /></Row>
        {(d.novedades || []).filter((n) => n.hasta >= fecha).slice(0, 30).map((n) => (
          <Between key={n.id}><Text style={[S.small, { flex: 1 }]}>{mname(d.members, n.member_id)} · {n.motivo} · {n.desde.split("-").reverse().join("-")} al {n.hasta.split("-").reverse().join("-")}</Text>
            <Pressable onPress={() => run(() => supabase.from("novedades").delete().eq("id", n.id))}><Text style={{ color: C.red, fontSize: 12, padding: 4 }}>Quitar</Text></Pressable></Between>))}
      </Card>
      {tot.s ? <Btn title={saving ? "Guardando…" : "Marcar el resto como “forma”"} onPress={todosForman} disabled={saving} /> : null}
      {units.map((u) => {
        const st = stat(u.list);
        const isOpen = open[u.unit] !== false;
        return (
          <Card key={u.unit}>
            <Between>
              <Pressable style={{ flex: 1 }} onPress={() => setOpen((o) => ({ ...o, [u.unit]: !isOpen }))}>
                <Text style={S.title}>{u.unit} {isOpen ? "▾" : "▸"}</Text>
                <Text style={S.small}>Fuerza {st.t} · forman {st.f} · faltan {st.x}</Text>
              </Pressable>
              {sec ? null : <Pressable onPress={() => setSheet({ k: "add", unit: u.unit })} style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: C.accent, alignItems: "center", justifyContent: "center" }}><Text style={{ color: "#fff", fontSize: 22, fontWeight: "800" }}>+</Text></Pressable>}
            </Between>
            {isOpen ? u.list.map((m) => {
              const v = val(m.id);
              return (
                <View key={m.id} style={{ borderTopWidth: 1, borderColor: C.line, paddingTop: 8, gap: 6 }}>
                  <Between>
                    <Pressable style={{ flex: 1 }} onLongPress={sec ? undefined : () => setSheet({ k: "out", m })}>
                      <Text style={{ color: C.ink, fontSize: 15 }}>{m.name}</Text>
                      <Text style={S.small}>{m.cargo}{m.parte_unit && m.parte_unit !== m.unit ? " · agregado" : ""}{v && v.auto ? " · " + v.motivo + " (novedad)" : ""}</Text>
                      {rec[m.id] && rec[m.id].by_member === m.id ? <Text style={{ fontSize: 12, fontWeight: "800", color: C.accent }}>✓ Se reportó él mismo · {new Date(rec[m.id].updated_at).toLocaleTimeString("es-CL", { hour: "2-digit", minute: "2-digit" })}</Text> : null}
                    </Pressable>
                    <Row>
                      <Pressable onPress={() => mark(m, true)} style={{ paddingHorizontal: 13, paddingVertical: 8, borderRadius: 10, backgroundColor: v && v.forma === true ? C.accent : C.surface2 }}><Text style={{ fontWeight: "800", color: v && v.forma === true ? "#fff" : C.ink2 }}>Sí</Text></Pressable>
                      <Pressable onPress={() => mark(m, false, v && !v.forma ? v.motivo : "")} style={{ paddingHorizontal: 13, paddingVertical: 8, borderRadius: 10, backgroundColor: v && v.forma === false ? C.red : C.surface2 }}><Text style={{ fontWeight: "800", color: v && v.forma === false ? "#fff" : C.ink2 }}>No</Text></Pressable>
                      {sec ? null : <Pressable onPress={() => setSheet({ k: "out", m })} style={{ paddingHorizontal: 8, paddingVertical: 8 }}><Text style={{ fontSize: 18, color: C.muted }}>⋯</Text></Pressable>}
                    </Row>
                  </Between>
                  {v && (v.forma === false || v.motivo) ? <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{cols.map((c) => <Chip key={c.n} label={c.n} on={v.motivo === c.n} color={c.forma ? C.accent : C.red} onPress={() => mark(m, !!c.forma, c.n)} />)}</View> : null}
                </View>);
            }) : null}
          </Card>);
      })}
      {sheet && sheet.k === "add" ? <PfAgregar d={d} unit={sheet.unit} fecha={fecha} onClose={() => setSheet(null)} /> : null}
      {sheet && sheet.k === "out" ? <PfQuitar m={sheet.m} fecha={fecha} onClose={() => setSheet(null)} /> : null}
      {sheet && sheet.k === "col" ? <PfColumna d={d} cols={cols} onClose={() => setSheet(null)} /> : null}
      {sheet && sheet.k === "nov" ? <PfNovedad d={d} cols={cols} fecha={fecha} onClose={() => setSheet(null)} /> : null}
    </>
  );
}

function PfAgregar({ d, unit, fecha, onClose }) {
  const [q, setQ] = useState("");
  const [nuevo, setNuevo] = useState(false);
  const [name, setName] = useState(""); const [cargo, setCargo] = useState(""); const [phone, setPhone] = useState("");
  const cands = d.members.filter((m) => m.activo !== false && (!inParte(m, fecha) || (m.parte_unit || m.unit) !== unit)).filter((m) => !q || norm(m.name + " " + m.cargo + " " + m.unit).includes(norm(q))).slice(0, 25);
  async function agregar(m) {
    const body = { parte: true, parte_unit: unit === m.unit ? null : unit, parte_desde: inParte(m, fecha) ? m.parte_desde : fecha, parte_hasta: null, salida_motivo: "" };
    if (await run(() => supabase.from("members").update(body).eq("id", m.id), m.name + " agregado al parte")) onClose();
  }
  async function crear() {
    if (!name.trim()) return Alert.alert("Escribe el nombre con grado, por ejemplo: SG2 Juan Pérez Soto");
    const ref = d.members.find((m) => m.unit === unit) || {};
    const id = "m-" + norm(name).replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) + "-" + Math.random().toString(36).slice(2, 5);
    const body = { id, name: name.trim(), grado: name.trim().split(/\s+/)[0].toUpperCase(), cargo: cargo.trim(), unit, unit_order: ref.unit_order ?? 50, nivel: ref.nivel || "C", phone: phone.trim(), parte: true, parte_desde: fecha };
    if (await run(() => supabase.from("members").insert(body), name.trim() + " agregado al parte")) onClose();
  }
  return (
    <Sheet visible title={"Agregar a " + unit} onClose={onClose}>
      <Chips options={[[false, "Elegir de la lista"], [true, "Persona nueva"]]} value={nuevo} onChange={setNuevo} />
      {!nuevo ? <>
        <Field label="Buscar" value={q} onChangeText={setQ} placeholder="Nombre, cargo o unidad" />
        {cands.map((m) => <Card key={m.id} onPress={() => agregar(m)}><Text style={S.title}>{m.name}</Text><Text style={S.small}>{m.cargo} · {m.unit}{!inParte(m, fecha) ? " · fuera del parte" : ""}</Text></Card>)}
        <Note text="Si la persona es de otra unidad, queda como agregada a esta y suma a su fuerza." />
      </> : <>
        <Field label="Grado y nombre" value={name} onChangeText={setName} placeholder="SG2 Juan Pérez Soto" />
        <Field label="Cargo" value={cargo} onChangeText={setCargo} />
        <Field label="Celular (opcional)" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
        <Btn title="Agregar al parte" kind="primary" onPress={crear} />
      </>}
    </Sheet>);
}

function PfQuitar({ m, fecha, onClose }) {
  const [mot, setMot] = useState("Traslado");
  async function quitar() {
    if (await run(() => supabase.from("members").update({ parte_hasta: fecha, salida_motivo: mot }).eq("id", m.id), m.name + " sale del parte desde el " + fecha.split("-").reverse().join("-"))) onClose();
  }
  return (
    <Sheet visible title={"Quitar del parte"} onClose={onClose}>
      <Text style={S.title}>{m.name}</Text>
      <Text style={S.small}>{m.cargo} · {m.unit}</Text>
      <Text style={S.label}>Motivo</Text>
      <Chips options={SALIDAS.map((x) => [x, x])} value={mot} onChange={setMot} />
      <Note text="Deja de contar en la fuerza desde el día que estás viendo. Los partes anteriores no cambian y su ficha sigue en Equipo." />
      <Btn title="Quitar del parte" kind="danger" onPress={quitar} />
    </Sheet>);
}

function PfColumna({ d, cols, onClose }) {
  const [n, setN] = useState(""); const [forma, setForma] = useState(false);
  async function save(list) { if (await run(() => supabase.from("config").upsert({ key: "parte_cols", value: list }))) onClose(); }
  return (
    <Sheet visible title="Columnas de novedades" onClose={onClose}>
      {cols.map((c, i) => (
        <Between key={c.n}><Text style={S.body}>{c.n} · {c.forma ? "cuenta como forma" : "cuenta como falta"}</Text>
          <Pressable onPress={() => save(cols.filter((_, j) => j !== i))}><Text style={{ color: C.red, padding: 6 }}>Quitar</Text></Pressable></Between>))}
      <Field label="Nueva columna" value={n} onChangeText={setN} placeholder="Ej.: Teletrabajo, Turno, Guardia" />
      <Chips options={[[false, "Cuenta como falta"], [true, "Cuenta como forma"]]} value={forma} onChange={setForma} />
      <Btn title="+ Agregar columna" kind="primary" onPress={() => { if (n.trim() && !cols.find((c) => c.n === n.trim())) save(cols.concat([{ n: n.trim(), forma }])); }} />
    </Sheet>);
}


/* Asistencia mensual: días hábiles (lun-vie) hasta hoy */
function ParteMensual({ d, cols }) {
  const [mo, setMo] = useState(0);
  const base = new Date(); const y = new Date(base.getFullYear(), base.getMonth() + mo, 1);
  const Y = y.getFullYear(), M = y.getMonth();
  const hoyIso = isoDay(startOfDay(Date.now()));
  const dias = []; for (let t = y.getTime(); new Date(t).getMonth() === M; t = addDays(t, 1)) { const wd = new Date(t).getDay(); const iso = isoDay(t); if (wd >= 1 && wd <= 5 && iso <= hoyIso) dias.push(iso); }
  const colOf = (n) => cols.find((c) => c.n === n);
  const recs = {}; (d.parte || []).forEach((p) => (recs[p.fecha + "|" + p.member_id] = p));
  const valAt = (id, f) => { const r = recs[f + "|" + id]; if (r) return r; const n = (d.novedades || []).find((x) => x.member_id === id && x.desde <= f && f <= x.hasta); if (n) { const c = colOf(n.motivo); return { forma: c ? !!c.forma : false, motivo: n.motivo }; } return null; };
  const people = d.members.filter((m) => dias.some((f) => inParte(m, f)));
  const filas = people.map((m) => { let f = 0, x = 0, s = 0; const mot = {}; dias.forEach((di) => { if (!inParte(m, di)) return; const v = valAt(m.id, di); if (v && v.forma) f++; else if (v && v.forma === false) { x++; if (v.motivo) mot[v.motivo] = (mot[v.motivo] || 0) + 1; } else s++; if (v && v.forma && v.motivo) mot[v.motivo] = (mot[v.motivo] || 0) + 1; }); return { m, f, x, s, mot, pct: f + x ? Math.round(100 * f / (f + x)) : null }; });
  const T = filas.reduce((a, r) => ({ f: a.f + r.f, x: a.x + r.x, s: a.s + r.s }), { f: 0, x: 0, s: 0 });
  const pct = T.f + T.x ? Math.round(100 * T.f / (T.f + T.x)) : null;
  const motTot = {}; filas.forEach((r) => Object.entries(r.mot).forEach(([k, n]) => (motTot[k] = (motTot[k] || 0) + n)));
  const units = {}; filas.forEach((r) => { const u = r.m.parte_unit || r.m.unit || "Sin unidad"; (units[u] = units[u] || []).push(r); });
  const MES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"][M] + " " + Y;
  const [ver, setVer] = useState(false);
  function enviar() {
    const L = ["ASISTENCIA MENSUAL · ZB ARICA", MES.toUpperCase() + " (" + dias.length + " días hábiles)", "", "Asistencia " + (pct == null ? "—" : pct + "%") + " · días-persona presentes " + T.f + " · ausentes " + T.x + (T.s ? " · sin registro " + T.s : "")];
    if (Object.keys(motTot).length) { L.push("", "NOVEDADES (días)"); Object.entries(motTot).forEach(([k, n]) => L.push("• " + k + ": " + n)); }
    L.push(""); Object.entries(units).forEach(([u, rs]) => { const f = rs.reduce((a, r) => a + r.f, 0), x = rs.reduce((a, r) => a + r.x, 0); L.push(u + ": " + (f + x ? Math.round(100 * f / (f + x)) + "%" : "—")); });
    const aus = filas.filter((r) => r.x).sort((a, b) => b.x - a.x); if (aus.length) { L.push("", "AUSENCIAS"); aus.forEach((r) => L.push("- " + r.m.name + ": " + r.x + " día(s) (" + Object.entries(r.mot).map(([k, n]) => k + " " + n).join(", ") + ")")); }
    Share.share({ message: L.join("\n") }).catch(() => {});
  }
  return (
    <>
      <Between><Btn small title="‹ Mes" onPress={() => setMo(mo - 1)} /><Text style={S.h2}>{MES}</Text><Btn small title="Mes ›" onPress={() => mo < 0 && setMo(mo + 1)} disabled={mo >= 0} /></Between>
      <Text style={S.small}>{dias.length} días hábiles registrados (lunes a viernes{mo === 0 ? ", hasta hoy" : ""}).</Text>
      <Row>
        {[["ASISTENCIA", pct == null ? "—" : pct + "%", C.accent], ["PRESENTES", T.f, C.ink], ["AUSENTES", T.x, C.red]].map(([l, n, c]) => (
          <View key={l} style={{ flex: 1, backgroundColor: C.surface, borderRadius: 14, borderWidth: 1, borderColor: C.line, padding: 12, alignItems: "center" }}>
            <Text style={{ fontSize: 11, fontWeight: "800", color: C.muted }}>{l}</Text><Text style={{ fontSize: 26, fontWeight: "800", color: c }}>{n}</Text></View>))}
      </Row>
      <Text style={S.small}>Presentes y ausentes en días-persona. {T.s ? T.s + " días-persona sin registro no se cuentan." : ""}</Text>
      {Object.keys(motTot).length ? <Card><Text style={S.label}>Novedades del mes (días)</Text>{Object.entries(motTot).map(([k, n]) => <Between key={k}><Text style={S.small}>{k}</Text><Text style={{ fontWeight: "800", color: C.ink }}>{n}</Text></Between>)}</Card> : null}
      <Card>
        <Text style={S.label}>Por unidad</Text>
        {Object.entries(units).map(([u, rs]) => { const f = rs.reduce((a, r) => a + r.f, 0), x = rs.reduce((a, r) => a + r.x, 0); const p = f + x ? Math.round(100 * f / (f + x)) : null;
          return <Between key={u}><Text style={[S.small, { flex: 1 }]}>{u} ({rs.length})</Text><Text style={{ fontWeight: "800", color: p == null ? C.muted : p >= 90 ? C.accent : p >= 75 ? C.amber : C.red }}>{p == null ? "—" : p + "%"}</Text></Between>; })}
      </Card>
      <Btn title={ver ? "Ocultar detalle por persona" : "Ver detalle por persona"} onPress={() => setVer(!ver)} />
      {ver ? filas.slice().sort((a, b) => b.x - a.x || a.m.name.localeCompare(b.m.name)).map((r) => (
        <Between key={r.m.id}>
          <View style={{ flex: 1 }}><Text style={[S.small, { color: C.ink, fontWeight: "700" }]}>{r.m.name}</Text>{Object.keys(r.mot).length ? <Text style={S.small}>{Object.entries(r.mot).map(([k, n]) => k + " " + n).join(" · ")}</Text> : null}</View>
          <Text style={{ width: 70, textAlign: "right", fontSize: 12, color: C.muted }}>{r.f}✓ {r.x ? r.x + "✗" : ""}</Text>
          <Text style={{ width: 46, textAlign: "right", fontWeight: "800", color: r.pct == null ? C.muted : r.pct >= 90 ? C.accent : r.pct >= 75 ? C.amber : C.red }}>{r.pct == null ? "—" : r.pct + "%"}</Text>
        </Between>)) : null}
      <Btn title="Enviar asistencia mensual" kind="primary" onPress={enviar} />
      <Descargar titulo={"Asistencia " + MES} build={() => ({ notas: "Asistencia " + (pct == null ? "—" : pct + "%") + " · " + dias.length + " días hábiles", hojas: [
        { nombre: "Por unidad", filas: [["Unidad", "Personas", "Presentes (días)", "Ausentes (días)", "% asistencia"]].concat(Object.entries(units).map(([u, rs]) => { const f = rs.reduce((a, r) => a + r.f, 0), x = rs.reduce((a, r) => a + r.x, 0); return [u, rs.length, f, x, f + x ? Math.round(100 * f / (f + x)) + "%" : "—"]; })) },
        { nombre: "Por persona", filas: [["Grado y nombre", "Unidad", "Presente", "Ausente", "Sin registro", "% asistencia", "Novedades"]].concat(filas.map((r) => [r.m.name, r.m.parte_unit || r.m.unit || "", r.f, r.x, r.s, r.pct == null ? "—" : r.pct + "%", Object.entries(r.mot).map(([k, n]) => k + " " + n).join(", ")])) }] })} />
    </>
  );
}

export function PfNovedad({ d, cols, fecha, onClose, self }) {
  const [q, setQ] = useState(""); const [who, setWho] = useState(self && d.me ? d.me.id : null);
  const [mot, setMot] = useState(cols[0] ? cols[0].n : "Permiso");
  const [desde, setDesde] = useState(fecha.split("-").reverse().join("-"));
  const [hasta, setHasta] = useState(fecha.split("-").reverse().join("-"));
  const cands = d.members.filter((m) => m.activo !== false && inParte(m, fecha)).filter((m) => !q || norm(m.name + " " + m.unit).includes(norm(q))).slice(0, 12);
  const toIso = (s) => { const m = String(s).trim().match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/); return m ? m[3] + "-" + m[2].padStart(2, "0") + "-" + m[1].padStart(2, "0") : null; };
  async function save() {
    const a = toIso(desde), b = toIso(hasta);
    if (!who) return Alert.alert("Elige a la persona.");
    if (!a || !b || b < a) return Alert.alert("Revisa las fechas (dd-mm-aaaa).");
    if (await run(() => supabase.from("novedades").insert({ member_id: who, motivo: mot, desde: a, hasta: b, comment: self ? "informada por el integrante" : "" }), "Novedad registrada")) onClose();
  }
  const dmy = (ms) => isoDay(ms).split("-").reverse().join("-");
  function semana(n) { const base = new Date(fecha + "T12:00:00").getTime(); const lun = addDays(weekStart(base), 7 * n); setDesde(dmy(lun)); setHasta(dmy(addDays(lun, 4))); }
  return (
    <Sheet visible title={self ? "Avisar que no estaré" : "Novedad con fechas"} onClose={onClose}>
      <Text style={S.label}>Persona: {who ? mname(d.members, who) : "—"}</Text>
      {self ? null : <><Field label="Buscar" value={q} onChangeText={setQ} placeholder="Nombre o unidad" />
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{cands.map((m) => <Chip key={m.id} label={m.name} on={who === m.id} onPress={() => setWho(m.id)} />)}</View></>}
      <Text style={S.label}>Motivo</Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{cols.map((c) => <Chip key={c.n} label={c.n} on={mot === c.n} onPress={() => setMot(c.n)} />)}</View>
      <Row style={{ flexWrap: "wrap" }}><Btn small title="Toda esta semana" onPress={() => semana(0)} /><Btn small title="Semana siguiente" onPress={() => semana(1)} /><Btn small title="Dos semanas" onPress={() => { semana(0); setHasta(dmy(addDays(weekStart(new Date(fecha + "T12:00:00").getTime()), 11))); }} /></Row>
      <Row><View style={{ flex: 1 }}><Field label="Desde (dd-mm-aaaa)" value={desde} onChangeText={setDesde} /></View><View style={{ flex: 1 }}><Field label="Hasta" value={hasta} onChangeText={setHasta} /></View></Row>
      <Note text="Esos días la persona aparece marcada sola con este motivo. Si ese día marcas otra cosa a mano, manda lo que marcaste." />
      <Btn title="Guardar novedad" kind="primary" onPress={save} />
    </Sheet>);
}

/* ================= Carta Gantt ================= */
export function Gantt({ d, open }) {
  const [weeks, setWeeks] = useState(8);
  const [pend, setPend] = useState(true);
  const [grp, setGrp] = useState(null);
  const DW = weeks <= 8 ? 16 : weeks <= 12 ? 11 : 6;
  const start = addDays(weekStart(Date.now()), -7);
  const end = addDays(start, weeks * 7);
  const W = weeks * 7 * DW;
  const x = (t) => Math.max(0, Math.min(W, ((t - start) / DAY) * DW));
  const ROW = 34, LBL = 150;
  const tasks = d.tasks.filter((t) => (!pend || !t.done) && due(t) >= start && (!grp || (areaInfo(t.area) || {}).group === grp))
    .sort((a, b) => ((areaInfo(a.area) || {}).group || "Z").localeCompare((areaInfo(b.area) || {}).group || "Z") || due(a) - due(b));
  const evs = grp ? [] : d.events.filter((e) => { const t = new Date(e.at).getTime(); return t >= start && t <= end; }).sort((a, b) => new Date(a.at) - new Date(b.at));
  const rows = [];
  let last = null;
  tasks.forEach((t) => { const g = (areaInfo(t.area) || {}).group || "—"; if (g !== last) { rows.push({ k: "h", g }); last = g; } rows.push({ k: "t", t }); });
  if (evs.length) { rows.push({ k: "h", g: "EV" }); evs.forEach((e) => rows.push({ k: "e", e })); }
  const gname = (g) => g === "EV" ? "Eventos" : ((AREA_GROUPS.find((a) => a[0] === g) || [])[1] || "Sin área");
  const today = x(Date.now());
  const ticks = [...Array(weeks)].map((_, i) => addDays(start, i * 7));
  return (
    <>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
        {[[4, "4 sem"], [8, "8 sem"], [12, "12 sem"], [26, "6 meses"]].map(([n, l]) => <Chip key={n} label={l} on={weeks === n} onPress={() => setWeeks(n)} />)}
        <Chip label={pend ? "Solo pendientes" : "Incluye cumplidas"} on={pend} onPress={() => setPend(!pend)} />
      </View>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}><Chip label="Todas" on={!grp} onPress={() => setGrp(null)} />{AREA_GROUPS.map(([k, n]) => <Chip key={k} label={n} on={grp === k} color={AREA_COLORS[k]} onPress={() => setGrp(grp === k ? null : k)} />)}</View>
      <View style={{ flexDirection: "row", backgroundColor: C.surface, borderRadius: 14, borderWidth: 1, borderColor: C.line, overflow: "hidden" }}>
        <View style={{ width: LBL, borderRightWidth: 1, borderColor: C.line }}>
          <View style={{ height: 28, justifyContent: "center", paddingHorizontal: 8, borderBottomWidth: 1, borderColor: C.line }}><Text style={S.small}>{tasks.length} tareas · {evs.length} eventos</Text></View>
          {rows.map((r, i) => r.k === "h" ? (
            <View key={i} style={{ height: 24, justifyContent: "center", paddingHorizontal: 8, backgroundColor: C.surface2 }}><Text style={{ fontSize: 11, fontWeight: "800", color: r.g === "EV" ? C.blue : AREA_COLORS[r.g] || C.ink2 }}>{gname(r.g).toUpperCase()}</Text></View>
          ) : (
            <Pressable key={i} onPress={() => r.k === "t" ? open({ kind: "task", id: r.t.id }) : null} style={{ height: ROW, justifyContent: "center", paddingHorizontal: 8, borderTopWidth: 1, borderColor: C.line }}>
              <Text numberOfLines={1} style={{ fontSize: 12, color: C.ink }}>{r.k === "t" ? r.t.title : r.e.title}</Text>
              <Text numberOfLines={1} style={{ fontSize: 10, color: C.muted }}>{r.k === "t" ? (mname(d.members, r.t.member_id) + " · " + fmtDay(due(r.t))) : fmt(new Date(r.e.at).getTime())}</Text>
            </Pressable>))}
        </View>
        <ScrollView horizontal contentOffset={{ x: Math.max(0, today - 60), y: 0 }}>
          <View style={{ width: W }}>
            <View style={{ height: 28, flexDirection: "row", borderBottomWidth: 1, borderColor: C.line }}>
              {ticks.map((t, i) => <View key={i} style={{ width: 7 * DW, borderLeftWidth: 1, borderColor: C.line, paddingLeft: 3, justifyContent: "center" }}><Text style={{ fontSize: 10, color: C.muted }}>{new Date(t).getDate() + "/" + (new Date(t).getMonth() + 1)}</Text></View>)}
            </View>
            {rows.map((r, i) => {
              if (r.k === "h") return <View key={i} style={{ height: 24, backgroundColor: C.surface2 }} />;
              if (r.k === "e") { const ex = x(new Date(r.e.at).getTime()); return <View key={i} style={{ height: ROW, borderTopWidth: 1, borderColor: C.line }}><View style={{ position: "absolute", left: ex - 6, top: ROW / 2 - 6, width: 12, height: 12, backgroundColor: C.blue, transform: [{ rotate: "45deg" }] }} /></View>; }
              const t = r.t; const dd = due(t); const cs = Math.min(new Date(t.created_at || dd).getTime(), dd);
              const x1 = x(Math.min(cs, dd - DAY / 2)), x2 = Math.max(x(dd), x1 + 6);
              const st = status(t);
              const col = t.done ? C.muted : st === "over" ? C.red : areaColor(t) || C.accent;
              return (
                <View key={i} style={{ height: ROW, borderTopWidth: 1, borderColor: C.line }}>
                  <View style={{ position: "absolute", left: x1, width: x2 - x1, top: 9, height: ROW - 18, borderRadius: 5, backgroundColor: col, opacity: t.done ? 0.5 : 0.9 }}>
                    <View style={{ width: ((t.done ? 100 : t.progress || 0) / 100) * (x2 - x1), height: "100%", borderRadius: 5, backgroundColor: "rgba(0,0,0,0.25)" }} />
                  </View>
                </View>);
            })}
            <View pointerEvents="none" style={{ position: "absolute", left: today, top: 0, bottom: 0, width: 2, backgroundColor: C.red, opacity: 0.6 }} />
          </View>
        </ScrollView>
      </View>
      <Text style={S.small}>Cada barra va desde que se creó la tarea hasta su plazo; la parte oscura es el avance. Rojo = vencida · rombos azules = eventos · línea roja = hoy. Toca una tarea para abrirla.</Text>
    </>
  );
}

/* ================= Plan de enlace ================= */

function AntecedentesEnlace() {
  const [open, setOpen] = useState(true);
  const [rows, setRows] = useState([]);
  const [query, setQuery] = useState("");
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(false);
  async function cargar() {
    setLoading(true); setError("");
    const { data, error: e } = await supabase.from("plan_enlace_antecedentes").select("*").order("numero");
    if (e) setError(errMsg(e)); else setRows(data || []);
    setLoading(false);
  }
  useEffect(() => { if (open) cargar(); }, [open]);
  async function guardar() {
    const { numero, domicilio, telefono, telefono_emergencia, parentesco, nucleo, observaciones } = editing;
    const { error: e } = await supabase.from("plan_enlace_antecedentes").update({ domicilio, telefono, telefono_emergencia, parentesco, nucleo, observaciones, updated_at: new Date().toISOString() }).eq("numero", numero);
    if (e) return Alert.alert("No se pudo guardar", errMsg(e));
    setEditing(null); await cargar();
  }
  return <Card>
    <Text style={S.title}>Domicilios y contactos de emergencia</Text>
    <Text style={S.small}>Antecedentes de la orden de enlace fotografiada. Revisar vigencia y diferencias antes de sustituir datos actuales.</Text>
    <Btn title={open ? "Ocultar antecedentes" : "Abrir antecedentes y direcciones"} onPress={() => setOpen(!open)} />
    {open ? <View style={{ gap: 10 }}>
      <TextInput value={query} onChangeText={setQuery} placeholder="Buscar persona, núcleo o domicilio" style={{ minHeight: 44, borderWidth: 1, borderColor: C.line2, borderRadius: 10, padding: 10 }} />
      {loading ? <Text style={S.small}>Cargando…</Text> : <Text style={S.small}>{rows.length} registros</Text>}
      {error ? <Text style={S.small}>{error}</Text> : null}
      <Btn small title="Actualizar lista" onPress={cargar} />
      {rows.filter(r => norm(r.nombre + " " + r.nucleo + " " + r.domicilio).includes(norm(query))).map(r => <View key={r.numero} style={{ borderTopWidth: 1, borderColor: C.line, paddingVertical: 10, gap: 5 }}>
        <Text style={S.title}>{r.numero}. {r.nombre}</Text>
        <Text style={S.small}>Núcleo: {r.nucleo || "Sin registrar"}</Text>
        <Text style={S.small}>Domicilio: {r.domicilio || "Sin registrar"}</Text>
        <Text style={S.small}>Teléfono en documento: {r.telefono || "Sin registrar"}</Text>
        <Text style={S.small}>Emergencia: {r.telefono_emergencia || "Sin registrar"} · {r.parentesco || "Parentesco sin registrar"}</Text>
        <Text style={S.small}>{r.observaciones}</Text>
        {editing && editing.numero === r.numero ? <View style={{ gap: 6 }}>
          {[["domicilio", "Domicilio particular"], ["telefono", "Teléfono"], ["telefono_emergencia", "Teléfono de emergencia"], ["parentesco", "Parentesco"], ["nucleo", "Núcleo"], ["observaciones", "Observaciones y validación"]].map(([key, label]) => <View key={key}><Text style={S.small}>{label}</Text><TextInput value={editing[key] || ""} onChangeText={value => setEditing(prev => ({ ...prev, [key]: value }))} style={{ minHeight: 44, borderWidth: 1, borderColor: C.line2, borderRadius: 8, padding: 8 }} /></View>)}
          <Row><Btn title="Guardar" onPress={guardar} /><Btn title="Cancelar" onPress={() => setEditing(null)} /></Row>
        </View> : <Btn small title="Revisar / editar antecedentes" onPress={() => setEditing({ ...r })} />}
      </View>)}
    </View> : null}
  </Card>;
}

export function PlanEnlace({ d, isAdmin }) {
  const [q, setQ] = useState(""); const [edit, setEdit] = useState(null); const [ph, setPh] = useState(""); const [em, setEm] = useState("");
  const [falta, setFalta] = useState(false);
  const qq = norm(q);
  const act = d.members.filter((m) => m.activo !== false && m.nivel !== "X");
  const list = act.filter((m) => (!qq || norm(m.name + " " + m.cargo + " " + m.unit + " " + (m.phone || "")).includes(qq)) && (!falta || !m.phone));
  const unitOrder = {}; act.forEach((m) => { if (unitOrder[m.unit] === undefined || (m.unit_order ?? 99) < unitOrder[m.unit]) unitOrder[m.unit] = m.unit_order ?? 99; });
  const units = Object.keys(unitOrder).sort((a, b) => unitOrder[a] - unitOrder[b]);
  function startEdit(m) { setEdit(m.id); setPh(m.phone || ""); setEm(m.email || ""); }
  async function save(m) {
    const p = ph.trim(); const e = em.trim().toLowerCase();
    if (p && phoneDigits(p).length < 8) return Alert.alert("Número no válido", "Ej.: +56 9 1234 5678");
    if (e && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)) return Alert.alert("Correo no válido", "Ej.: nombre.apellido@ejercito.cl");
    const yo = d.me && m.id === d.me.id;
    const fn = isAdmin ? () => supabase.from("members").update({ phone: p || null, email: e || null }).eq("id", m.id) : () => supabase.rpc("actualizar_mis_datos", { p_phone: p, p_email: e });
    if (!isAdmin && !yo) return;
    if (await run(fn, yo && !isAdmin ? "Tus datos quedaron actualizados" : "Plan de enlace actualizado")) setEdit(null);
  }
  function compartir() {
    const txt = "PLAN DE ENLACE · ZONA DE BIENESTAR \"ARICA\"\n" + new Date().toLocaleDateString("es-CL") + "\n" +
      units.map((u) => { const ms = act.filter((m) => (m.unit || "") === u); return ms.length ? "\n" + (u || "Sin unidad").toUpperCase() + "\n" + ms.map((m) => "• " + m.name + (m.cargo ? " (" + m.cargo + ")" : "") + ": " + (m.phone || "sin teléfono") + (m.email ? " · " + m.email : "")).join("\n") : ""; }).join("\n");
    Share.share({ message: txt });
  }
  const sinTel = act.filter((m) => !m.phone).length;
  return (
    <View style={{ gap: 12 }}>
      <Text style={S.h2}>Plan de enlace</Text>
      {isAdmin ? <AntecedentesEnlace /> : null}
      <Text style={S.small}>{act.length} integrantes · {act.length - sinTel} con teléfono · {sinTel} sin teléfono</Text>
      <TextInput value={q} onChangeText={setQ} placeholder="Buscar por nombre, cargo, unidad o número" placeholderTextColor="#8A968F" style={{ minHeight: 46, borderRadius: 12, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 14 }} />
      <Row style={{ flexWrap: "wrap" }}><Chip label={"Sin teléfono (" + sinTel + ")"} on={falta} onPress={() => setFalta(!falta)} /><Btn small title="Compartir plan de enlace" onPress={compartir} /></Row>
      <Descargar titulo="Plan de enlace ZB Arica" build={() => ({ hojas: [{ nombre: "Plan de enlace", filas: [["Unidad", "Grado y nombre", "Cargo", "Teléfono", "Correo"]].concat(units.flatMap((u) => act.filter((m) => (m.unit || "") === u).map((m) => [u || "Sin unidad", m.name, m.cargo || "", m.phone || "", m.email || ""]))) }] })} />
      {isAdmin ? <Note kind="info" text="Toca “Actualizar” para cambiar el teléfono o correo de una persona. Cada integrante también puede corregir los suyos." /> : (() => { const yo = d.members.find((m) => d.me && m.id === d.me.id); return yo ? (
        <Card style={{ borderColor: C.accent }}>
          <Text style={S.title}>Mis datos de contacto</Text>
          <Text style={S.small}>Teléfono: {yo.phone || "sin registrar"} · Correo: {yo.email || "sin registrar"}</Text>
          {edit === yo.id ? null : <Btn small title="Corregir mis datos" kind="primary" onPress={() => startEdit(yo)} />}
          {edit === yo.id ? <Note kind="info" text="Ojo: para entrar a Hito sigue usando el número con que creaste tu acceso." /> : null}
          {edit === yo.id ? <View style={{ gap: 6 }}>
                    <TextInput value={ph} onChangeText={setPh} placeholder="+56 9 1234 5678" placeholderTextColor="#8A968F" keyboardType="phone-pad" style={{ minHeight: 42, borderRadius: 10, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 10 }} />
                    <TextInput value={em} onChangeText={setEm} placeholder="correo, ej.: nombre.apellido@ejercito.cl" placeholderTextColor="#8A968F" keyboardType="email-address" autoCapitalize="none" style={{ minHeight: 42, borderRadius: 10, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 10 }} />
                    <Row><Btn small title="Guardar" kind="primary" onPress={() => save(yo)} /><Btn small title="Cancelar" onPress={() => setEdit(null)} /></Row>
                  </View> : null}
        </Card>) : null; })()}
      {units.map((u) => { const ms = list.filter((m) => (m.unit || "") === u); if (!ms.length) return null;
        return (
          <Card key={u} style={{ padding: 0, gap: 0 }}>
            <View style={{ padding: 12, backgroundColor: C.surface2, borderTopLeftRadius: 14, borderTopRightRadius: 14 }}><Text style={S.title}>{u || "Sin unidad"}</Text></View>
            {ms.map((m) => (
              <View key={m.id} style={{ paddingHorizontal: 12, paddingVertical: 10, borderTopWidth: 1, borderColor: C.line, gap: 6 }}>
                <Between>
                  <View style={{ flex: 1 }}>
                    <Text style={[S.small, { color: C.ink, fontWeight: "700" }]}>{m.name}</Text>
                    {m.cargo ? <Text style={S.small}>{m.cargo}</Text> : null}
                    <Text style={{ fontSize: 15, fontWeight: "800", color: m.phone ? C.accent : C.amberInk }}>{m.phone || "Sin teléfono"}</Text>
                    {m.email ? <Text style={S.small}>{m.email}</Text> : null}
                  </View>
                  <View style={{ gap: 4 }}>
                    {m.phone ? <Btn small title="Llamar" onPress={() => Linking.openURL("tel:" + phoneDigits(m.phone))} /> : null}
                    {m.phone ? <Btn small title="WhatsApp" onPress={() => openWa(m.phone, "")} /> : null}
                    {(isAdmin || (d.me && m.id === d.me.id)) && edit !== m.id ? <Btn small title={isAdmin ? "Actualizar" : "Corregir"} onPress={() => startEdit(m)} /> : null}
                  </View>
                </Between>
                {edit === m.id && (isAdmin || !(d.me && m.id === d.me.id)) ? (
                  <View style={{ gap: 6 }}>
                    <TextInput value={ph} onChangeText={setPh} placeholder="+56 9 1234 5678" placeholderTextColor="#8A968F" keyboardType="phone-pad" style={{ minHeight: 42, borderRadius: 10, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 10 }} />
                    <TextInput value={em} onChangeText={setEm} placeholder="correo, ej.: nombre.apellido@ejercito.cl" placeholderTextColor="#8A968F" keyboardType="email-address" autoCapitalize="none" style={{ minHeight: 42, borderRadius: 10, borderWidth: 1, borderColor: C.line2, backgroundColor: C.surface, paddingHorizontal: 10 }} />
                    <Row><Btn small title="Guardar" kind="primary" onPress={() => save(m)} /><Btn small title="Cancelar" onPress={() => setEdit(null)} /></Row>
                  </View>) : null}
              </View>))}
          </Card>); })}
    </View>
  );
}
