// Avisos en el celular: recordatorios de plazo programados en el propio teléfono
// (funcionan aunque la app esté cerrada) y avisos inmediatos cuando llega algo nuevo.
import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { fmt } from "./lib";

// El módulo se carga solo cuando la persona activa los avisos (si falla, la app sigue funcionando).
let Notifications = null;
let enabled = null;
function mod() {
  if (Platform.OS === "web") return null;
  if (Notifications) return Notifications;
  try { Notifications = require("expo-notifications"); } catch (e) { Notifications = null; }
  return Notifications;
}
export async function avisosActivos() {
  if (enabled === null) { try { enabled = (await AsyncStorage.getItem("hito-avisos")) === "1"; } catch (e) { enabled = false; } }
  return enabled;
}
export async function activarAvisos(on) {
  enabled = !!on; lastKey = "";
  try { await AsyncStorage.setItem("hito-avisos", on ? "1" : "0"); } catch (e) {}
  if (!on) { try { const N = mod(); if (N) await N.cancelAllScheduledNotificationsAsync(); } catch (e) {} return true; }
  return await setupNotifications();
}

let ready = null;
let lastKey = "";
const H = 3600e3;

export function setupNotifications() {
  if (ready) return ready;
  ready = (async () => {
    try {
      if (!mod()) return false;
      Notifications.setNotificationHandler({
        handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false }),
      });
      if (Platform.OS === "android") {
        await Notifications.setNotificationChannelAsync("plazos", {
          name: "Plazos y avisos", importance: Notifications.AndroidImportance.HIGH, vibrationPattern: [0, 250, 150, 250],
        });
      }
      const cur = await Notifications.getPermissionsAsync();
      if (cur.granted) return true;
      const req = await Notifications.requestPermissionsAsync();
      return !!req.granted;
    } catch (e) { ready = null; return false; }
  })();
  return ready;
}

async function at(date, title, body) {
  if (date <= Date.now() + 60e3) return;
  await Notifications.scheduleNotificationAsync({
    content: { title, body, sound: true },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: new Date(date), channelId: "plazos" },
  });
}

export async function now(title, body) {
  if (!(await avisosActivos()) || !(await setupNotifications())) return;
  try { await Notifications.scheduleNotificationAsync({ content: { title, body, sound: true }, trigger: Platform.OS === "android" ? { channelId: "plazos" } : null }); } catch (e) {}
}

// Reprograma todos los recordatorios a partir de los datos actuales.
export async function reschedule(d) {
  if (!d.me || !(await avisosActivos()) || !(await setupNotifications())) return;
  const isAdmin = d.me.role === "admin";
  const mine = d.tasks.filter((t) => !t.done && (isAdmin ? true : t.member_id === d.me.id || t.apoyo === d.me.id || t.delegado === d.me.id || (t.participantes || []).includes(d.me.id)));
  const key = mine.map((t) => t.id + t.due).join("|") + (isAdmin ? "A" : "M");
  if (key === lastKey) return;
  lastKey = key;
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    const nm = (id) => ((d.members.find((m) => m.id === id) || {}).name || "Sin asignar");
    const list = mine.map((t) => ({ t, due: new Date(t.due).getTime() })).sort((a, b) => a.due - b.due).slice(0, 60);
    for (const { t, due } of list) {
      if (isAdmin) {
        await at(due, "Venció una tarea", "“" + t.title + "” de " + nm(t.member_id) + ". Debe presentarse en tu oficina.");
      } else {
        await at(due - 48 * H, "Quedan 2 días", "“" + t.title + "” vence el " + fmt(due) + ".");
        await at(due - 3 * H, "Vence en 3 horas", "“" + t.title + "”. Si no alcanzas, ya no se puede pedir prórroga después del plazo.");
        await at(due, "Tarea vencida", "“" + t.title + "” venció. Debes presentarte en la oficina del Comandante.");
      }
    }
    // Resumen diario a las 8:00
    await Notifications.scheduleNotificationAsync({
      content: { title: "Hito · tu día", body: isAdmin ? "Revisa vencidas, citaciones y prórrogas pendientes." : "Revisa tus tareas y plazos de hoy." },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DAILY, hour: 8, minute: 0, channelId: "plazos" },
    });
  } catch (e) {}
}

// Compara la carga anterior con la nueva y avisa lo que llegó.
export function diffAlerts(prev, d) {
  if (!prev || !prev.loaded || !d.me) return;
  const isAdmin = d.me.role === "admin";
  const old = new Set(prev.tasks.map((t) => t.id));
  if (!isAdmin) {
    d.tasks.filter((t) => !old.has(t.id) && (t.member_id === d.me.id || t.apoyo === d.me.id || t.delegado === d.me.id || (t.participantes || []).includes(d.me.id))).forEach((t) => now("Nueva tarea asignada", "“" + t.title + "” · plazo " + fmt(new Date(t.due).getTime())));
    const before = Object.fromEntries(prev.prorrogas.map((p) => [p.id, p.status]));
    d.prorrogas.filter((p) => before[p.id] === "pendiente" && p.status !== "pendiente").forEach((p) => now("Respuesta a tu prórroga", "Estado: " + p.status + (p.comment ? " · " + p.comment : "")));
    const solicitudesPrevias = Object.fromEntries((prev.solicitudes || []).map((s) => [s.id, s]));
    (d.solicitudes || []).filter((s) => s.solicitante === d.me.id && solicitudesPrevias[s.id] && solicitudesPrevias[s.id].estado !== "rechazada" && s.estado === "rechazada")
      .forEach((s) => {
        const titulo = (s.datos || {}).title || "la tarea solicitada";
        const tipo = s.tipo === "derivacion" ? "Tu derivación" : "Tu solicitud";
        now("Solicitud rechazada", tipo + " de “" + titulo + "” fue rechazada por el Comandante." + (s.motivo ? " Motivo: " + s.motivo : ""));
      });
  } else {
    if (prev.avisos) { const oldA = new Set(prev.avisos.map((x) => x.id)); (d.avisos || []).filter((x) => !oldA.has(x.id)).forEach((x) => now("Cambio sin tu autorización", (((d.members || []).find((m) => m.id === x.actor) || {}).name || "Un integrante") + " · “" + x.titulo + "”: " + x.detalle)); }
    const oldN = new Set((prev.novedades || []).map((x) => x.id));
    (d.novedades || []).filter((x) => prev.novedades && !oldN.has(x.id) && x.comment === "informada por el integrante").forEach((x) => now("Aviso de ausencia", ((d.members || []).find((m) => m.id === x.member_id) || {}).name + ": " + x.motivo + " del " + x.desde.split("-").reverse().join("-") + " al " + x.hasta.split("-").reverse().join("-")));
    const oldP = new Set(prev.prorrogas.map((p) => p.id));
    d.prorrogas.filter((p) => !oldP.has(p.id) && p.status === "pendiente").forEach((p) => now("Nueva solicitud de prórroga", "Motivo: " + (p.motivo || "—")));
  }
  if (!isAdmin) {
    const prevOwn = {}; prev.tasks.forEach((t) => (prevOwn[t.id] = [t.member_id, t.apoyo]));
    d.tasks.filter((t) => t.id in prevOwn && !prevOwn[t.id].includes(d.me.id) && (t.member_id === d.me.id || t.apoyo === d.me.id))
      .forEach((t) => now("Te asignaron una tarea", "“" + t.title + "” · plazo " + fmt(new Date(t.due).getTime())));
  }
  const prevDel = {}; prev.tasks.forEach((t) => (prevDel[t.id] = t.delegado || null));
  const nm = (id) => ((d.members || []).find((m) => m.id === id) || {}).name || "alguien";
  d.tasks.filter((t) => t.id in prevDel && (t.delegado || null) !== prevDel[t.id]).forEach((t) => {
    if (isAdmin && t.delegado) now("Tarea derivada", nm(t.member_id) + " derivó “" + t.title + "” a " + nm(t.delegado));
    else if (!isAdmin && t.delegado === d.me.id) now("Te derivaron una tarea", "“" + t.title + "” de " + nm(t.member_id));
  });
  const oldE = new Set(prev.events.map((e) => e.id));
  d.events.filter((e) => !oldE.has(e.id) && e.by_member !== d.me.id).forEach((e) => now("Nuevo evento en el calendario", e.title));
  const oldPo = new Set(prev.posts.map((p) => p.id));
  d.posts.filter((p) => !oldPo.has(p.id)).forEach((p) => now("Diario mural", p.title));
}
