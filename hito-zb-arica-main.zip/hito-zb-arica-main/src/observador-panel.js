import React, { useCallback, useState } from "react";
import { View, Text, ScrollView } from "react-native";
import { Btn, Note, S } from "./ui";
import { Dashboard } from "./dashboard";
import { accessAction, CambiarClave } from "./usuarios";

export function Observador({ d, reload, token, onExit }) {
 const [password,setPassword]=useState(false);
 const reportProvider=useCallback(async period=>{const r=await accessAction({action:"observer_read",token,period});if(!r.dashboard)throw Error("Actualiza tu clave o ingresa nuevamente");return r.dashboard;},[token]);
 if(password)return <CambiarClave observerToken={token} onClose={()=>{setPassword(false);reload();}}/>;
 return <ScrollView contentContainerStyle={{padding:16,gap:12,paddingBottom:40}}><Text style={{...S.title,fontSize:24}}>HITO · Observador</Text><Text style={S.small}>{d.me.name}</Text><Note kind="info" text="Consulta de indicadores agregados. No puedes crear, modificar, aprobar ni eliminar información. No incluye fichas personales ni detalle de tareas."/><View style={{flexDirection:"row",gap:8}}><Btn small title="Cambiar mi PIN" onPress={()=>setPassword(true)}/><Btn small title="Salir" onPress={onExit}/></View><Dashboard reportProvider={reportProvider} open={()=>{}}/></ScrollView>;
}
