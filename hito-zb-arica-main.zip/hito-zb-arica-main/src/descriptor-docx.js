import JSZip from "jszip";
import template from "./descriptor-plantilla";
import { PERFILES_CARGO } from "./perfiles";

const norm=s=>String(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim();
const esc=s=>String(s??"").replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g,"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const slug=s=>norm(s).replace(/[^a-z0-9]+/g,"_").replace(/^_|_$/g,"").slice(0,100)||"cargo";
const cleanTitle=s=>String(s||"").replace(/^DESCRIPTOR DE CARGO\s*[·:–—-]?\s*/i,"").trim();
function p(text,{bold=false,align="both",after=100,keep=false,size=28}={}) {
 const runs=String(text??"").split("\n").map((line,i)=>`${i?"<w:r><w:br/></w:r>":""}<w:r><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman"/><w:sz w:val="${size}"/><w:szCs w:val="${size}"/>${bold?"<w:b/>":""}</w:rPr><w:t xml:space="preserve">${esc(line)}</w:t></w:r>`).join("");
 return `<w:p><w:pPr><w:spacing w:before="0" w:after="${after}" w:line="240" w:lineRule="auto"/><w:jc w:val="${align}"/>${keep?"<w:keepNext/>":""}<w:widowControl/></w:pPr>${runs}</w:p>`;
}
const heading=s=>p(s,{bold:true,align:"left",after:140,keep:true});
const pageBreak='<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
function table(rows,header=false) {
 return `<w:tbl>${template.tableProperties}${template.grid}${rows.map((cells,i)=>`<w:tr>${header&&i===0?"<w:trPr><w:tblHeader/><w:cantSplit/></w:trPr>":"<w:trPr><w:cantSplit/></w:trPr>"}${cells.map((text,j)=>`<w:tc><w:tcPr><w:tcW w:w="${j?6803:2835}" w:type="dxa"/><w:vAlign w:val="center"/><w:tcMar><w:top w:w="90" w:type="dxa"/><w:left w:w="100" w:type="dxa"/><w:bottom w:w="90" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tcMar></w:tcPr>${p(text,{bold:header&&i===0,align:header&&i===0?"center":"left",after:50})}</w:tc>`).join("")}</w:tr>`).join("")}</w:tbl>`;
}
const paragraphs=text=>String(text||"").split(/\n\s*\n/).filter(x=>x.trim()).map(x=>p(x,{align:x.includes("\n")?"left":"both"})).join("");
function section(definition,name) { return (definition.sections||[]).find(s=>norm(s.heading)===norm(name))?.text||""; }
function field(text,names) {
 for(const line of String(text||"").split("\n"))for(const name of names){
  const at=line.indexOf(":");
  if(at>=0&&norm(line.slice(0,at)).replace(/\s*\/\s*/g,"/")===norm(name).replace(/\s*\/\s*/g,"/"))return line.slice(at+1).replace(/^\s*[—–-]\s*/,"").trim();
 }
 return "";
}
export function functionRows(text) {
 const rows=[];let current=null;
 for(const line of String(text||"").split("\n")){
  if(!line.trim()||/^FUNCIONES\s*[—–-]\s*TAREAS$/i.test(line.trim()))continue;
  const numbered=line.match(/^\s*(\d+)[.)]\s*(?:[—–-]\s*)?(.+)$/);
  if(numbered){
   const rest=numbered[2];const divider=rest.indexOf(" — ");
   current=[`${numbered[1]}. ${divider>=0?rest.slice(0,divider):rest}`,divider>=0?rest.slice(divider+3):""];rows.push(current);
  }else if(current){current[1]+=(current[1]?"\n":"")+line;}else{current=["Funciones y tareas",line];rows.push(current);}
 }
 for(const row of rows)if(!row[1].trim()){
  const text=row[0].replace(/^\d+[.)]\s*/,"");
  const number=row[0].match(/^\d+/)?.[0];
  const label=/^Ser[aá] responsable/i.test(text)?"Responsabilidades del cargo":/^Deber[aá]/i.test(text)?"Ejecución y seguimiento":/^Responder[aá]/i.test(text)?"Responsabilidad y resultados":/^Mantendr[aá]/i.test(text)?"Coordinación funcional":/^No\b/.test(text)?"Límites de actuación":/^Como evidencia/i.test(text)?"Productos y evidencias":"Funciones específicas";
  row[0]=(number?number+". ":"")+label;row[1]=text;
 }
 return rows.length?rows:[["Funciones y tareas","No consignadas en el descriptor."]];
}

export function catalogoDescriptores(d) {
 const entries=[],missing=[],seen=new Set();
 const manuals=d.profiles||[];
 for(const m of d.members||[]){
  if(!m.cargo?.trim())continue;
  const key=norm(m.cargo),scoped=key+"::"+norm(m.unit);
  if(seen.has(scoped))continue;seen.add(scoped);
  const manual=manuals.find(x=>norm(x.cargo_key)===scoped)||manuals.find(x=>norm(x.cargo_key||x.cargo)===key);
  const fallback=PERFILES_CARGO.find(x=>x.aliases.some(a=>norm(`${m.cargo} ${m.unit||""}`).includes(norm(a))));
  if(manual||fallback)entries.push({cargo:m.cargo,definition:manual||fallback,source:manual?"Ficha guardada en HITO":"Descriptor institucional de referencia",unit:m.unit||""});
  else missing.push({cargo:m.cargo,unit:m.unit||""});
 }
 entries.sort((a,b)=>a.cargo.localeCompare(b.cargo,"es")||a.unit.localeCompare(b.unit,"es"));
 return {entries,missing};
}

export async function crearDescriptor(entry) {
 const zip=await JSZip.loadAsync(template.base64,{base64:true});
 const original=await zip.file("word/document.xml").async("string");
 const sect=original.match(/<w:sectPr\b[\s\S]*?<\/w:sectPr>/)?.[0];
 if(!sect)throw Error("La plantilla no contiene configuración de página");
 const def=entry.definition;const description=section(def,"descripción del puesto"),relations=section(def,"relaciones de dependencia y supervisión");
 const info=[
  ["Título requerido para el puesto",field(description,["Título requerido para el puesto"])||"No consignado en el descriptor"],
  ["Localización o ubicación",field(description,["Localización o ubicación"])||'ZONA DE BIENESTAR “ARICA”'],
  ["Depto / Sección",field(description,["Depto / Sección","Depto/Sección"])||entry.unit||"No consignado en el descriptor"],
  ["Subordinado a",field(description,["Subordinado a"])||field(relations,["Cargo del superior directo","Subordinado a"])||"Según relaciones de dependencia del descriptor"],
  ["Elaborado por",field(description,["Elaborado por","Preparado por"])||"No consignado en el descriptor"],
  ["Aprobado por",field(description,["Aprobado por"])||"COMANDANTE DE LA ZONA DE BIENESTAR"],
  ["Fecha de actualización",field(description,["Fecha de actualización","Fecha"])||"No consignada en el descriptor"]
 ];
 const mission=section(def,"misión del cargo");const functions=section(def,"funciones y tareas principales");
 let body=p("DESCRIPTOR DE CARGO",{bold:true,align:"center",keep:true})+p(cleanTitle(def.title||entry.cargo).toUpperCase(),{bold:true,align:"center",keep:true})+p('ZONA DE BIENESTAR “ARICA”',{bold:true,align:"center",after:200,keep:true});
 body+=heading("I. DESCRIPCIÓN DEL PUESTO")+table(info)+p("",{after:120});
 body+=heading("II. MISIÓN DEL CARGO")+paragraphs(mission||"No consignada en el descriptor.");
 const status=field(description,["Estado de revisión"]);
 body+=status?p("Estado: "+status,{align:"left",after:100}):"";
 body+=p("La aplicación de las funciones y la dependencia del puesto se ajustará a la TD y a la orden de funcionamiento aprobadas.",{after:100});
 body+=template.signature+pageBreak+heading("III. FUNCIONES Y TAREAS PRINCIPALES")+table([["FUNCIONES","TAREAS"],...functionRows(functions)],true);
 const extras=(def.sections||[]).filter(s=>!["descripcion del puesto","mision del cargo","funciones y tareas principales"].includes(norm(s.heading))&&s.text?.trim());
 if(extras.length){body+=pageBreak+heading("ANTECEDENTES COMPLEMENTARIOS");for(const s of extras)body+=heading(s.heading.toUpperCase())+paragraphs(s.text);}
 body+=p(`Cargo asociado en HITO: ${entry.cargo}\nOrigen: ${entry.source}`,{align:"left",after:0,size:24});
 zip.file("word/document.xml",original.replace(/<w:body>[\s\S]*?<\/w:body>/,`<w:body>${body}${sect}</w:body>`));
 zip.file("docProps/core.xml",`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>${esc(entry.cargo)}</dc:title><dc:creator>Zona de Bienestar Arica</dc:creator></cp:coreProperties>`);
 // La miniatura del archivo fuente no representa el nuevo cargo.
 zip.remove("docProps/thumbnail.jpeg");
 const types=await zip.file("[Content_Types].xml").async("string");zip.file("[Content_Types].xml",types.replace(/<Override[^>]*PartName="\/docProps\/thumbnail\.jpeg"[^>]*\/>/g,""));
 const rels=await zip.file("_rels/.rels").async("string");zip.file("_rels/.rels",rels.replace(/<Relationship\b[^>]*Target="docProps\/thumbnail\.jpeg"[^>]*\/>/g,""));
 return zip.generateAsync({type:"uint8array",compression:"DEFLATE"});
}

const csv=value=>'"'+String(value??"").replace(/^[=+\-@]/,"'$&").replace(/"/g,'""')+'"';
export async function crearZipDescriptores(d,onProgress=()=>{}) {
 const catalog=catalogoDescriptores(d);if(!catalog.entries.length)throw Error("No hay descriptores disponibles");
 const archive=new JSZip();const index=[["Archivo","Cargo","Unidad","Origen"]];
 for(let i=0;i<catalog.entries.length;i++){
  const e=catalog.entries[i],name=`${String(i+1).padStart(3,"0")}_${slug(e.cargo+"_"+e.unit)}.docx`;
  archive.file(`Descriptores/${name}`,await crearDescriptor(e));index.push([name,e.cargo,e.unit,e.source]);onProgress(i+1,catalog.entries.length);
  await new Promise(resolve=>setTimeout(resolve,0));
 }
 archive.file("INDICE_DESCRIPTORES.csv","\uFEFF"+index.map(r=>r.map(csv).join(";")).join("\r\n"));
 archive.file("CARGOS_SIN_DESCRIPTOR.csv","\uFEFF"+[["Cargo","Unidad"],...catalog.missing.map(m=>[m.cargo,m.unit])].map(r=>r.map(csv).join(";")).join("\r\n"));
 archive.file("LEEME.txt",`DESCRIPTORES DE CARGO · HITO ZB ARICA\n\n${catalog.entries.length} documentos Word en el formato institucional proporcionado el 17OCT2026.\nLos documentos conservan sus contenidos registrados. Los campos sin información se señalan expresamente.\nEl índice identifica el cargo y el origen de cada descriptor. Incluye los cargos y unidades del Equipo actual, sin repetir a sus titulares.\nCARGOS_SIN_DESCRIPTOR.csv enumera los cargos del equipo sin ficha ni referencia asociada.\nLa reproducción del bloque de firma del formato no acredita firma electrónica ni aprobación de un descriptor.\nGenerado: ${new Date().toISOString()}\n`);
 return {bytes:await archive.generateAsync({type:"uint8array",compression:"DEFLATE"}),count:catalog.entries.length,missing:catalog.missing.length};
}
