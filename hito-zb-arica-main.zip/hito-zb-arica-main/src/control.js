// Control de gestión: actividades periódicas, matriz de riesgos y exportación a Excel.
import React, { useState, useMemo } from "react";
import { View, Text, Pressable, Alert, ScrollView, Platform } from "react-native";
import * as XLSX from "xlsx";
import { File, Paths } from "expo-file-system";
import * as Sharing from "expo-sharing";
import { supabase, fmt, fmtDay, startOfDay, addDays, due, status, norm, errMsg, DAY } from "./lib";
import { AREAS, AREA_COLORS, AREA_GROUPS, areaInfo, procInfo } from "./catalog";
import { Share } from "react-native";
import { Descargar } from "./exportar";
import { ReunionSemanal } from "./reunion";
import { C, S, Btn, Chip, Chips, Card, Field, Note, Sheet, Row, Between, Empty } from "./ui";

export const PERIODOS = ["Semanal", "Quincenal", "Mensual", "Trimestral", "Semestral", "Anual", "Según disposición"];
export const PRIORIDADES = ["ALTA", "MEDIA", "BAJA"];
export const TIPOS_RIESGO = ["Operacional", "Administrativo", "Documental", "Cumplimiento", "Seguridad", "Recursos", "Tecnológico", "Otro"];
const NIV3 = ["BAJA", "MEDIA", "ALTA"];
export const ESTADOS_ACCION = ["Pendiente", "En ejecución", "Cumplida", "No cumplida"];
const DIAS = ["", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
const mname = (members, id) => (members.find((m) => m.id === id) || {}).name || "—";
const iso = (ms) => new Date(ms - new Date(ms).getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const ZONA_HITO = "America/Santiago";
const fmtFechaHito = new Intl.DateTimeFormat("en-US", { timeZone: ZONA_HITO, year: "numeric", month: "2-digit", day: "2-digit" });
const fmtFechaHoraHito = new Intl.DateTimeFormat("en-US", { timeZone: ZONA_HITO, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" });
const partesFormato = (fmt, ms) => Object.fromEntries(fmt.formatToParts(new Date(ms)).map((p) => [p.type, p.value]));
function fechaHito(ms) { const p = partesFormato(fmtFechaHito, ms); return p.year + "-" + p.month + "-" + p.day; }
function sumarFechaHito(fecha, n) { const [y, m, d] = fecha.split("-").map(Number); const x = new Date(Date.UTC(y, m - 1, d + n)); return x.getUTCFullYear() + "-" + String(x.getUTCMonth() + 1).padStart(2, "0") + "-" + String(x.getUTCDate()).padStart(2, "0"); }
function horaHitoIso(fecha, hora) { const [y, m, d] = fecha.split("-").map(Number); const objetivo = Date.UTC(y, m - 1, d, Number(hora) || 0, 0, 0); let utc = objetivo; for (let i = 0; i < 3; i++) { const p = partesFormato(fmtFechaHoraHito, utc); const localComoUtc = Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day), Number(p.hour), Number(p.minute), Number(p.second)); utc = objetivo + (utc - localComoUtc); } return new Date(utc).toISOString(); }
const dmy = (s) => (s ? String(s).slice(0, 10).split("-").reverse().join("-") : "—");
const toIso = (s) => { const m = String(s || "").trim().match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/); return m ? m[3] + "-" + m[2].padStart(2, "0") + "-" + m[1].padStart(2, "0") : null; };

export function nivel(p, i) { const s = (p || 0) * (i || 0); if (!s) return "PENDIENTE"; return s >= 6 ? "ALTO" : s >= 3 ? "MEDIO" : "BAJO"; }
// Nivel de exposición residual CAIGG (después de controles) → semáforo de la app
const EXPO = { "NO ACEPTABLE": "ALTO", MAYOR: "ALTO", MEDIA: "MEDIO", MENOR: "BAJO" };
export function nivelR(r) { return (r && r.exposicion && EXPO[r.exposicion]) || nivel(r.probabilidad, r.impacto); }
export const SEM = { ALTO: "#B4380A", MEDIO: "#C98A0B", BAJO: "#1F5D4C", PENDIENTE: "#8A968F" };

/* ---------- Generación de tareas desde actividades periódicas ---------- */
function ocurrencias(a, from, to) {
  const out = [];
  const ini = a.desde && a.desde > from ? a.desde : from;
  const fin = a.hasta && a.hasta < to ? a.hasta : to;
  const dia = a.dia || 1;
  for (let fecha = ini; fecha <= fin; fecha = sumarFechaHito(fecha, 1)) {
    const [y, m, d] = fecha.split("-").map(Number);
    const weekday = ((new Date(Date.UTC(y, m - 1, d)).getUTCDay() + 6) % 7) + 1;
    const domOk = d === Math.min(dia, new Date(Date.UTC(y, m, 0)).getUTCDate());
    let ok = false;
    switch (a.periodicidad) {
      case "Semanal": ok = weekday === dia; break;
      case "Quincenal": ok = weekday === dia && Math.floor((Date.UTC(y, m - 1, d) - Date.UTC(2026, 0, 5)) / (7 * DAY)) % 2 === 0; break;
      case "Mensual": ok = domOk; break;
      case "Trimestral": ok = domOk && (m - 1) % 3 === 2; break;
      case "Semestral": ok = domOk && (m - 1 === 5 || m - 1 === 11); break;
      case "Anual": ok = domOk && m - 1 === 11; break;
      default: ok = false;
    }
    if (ok) out.push(fecha);
  }
  return out;
}
let genBusy = false;
export async function generarPeriodicas(d) {
  const activas = (d.actividades || []).filter((a) => a.activa !== false);
  if (genBusy || !d.me || d.me.role !== "admin" || !activas.length) return;
  genBusy = true;
  try {
    const from = fechaHito(Date.now()), to = sumarFechaHito(from, 14);
    const ids = activas.map((a) => a.id);
    const { data: guardadas, error: consultaError } = await supabase.from("tasks").select("actividad_id,due").in("actividad_id", ids);
    if (consultaError) throw consultaError;
    const have = new Set([...(d.tasks || []), ...(guardadas || [])].filter((t) => t.actividad_id && t.due).map((t) => t.actividad_id + "|" + fechaHito(due(t))));
    const rows = [];
    activas.forEach((a) => {
      ocurrencias(a, from, to).forEach((fecha) => {
        const key = a.id + "|" + fecha;
        if (have.has(key)) return;
        const ai = areaInfo(a.area) || {}; const p = procInfo(ai.proc || "PLAN") || { tf: "TF1", code: "PLAN" };
        const hh = a.hora || 12;
        rows.push({ title: a.title, area: a.area, tf: p.tf, proc: p.code, member_id: a.member_id, controla: a.controla, evidencia: a.evidencia, actividad_id: a.id, due: horaHitoIso(fecha, hh), stages: [], log: [{ t: "creada (actividad periódica " + (a.codigo || "") + ")", at: Date.now() }] });
        have.add(key);
      });
    });
    if (rows.length) {
      const { error } = await supabase.from("tasks").upsert(rows, { onConflict: "actividad_id,due", ignoreDuplicates: true });
      if (error) throw error;
    }
  } catch (e) { console.warn("No se pudieron generar actividades periódicas:", e && e.message ? e.message : e); }
  finally { genBusy = false; }
}
/* ---------- Pestaña Control ---------- */
export function Control({ d, open, ro }) {
  const [tab, setTab] = useState("reunion");
  const [sheet, setSheet0] = useState(null);
  const setSheet = (x) => { if (!ro || x === null) setSheet0(x); };
  return (
    <>
      <Chips options={[["reunion", "Reunión semanal"], ["resumen", "Resumen"], ["riesgos", "Riesgos"], ["periodicas", "Actividades periódicas"], ["excel", "Exportar Excel"]]} value={tab} onChange={setTab} />
      {tab === "reunion" ? <ReunionSemanal d={d} /> : null}
      {tab === "resumen" ? <Resumen d={d} /> : null}
      {tab === "riesgos" ? <Riesgos d={d} setSheet={setSheet} open={open} /> : null}
      {tab === "periodicas" ? <Periodicas d={d} setSheet={setSheet} /> : null}
      {tab === "excel" ? <Exportar d={d} /> : null}
      {sheet && sheet.k === "riesgo" ? <RiesgoForm d={d} r={sheet.r} onClose={() => setSheet(null)} /> : null}
      {sheet && sheet.k === "act" ? <ActividadForm d={d} a={sheet.a} onClose={() => setSheet(null)} /> : null}
    </>
  );
}

function Stat({ l, n, c }) {
  return <View style={{ flex: 1, backgroundColor: C.surface, borderRadius: 12, borderWidth: 1, borderColor: C.line, padding: 10, alignItems: "center" }}>
    <Text style={{ fontSize: 22, fontWeight: "800", color: c }}>{n}</Text><Text style={{ fontSize: 11, color: C.muted, textAlign: "center" }}>{l}</Text></View>;
}

function Riesgos({ d, setSheet }) {
  const [f, setF] = useState("abiertos");
  const [ar, setAr] = useState("todas");
  const [q, setQ] = useState("");
  const rs = d.riesgos || [];
  const abiertos = rs.filter((r) => !r.cierre);
  const cnt = (n) => abiertos.filter((r) => nivelR(r) === n).length;
  const areas = [...new Set(rs.map((r) => r.area).filter(Boolean))];
  const score = (r) => (r.exposicion_valor != null ? Number(r.exposicion_valor) : (r.probabilidad || 0) * (r.impacto || 0) / 2);
  const list = (f === "abiertos" ? abiertos : f === "cerrados" ? rs.filter((r) => r.cierre) : f === "plan" ? rs.filter((r) => r.plan) : rs)
    .filter((r) => ar === "todas" || r.area === ar)
    .filter((r) => !q || norm([r.codigo, r.descripcion, r.subproceso, r.etapa, r.tipo].join(" ")).includes(norm(q)))
    .slice().sort((a, b) => score(b) - score(a));
  const [lim, setLim] = useState(30);
  return (
    <>
      <Row><Stat l="Abiertos" n={abiertos.length} c={C.ink} /><Stat l="Alto" n={cnt("ALTO")} c={SEM.ALTO} /><Stat l="Medio" n={cnt("MEDIO")} c={SEM.MEDIO} /><Stat l="Bajo" n={cnt("BAJO")} c={SEM.BAJO} /></Row>
      <Row><Stat l="Plan de tratamiento" n={rs.filter((r) => r.plan && !r.cierre).length} c={C.amber} /><Stat l="Acciones pendientes" n={abiertos.filter((r) => r.accion && r.estado_accion !== "Cumplida").length} c={C.amber} /><Stat l="Cerrados" n={rs.length - abiertos.length} c={C.muted} /></Row>
      <Card>
        <Text style={S.label}>Riesgo inherente: probabilidad × impacto (abiertos)</Text>
        {[3, 2, 1].map((p) => (
          <Row key={p}>
            <Text style={{ width: 54, fontSize: 11, color: C.muted }}>{NIV3[p - 1]}</Text>
            {[1, 2, 3].map((i) => { const n = abiertos.filter((r) => r.probabilidad === p && r.impacto === i).length; const lv = nivel(p, i);
              return <View key={i} style={{ flex: 1, height: 38, borderRadius: 8, backgroundColor: SEM[lv], opacity: n ? 1 : 0.25, alignItems: "center", justifyContent: "center" }}><Text style={{ color: "#fff", fontWeight: "800" }}>{n || ""}</Text></View>; })}
          </Row>))}
        <Row><Text style={{ width: 54 }} />{NIV3.map((x) => <Text key={x} style={{ flex: 1, textAlign: "center", fontSize: 11, color: C.muted }}>{x}</Text>)}</Row>
        <Text style={S.small}>Filas: probabilidad · columnas: impacto. El color de cada riesgo en la lista es su exposición después de los controles (matriz CAIGG).</Text>
      </Card>
      <Row><Chips options={[["abiertos", "Abiertos"], ["plan", "Plan de tratamiento"], ["cerrados", "Cerrados"], ["todos", "Todos"]]} value={f} onChange={setF} /></Row>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
        <Chip label="Todas las áreas" on={ar === "todas"} onPress={() => setAr("todas")} />
        {areas.map((a) => { const ai = areaInfo(a); return <Chip key={a} label={ai ? ai.name : a} on={ar === a} color={ai ? ai.color : undefined} onPress={() => setAr(a)} />; })}
      </View>
      <Field label="" value={q} onChangeText={setQ} placeholder="Buscar riesgo, subproceso o etapa" />
      {d.me && d.me.role === "admin" ? <Btn title="+ Nuevo riesgo" kind="primary" onPress={() => setSheet({ k: "riesgo" })} /> : null}
      {list.length ? list.slice(0, lim).map((r) => { const lv = nivelR(r); const ai = areaInfo(r.area);
        return (
          <Card key={r.id} onPress={() => setSheet({ k: "riesgo", r })} style={{ borderLeftWidth: 6, borderLeftColor: SEM[lv] }}>
            <Between><View style={{ backgroundColor: SEM[lv], borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 }}><Text style={{ color: "#fff", fontSize: 11, fontWeight: "800" }}>{r.exposicion ? r.exposicion : lv}</Text></View><Text style={S.small}>{r.codigo} · {r.tipo}{r.plan ? " · PLAN" : ""}</Text></Between>
            <Text style={S.title}>{r.descripcion || "(sin descripción)"}</Text>
            {r.subproceso ? <Text style={S.small}>{r.subproceso}{r.etapa ? " · " + r.etapa : ""}</Text> : null}
            <Text style={S.small}>{ai ? ai.name : "Sin área"}{r.accion ? " · Acción: " + r.accion : ""}</Text>
            <Text style={S.small}>{mname(d.members, r.responsable)}{r.plazo ? " · plazo " + dmy(r.plazo) : ""} · {r.cierre ? "cerrado " + dmy(r.cierre) : r.accion ? r.estado_accion : r.efectividad ? "control " + r.efectividad : r.estado_accion}</Text>
          </Card>); }) : <Empty text="Sin riesgos en esta vista." />}
      {list.length > lim ? <Btn title={"Ver más (" + (list.length - lim) + ")"} onPress={() => setLim(lim + 30)} /> : null}
    </>
  );
}

function Dato({ l, v }) { return v ? <Text style={S.small}><Text style={{ fontWeight: "700" }}>{l}: </Text>{String(v)}</Text> : null; }

function PersonPick({ d, label, value, onChange }) {
  const [q, setQ] = useState("");
  const cands = d.members.filter((m) => m.activo !== false && m.nivel !== "X" && (!q || norm(m.name + " " + m.cargo).includes(norm(q)))).slice(0, q ? 20 : 6);
  return (<>
    <Text style={S.label}>{label}: {value ? mname(d.members, value) : "—"}</Text>
    <Field label="" value={q} onChangeText={setQ} placeholder="Buscar persona" />
    <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{cands.map((m) => <Chip key={m.id} label={m.name} on={value === m.id} onPress={() => onChange(m.id)} />)}</View>
  </>);
}

function RiesgoForm({ d, r, onClose }) {
  const [area, setArea] = useState(r ? r.area : "CDO");
  const [tipo, setTipo] = useState(r ? r.tipo : "Operacional");
  const [desc, setDesc] = useState(r ? r.descripcion : "");
  const [p, setP] = useState(r ? r.probabilidad : 2);
  const [i, setI] = useState(r ? r.impacto : 2);
  const [acc, setAcc] = useState(r ? r.accion || "" : "");
  const [resp, setResp] = useState(r ? r.responsable : (areaInfo("CDO") || {}).owner);
  const [plazo, setPlazo] = useState(r && r.plazo ? dmy(r.plazo) : "");
  const [est, setEst] = useState(r ? r.estado_accion : "Pendiente");
  const lv = nivel(p, i);
  async function save(cerrar) {
    if (!desc.trim()) return Alert.alert("Describe el riesgo o hallazgo.");
    const body = { area, tipo, descripcion: desc.trim(), probabilidad: p, impacto: i, accion: acc.trim(), responsable: resp, plazo: toIso(plazo), estado_accion: est };
    if (cerrar) { body.cierre = iso(Date.now()); body.estado_accion = "Cumplida"; }
    if (!r) body.codigo = "R-" + String((d.riesgos || []).length + 1).padStart(3, "0");
    const q = r ? supabase.from("riesgos").update(body).eq("id", r.id) : supabase.from("riesgos").insert(body);
    const { error } = await q; if (error) return Alert.alert("No se pudo guardar", errMsg(error)); onClose();
  }
  return (
    <Sheet visible title={r ? "Riesgo " + r.codigo : "Nuevo riesgo"} onClose={onClose}>
      <Text style={S.label}>Área</Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{AREAS.map((a) => <Chip key={a[0]} label={a[1]} on={area === a[0]} color={AREA_COLORS[a[2]]} onPress={() => { setArea(a[0]); if (!r) setResp(a[3]); }} />)}</View>
      <Text style={S.label}>Tipo</Text>
      <Chips options={TIPOS_RIESGO.map((x) => [x, x])} value={tipo} onChange={setTipo} />
      <Field label="Descripción del riesgo / hallazgo" value={desc} onChangeText={setDesc} multiline />
      <Text style={S.label}>Probabilidad</Text><Chips options={[[1, "Baja"], [2, "Media"], [3, "Alta"]]} value={p} onChange={setP} />
      <Text style={S.label}>Impacto</Text><Chips options={[[1, "Bajo"], [2, "Medio"], [3, "Alto"]]} value={i} onChange={setI} />
      <View style={{ backgroundColor: SEM[lv], borderRadius: 10, padding: 10, alignItems: "center" }}><Text style={{ color: "#fff", fontWeight: "800" }}>NIVEL INHERENTE {lv}</Text></View>
      {r && r.subproceso ? <Card>
        <Text style={S.label}>Matriz CAIGG</Text>
        <Dato l="Proceso" v={r.proceso} /><Dato l="Subproceso" v={r.subproceso} /><Dato l="Etapa" v={r.etapa} />
        <Dato l="Fuente" v={r.fuente} /><Dato l="Severidad (1-5)" v={r.severidad ? r.severidad + " · P" + r.prob5 + " × I" + r.imp5 : ""} />
        <Dato l="Control existente" v={r.control} /><Dato l="Efectividad del control" v={r.efectividad} />
        <Dato l="Exposición residual" v={r.exposicion ? r.exposicion + " (" + r.exposicion_valor + ")" : ""} />
        <Dato l="Señal LA/FT/DF" v={r.senal} /><Dato l="Cargo relacionado" v={r.cargo} />
        <Dato l="Indicador" v={r.indicador} /><Dato l="Meta" v={r.meta} />
        {r.task_id ? <Text style={[S.small, { color: C.accent }]}>Tiene tarea asignada en la app (plan de tratamiento).</Text> : null}
      </Card> : null}
      <Field label="Acción de tratamiento" value={acc} onChangeText={setAcc} multiline />
      <PersonPick d={d} label="Responsable de la acción" value={resp} onChange={setResp} />
      <Field label="Plazo (dd-mm-aaaa)" value={plazo} onChangeText={setPlazo} />
      <Text style={S.label}>Estado de la acción</Text><Chips options={ESTADOS_ACCION.map((x) => [x, x])} value={est} onChange={setEst} />
      <Btn title="Guardar" kind="primary" onPress={() => save(false)} />
      {r && !r.cierre ? <Btn title="Cerrar riesgo (hoy)" onPress={() => save(true)} /> : null}
      {r ? <Btn title="Eliminar" kind="danger" onPress={async () => { await supabase.from("riesgos").delete().eq("id", r.id); onClose(); }} /> : null}
    </Sheet>);
}

function Periodicas({ d, setSheet }) {
  const acts = (d.actividades || []).slice().sort((a, b) => (a.codigo || "").localeCompare(b.codigo || ""));
  const next = (a) => d.tasks.filter((t) => t.actividad_id === a.id && !t.done).sort((x, y) => due(x) - due(y))[0];
  const desc = (a) => a.periodicidad + (a.periodicidad === "Semanal" || a.periodicidad === "Quincenal" ? " · " + DIAS[a.dia || 1] : a.periodicidad !== "Según disposición" ? " · día " + (a.dia || 1) : "");
  return (
    <>
      <Note text="Cada actividad crea sola sus tareas con 14 días de anticipación, con su responsable, quién controla y la evidencia requerida." />
      {d.me && d.me.role === "admin" ? <Btn title="+ Nueva actividad periódica" kind="primary" onPress={() => setSheet({ k: "act" })} /> : null}
      {acts.length ? acts.map((a) => { const ai = areaInfo(a.area); const n = next(a); return (
        <Card key={a.id} onPress={() => setSheet({ k: "act", a })} style={ai ? { borderLeftWidth: 6, borderLeftColor: ai.color } : null}>
          <Between><Text style={S.small}>{a.codigo} · {ai ? ai.name : ""}</Text><Text style={{ fontSize: 11, fontWeight: "800", color: a.prioridad === "ALTA" ? C.red : a.prioridad === "MEDIA" ? C.amber : C.muted }}>{a.prioridad}</Text></Between>
          <Text style={S.title}>{a.title}{a.activa === false ? " (pausada)" : ""}</Text>
          <Text style={S.small}>{desc(a)} · {dmy(a.desde)} al {dmy(a.hasta)}</Text>
          <Text style={S.small}>Responsable {mname(d.members, a.member_id)} · controla {mname(d.members, a.controla)}{a.evidencia ? " · evidencia: " + a.evidencia : ""}</Text>
          <Text style={S.small}>{n ? "Próxima: " + fmt(due(n)) : "Sin tareas próximas"}</Text>
        </Card>); }) : <Empty text="Sin actividades periódicas." />}
    </>
  );
}

function ActividadForm({ d, a, onClose }) {
  const [title, setTitle] = useState(a ? a.title : "");
  const [area, setArea] = useState(a ? a.area : "OCGR");
  const [per, setPer] = useState(a ? a.periodicidad : "Mensual");
  const [dia, setDia] = useState(a ? a.dia || 1 : 5);
  const [hora, setHora] = useState(String(a ? a.hora || 12 : 12));
  const [pri, setPri] = useState(a ? a.prioridad : "MEDIA");
  const [who, setWho] = useState(a ? a.member_id : (areaInfo("OCGR") || {}).owner);
  const [ctl, setCtl] = useState(a ? a.controla : "m-cerda");
  const [ev, setEv] = useState(a ? a.evidencia || "" : "");
  const [desde, setDesde] = useState(a && a.desde ? dmy(a.desde) : dmy(iso(Date.now())));
  const [hasta, setHasta] = useState(a && a.hasta ? dmy(a.hasta) : "31-12-2026");
  const [activa, setActiva] = useState(a ? a.activa !== false : true);
  const semanal = per === "Semanal" || per === "Quincenal";
  async function save() {
    if (!title.trim()) return Alert.alert("Escribe el nombre de la actividad.");
    const body = { title: title.trim(), area, periodicidad: per, dia: Number(dia) || 1, hora: Math.min(23, Math.max(0, Number(hora) || 12)), prioridad: pri, member_id: who, controla: ctl, evidencia: ev.trim(), desde: toIso(desde), hasta: toIso(hasta), activa };
    if (!a) body.codigo = "CAL-" + String((d.actividades || []).length + 1).padStart(3, "0");
    const { error } = a ? await supabase.from("actividades").update(body).eq("id", a.id) : await supabase.from("actividades").insert(body);
    if (error) return Alert.alert("No se pudo guardar", errMsg(error)); onClose();
  }
  return (
    <Sheet visible title={a ? "Actividad " + a.codigo : "Nueva actividad periódica"} onClose={onClose}>
      <Field label="Actividad / hito" value={title} onChangeText={setTitle} placeholder="Ej.: Control de liquidez de centros de costo" />
      <Text style={S.label}>Área</Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{AREAS.map((x) => <Chip key={x[0]} label={x[1]} on={area === x[0]} color={AREA_COLORS[x[2]]} onPress={() => { setArea(x[0]); if (!a) setWho(x[3]); }} />)}</View>
      <Text style={S.label}>Periodicidad</Text><Chips options={PERIODOS.map((x) => [x, x])} value={per} onChange={setPer} />
      {per !== "Según disposición" ? (semanal
        ? <><Text style={S.label}>Día</Text><Chips options={DIAS.slice(1).map((x, k) => [k + 1, x])} value={Number(dia)} onChange={setDia} /></>
        : <Field label="Día del mes (1–31; si el mes es más corto se usa el último)" value={String(dia)} onChangeText={setDia} keyboardType="number-pad" />) : <Note text="“Según disposición” no crea tareas solas; queda como referencia en el calendario maestro." />}
      <Field label="Hora de plazo (0–23)" value={hora} onChangeText={setHora} keyboardType="number-pad" />
      <Text style={S.label}>Prioridad</Text><Chips options={PRIORIDADES.map((x) => [x, x])} value={pri} onChange={setPri} />
      <PersonPick d={d} label="Responsable primario" value={who} onChange={setWho} />
      <PersonPick d={d} label="Controla" value={ctl} onChange={setCtl} />
      <Field label="Producto / evidencia" value={ev} onChangeText={setEv} placeholder="Ej.: PPT, acta, informe" />
      <Row><View style={{ flex: 1 }}><Field label="Desde" value={desde} onChangeText={setDesde} /></View><View style={{ flex: 1 }}><Field label="Hasta" value={hasta} onChangeText={setHasta} /></View></Row>
      <Chips options={[[true, "Activa"], [false, "Pausada"]]} value={activa} onChange={setActiva} />
      <Btn title="Guardar" kind="primary" onPress={save} />
      {a ? <Btn title="Eliminar actividad" kind="danger" onPress={async () => { await supabase.from("actividades").delete().eq("id", a.id); onClose(); }} /> : null}
    </Sheet>);
}

/* ---------- Exportar a Excel ---------- */
function Exportar({ d }) {
  const [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true);
    try {
      const nm = (id) => mname(d.members, id);
      const an = (c) => (areaInfo(c) || {}).name || c || "";
      const corte = fmtDay(Date.now());
      const tareas = d.tasks.map((t) => ({ "Área": an(t.area), "Tarea": t.title, "TF": t.tf, "Proceso": t.proc, "Responsable": nm(t.member_id), "Controla": t.controla ? nm(t.controla) : "", "Plazo": new Date(due(t)), "Estado": { over: "Atrasada", soon: "Próxima a vencer", ok: "En plazo", done: "Cumplida" }[status(t)], "Avance %": t.done ? 100 : t.progress || 0, "Escalamiento": t.escalar ? "SÍ" : "NO", "Evidencia": t.evidencia || "", "Días": Math.round((due(t) - Date.now()) / DAY) }))
        .sort((a, b) => a["Plazo"] - b["Plazo"]);
      const acts = (d.actividades || []).map((a) => ({ "ID": a.codigo, "Área": an(a.area), "Actividad / Hito": a.title, "Periodicidad": a.periodicidad, "Día": a.periodicidad === "Semanal" || a.periodicidad === "Quincenal" ? DIAS[a.dia || 1] : a.dia, "Desde": a.desde, "Hasta": a.hasta, "Responsable primario": nm(a.member_id), "Controla": nm(a.controla), "Producto / Evidencia": a.evidencia, "Prioridad": a.prioridad, "Activa": a.activa === false ? "NO" : "SÍ" }));
      const ries = (d.riesgos || []).map((r) => ({ "ID Riesgo": r.codigo, "Área": an(r.area), "Tipo": r.tipo, "Descripción": r.descripcion, "Probabilidad": NIV3[(r.probabilidad || 1) - 1], "Impacto": NIV3[(r.impacto || 1) - 1], "Nivel": nivelR(r), "Proceso": r.proceso || "", "Subproceso": r.subproceso || "", "Etapa": r.etapa || "", "Control": r.control || "", "Efectividad": r.efectividad || "", "Exposición residual": r.exposicion || "", "Plan tratamiento": r.plan ? "Sí" : "", "Acción": r.accion, "Responsable": nm(r.responsable), "Plazo": r.plazo, "Estado acción": r.estado_accion, "Cierre": r.cierre || "" }));
      const open = d.tasks.filter((t) => !t.done);
      const dash = [["SISTEMA MAESTRO DE CONTROL · ZB ARICA"], ["Corte", corte], [], ["Indicador", "Cantidad"],
        ["Total de tareas", d.tasks.length], ["Cumplidas", d.tasks.filter((t) => t.done).length], ["Pendientes", open.length],
        ["Atrasadas", open.filter((t) => status(t) === "over").length], ["Próximas a vencer (48 h)", open.filter((t) => status(t) === "soon").length],
        ["Requieren escalamiento", open.filter((t) => t.escalar).length], [], ["Riesgos abiertos", (d.riesgos || []).filter((r) => !r.cierre).length],
        ...["ALTO", "MEDIO", "BAJO", "PENDIENTE"].map((n) => ["Riesgos " + n, (d.riesgos || []).filter((r) => !r.cierre && nivelR(r) === n).length]),
        ["Riesgos cerrados", (d.riesgos || []).filter((r) => r.cierre).length]];
      const wb = XLSX.utils.book_new();
      const add = (name, rows, w) => { const ws = Array.isArray(rows[0]) ? XLSX.utils.aoa_to_sheet(rows) : XLSX.utils.json_to_sheet(rows.length ? rows : [{ "Sin datos": "" }]); if (w) ws["!cols"] = w.map((x) => ({ wch: x })); XLSX.utils.book_append_sheet(wb, ws, name); };
      add("01_Dashboard", dash, [34, 14]);
      add("02_Tareas", tareas, [24, 60, 6, 9, 32, 26, 18, 16, 9, 12, 20, 7]);
      add("03_Calendario_Maestro", acts, [8, 24, 50, 14, 10, 12, 12, 30, 26, 22, 9, 7]);
      add("04_Matriz_Riesgos", ries, [9, 24, 14, 60, 11, 9, 10, 40, 30, 12, 13, 12]);
      const bytes = new Uint8Array(XLSX.write(wb, { type: "array", bookType: "xlsx" }));
      if (Platform.OS === "web") {
        const blob = new Blob([bytes], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
        const url = URL.createObjectURL(blob); const a = document.createElement("a");
        a.href = url; a.download = "Control_ZB_Arica_" + iso(Date.now()) + ".xlsx"; document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 5000); setBusy(false); return;
      }
      const f = new File(Paths.cache, "Control_ZB_Arica_" + iso(Date.now()) + ".xlsx");
      if (f.exists) f.delete();
      f.create(); f.write(bytes);
      await Sharing.shareAsync(f.uri, { mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", dialogTitle: "Control ZB Arica" });
    } catch (e) { Alert.alert("No se pudo exportar", String((e && e.message) || e)); }
    setBusy(false);
  }
  return (
    <>
      <Note text="Genera una planilla Excel con el dashboard, todas las tareas, el calendario maestro y la matriz de riesgos, lista para enviar o imprimir." />
      <Btn title={busy ? "Generando…" : "Exportar a Excel"} kind="primary" disabled={busy} onPress={go} />
    </>
  );
}

/* ---------- Resumen de cumplimiento total y por áreas ---------- */
function Resumen({ d }) {
  const [per, setPer] = useState("todo");
  const now = Date.now(); const hoy = startOfDay(now);
  const desde = per === "semana" ? addDays(hoy, -((new Date(hoy).getDay() + 6) % 7)) : per === "mes" ? new Date(new Date(hoy).getFullYear(), new Date(hoy).getMonth(), 1).getTime() : 0;
  const hasta = per === "semana" ? addDays(desde, 7) : per === "mes" ? new Date(new Date(hoy).getFullYear(), new Date(hoy).getMonth() + 1, 1).getTime() : Infinity;
  const ts = d.tasks.filter((t) => { const x = due(t); return x >= desde && x < hasta; });
  const calc = (list) => {
    const hechas = list.filter((t) => t.done), venc = list.filter((t) => !t.done && due(t) < now), pend = list.filter((t) => !t.done && due(t) >= now);
    const aTiempo = hechas.filter((t) => !t.late && (!t.done_at || new Date(t.done_at).getTime() <= due(t))).length;
    const exig = hechas.length + venc.length;
    return { n: list.length, h: hechas.length, v: venc.length, p: pend.length, at: aTiempo, pct: exig ? Math.round(100 * hechas.length / exig) : null };
  };
  const tot = calc(ts);
  const col = (p) => p == null ? C.muted : p >= 85 ? C.accent : p >= 60 ? C.amber : C.red;
  const porGrupo = AREA_GROUPS.map(([g, n]) => ({ g, n, areas: AREAS.filter((a) => a[2] === g).map((a) => ({ a, r: calc(ts.filter((t) => t.area === a[0])) })).filter((x) => x.r.n), r: calc(ts.filter((t) => (areaInfo(t.area) || {}).group === g)) })).filter((x) => x.r.n);
  const sinArea = calc(ts.filter((t) => !areaInfo(t.area)));
  function compartir() {
    const L = ["RESUMEN DE CUMPLIMIENTO · ZB ARICA", per === "todo" ? "Todas las tareas" : per === "mes" ? "Mes en curso" : "Semana en curso", fmtDay(now), "",
      "TOTAL " + tot.n + " · hechas " + tot.h + " · vencidas sin cumplir " + tot.v + " · pendientes en plazo " + tot.p + (tot.pct != null ? " · cumplimiento " + tot.pct + "%" : ""), ""];
    porGrupo.forEach((x) => { L.push(x.n.toUpperCase() + ": " + x.r.h + " hechas / " + x.r.v + " vencidas / " + x.r.p + " pendientes" + (x.r.pct != null ? " (" + x.r.pct + "%)" : ""));
      x.areas.forEach((y) => L.push("  • " + y.a[1] + ": " + y.r.h + "/" + y.r.v + "/" + y.r.p + (y.r.pct != null ? " (" + y.r.pct + "%)" : ""))); });
    Share.share({ message: L.join("\n") }).catch(() => {});
  }
  const Fila = ({ l, r, bold, color }) => (
    <Row style={{ paddingVertical: 4 }}>
      <Text style={{ flex: 1, fontSize: 13, color: color || C.ink, fontWeight: bold ? "800" : "400" }} numberOfLines={2}>{l}</Text>
      <Text style={{ width: 44, textAlign: "center", color: C.accent, fontWeight: "700" }}>{r.h}</Text>
      <Text style={{ width: 44, textAlign: "center", color: C.red, fontWeight: "700" }}>{r.v}</Text>
      <Text style={{ width: 44, textAlign: "center", color: C.ink2 }}>{r.p}</Text>
      <Text style={{ width: 48, textAlign: "right", color: col(r.pct), fontWeight: "800" }}>{r.pct == null ? "—" : r.pct + "%"}</Text>
    </Row>);
  return (
    <>
      <Chips options={[["todo", "Todo"], ["mes", "Este mes"], ["semana", "Esta semana"]]} value={per} onChange={setPer} />
      <Row><Stat l="Tareas" n={tot.n} c={C.ink} /><Stat l="Hechas" n={tot.h} c={C.accent} /><Stat l="Vencidas sin cumplir" n={tot.v} c={C.red} /><Stat l="Pendientes en plazo" n={tot.p} c={C.ink2} /></Row>
      <Card>
        <Between><Text style={S.label}>Cumplimiento total</Text><Text style={{ fontSize: 26, fontWeight: "800", color: col(tot.pct) }}>{tot.pct == null ? "—" : tot.pct + "%"}</Text></Between>
        <View style={{ height: 10, borderRadius: 5, backgroundColor: C.surface2, overflow: "hidden", flexDirection: "row" }}>
          <View style={{ flex: tot.h || 0, backgroundColor: C.accent }} /><View style={{ flex: tot.v || 0, backgroundColor: C.red }} /><View style={{ flex: tot.p || 0, backgroundColor: C.line2 }} />
        </View>
        <Text style={S.small}>{tot.at} de {tot.h} hechas a tiempo. El % se calcula sobre lo exigible (hechas + vencidas); lo pendiente en plazo no descuenta.</Text>
      </Card>
      <Card>
        <Row style={{ borderBottomWidth: 1, borderColor: C.line, paddingBottom: 4 }}>
          <Text style={[S.small, { flex: 1 }]}>Área</Text><Text style={[S.small, { width: 44, textAlign: "center" }]}>Hechas</Text><Text style={[S.small, { width: 44, textAlign: "center" }]}>Venc.</Text><Text style={[S.small, { width: 44, textAlign: "center" }]}>Pend.</Text><Text style={[S.small, { width: 48, textAlign: "right" }]}>%</Text>
        </Row>
        {porGrupo.map((x) => (
          <View key={x.g} style={{ borderBottomWidth: 1, borderColor: C.line, paddingVertical: 4 }}>
            <Fila l={x.n} r={x.r} bold color={AREA_COLORS[x.g]} />
            {x.areas.map((y) => <Fila key={y.a[0]} l={"   " + y.a[1]} r={y.r} />)}
          </View>))}
        {sinArea.n ? <Fila l="Sin área asignada" r={sinArea} /> : null}
        <Fila l="TOTAL" r={tot} bold />
      </Card>
      <Btn title="Compartir resumen" kind="primary" onPress={compartir} />
      <Descargar titulo={"Resumen de cumplimiento " + (per === "todo" ? "total" : per === "mes" ? "del mes" : "de la semana")} build={() => ({ notas: "Cumplimiento total " + (tot.pct == null ? "—" : tot.pct + "%") + " · " + tot.h + " hechas, " + tot.v + " vencidas, " + tot.p + " pendientes", hojas: [{ nombre: "Por área", filas: [["Grupo", "Área", "Tareas", "Hechas", "Vencidas", "Pendientes", "% cumplimiento"]].concat(porGrupo.flatMap((x) => [[x.n, "TOTAL " + x.n, x.r.n, x.r.h, x.r.v, x.r.p, x.r.pct == null ? "—" : x.r.pct + "%"]].concat(x.areas.map((y) => [x.n, y.a[1], y.r.n, y.r.h, y.r.v, y.r.p, y.r.pct == null ? "—" : y.r.pct + "%"])))).concat([["", "TOTAL ZONA", tot.n, tot.h, tot.v, tot.p, tot.pct == null ? "—" : tot.pct + "%"]]) }] })} />
    </>
  );
}
