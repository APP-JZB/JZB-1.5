// Revisión en segundo plano (Android): cada ~15–30 min consulta la base de datos
// aunque la app esté cerrada, avisa lo nuevo y reprograma los recordatorios de plazo.
import * as TaskManager from "expo-task-manager";
import * as BackgroundTask from "expo-background-task";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { supabase } from "./lib";
import { avisosActivos, diffAlerts, reschedule } from "./notify";

const TASK = "hito-revision";
const KEY = "hito-bg-snap";

export function snapshot(d) {
  return {
    loaded: true, me: d.me,
    tasks: d.tasks.map((t) => ({ id: t.id, member_id: t.member_id, apoyo: t.apoyo, delegado: t.delegado, participantes: t.participantes, title: t.title, due: t.due, done: t.done })),
    prorrogas: d.prorrogas.map((p) => ({ id: p.id, status: p.status, motivo: p.motivo, comment: p.comment })),
    events: d.events.map((e) => ({ id: e.id, by_member: e.by_member, title: e.title })),
    posts: d.posts.map((p) => ({ id: p.id, title: p.title })),
    members: (d.members || []).map((m) => ({ id: m.id, name: m.name })),
    avisos: d.avisos ? d.avisos.map((x) => ({ id: x.id })) : undefined,
  };
}
export async function guardarSnapshot(d) { try { await AsyncStorage.setItem(KEY, JSON.stringify(snapshot(d))); } catch (e) {} }

export async function revisarFondo() {
  if (!(await avisosActivos())) return;
  const { data: s } = await supabase.auth.getSession();
  if (!s || !s.session) return;
  const uid = s.session.user.id;
  const [m, t, p, e, po, av] = await Promise.all([
    supabase.from("members").select("id,name,role,user_id,unit"),
    supabase.from("tasks").select("id,member_id,apoyo,delegado,participantes,title,due,done").eq("done", false),
    supabase.from("prorrogas").select("id,status,motivo,comment"),
    supabase.from("events").select("id,by_member,title").order("created_at", { ascending: false }).limit(50),
    supabase.from("posts").select("id,title").order("created_at", { ascending: false }).limit(30),
    supabase.from("avisos_admin").select("id,actor,titulo,detalle").order("created_at", { ascending: false }).limit(50),
  ]);
  if ([m, t, p, e, po].some((r) => r.error)) return;
  const me = (m.data || []).find((x) => x.user_id === uid);
  if (!me) return;
  const nd = { loaded: true, me, members: m.data, tasks: t.data || [], prorrogas: p.data || [], events: e.data || [], posts: po.data || [], avisos: (av && !av.error && av.data) || undefined };
  let prev = null; try { prev = JSON.parse((await AsyncStorage.getItem(KEY)) || "null"); } catch (x) {}
  if (prev && prev.me && prev.me.id === me.id) {
    diffAlerts(prev, nd);
  }
  await reschedule(nd);
  await AsyncStorage.setItem(KEY, JSON.stringify(snapshot(nd)));
}

TaskManager.defineTask(TASK, async () => {
  try { await revisarFondo(); return BackgroundTask.BackgroundTaskResult.Success; }
  catch (e) { return BackgroundTask.BackgroundTaskResult.Failed; }
});

export async function registrarFondo() {
  try {
    const st = await BackgroundTask.getStatusAsync();
    if (st !== BackgroundTask.BackgroundTaskStatus.Available) return false;
    if (!(await TaskManager.isTaskRegisteredAsync(TASK))) await BackgroundTask.registerTaskAsync(TASK, { minimumInterval: 15 });
    return true;
  } catch (e) { return false; }
}
