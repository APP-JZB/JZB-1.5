export const PERFILES_CARGO = [
  {
    "file": "01-2-Administrador-de-Contratos.txt",
    "title": "ADMINISTRADOR DE CONTRATOS",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — — Cuadro Permanente, Personal Civil\nGrado: — — CB1 / PAC (T) / TCC (T)\nEscalafón: — — Intendencia / Personal Civil\nEspecialidad Primaria: — — ----------\nEspecialidad Secundaria: — — ----------\nTítulo profesional o técnico:\n(Para personal civil) — Deseable — Técnico en Administración o Finanzas, titulado en Colegio Técnico o Instituto.\nConocimientos técnicos o de gestión: — Requerido — Enseñanza Media.\nManejo Microsoft Office.\nAcreditación como Operador de Chilecompras.\nIdioma: — Deseable — Ingles nivel Básico.\nExperiencia laboral: — Deseable — Experiencia de 02 años en cargos vinculador a Mercado Público."
      },
      {
        "heading": "misión del cargo",
        "text": "Garantizar y gestionar, en su calidad de Operador de Mercado Público con atribución de Administrador de Contratos, el cumplimiento de las clausulas de los contratos de suministros de bienes, servicios y obras, ejecutados a través de Licitaciones Públicas y Tratos Directos, tanto para aquellos mayores o menores a 1000 UTM, mediante el seguimiento continuo, según los requerimientos y lineamientos entre esta Zona de Bienestar y las empresas."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Jefe Sección Apoyo General\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Comandante de Zona Bienestar, Jefe de la Plana Mayor, Asesor Jurídico, Jefe Oficina Finanzas, Jefes de Centros de Costos, Centro de Gestión de Adquisiciones de la Zona de Bienestar, Depto. Logística del COB, Área Adquisiciones.\nCargo(s) de personal subordinado: — -----------"
      },
      {
        "heading": "funciones y tareas principales",
        "text": "FUNCIONES — TAREAS\n1. — Administrar, corregir y fiscalizar las tareas inherentes al área de los contratos de suministros en sus diferentes funciones. — • Asegurar el cumplimiento del contrato, dentro de los principios legales, administrativos y financieros, mediante la determinación y la revisión de los requisitos del cliente, durante el proceso de contratación y la ejecución del proyecto.\n• Obtener el acta de inicio del contrato, carta de autorización o carta de intención firmada entre las partes.\n• Elaborar el cierre administrativo del contrato y obtener la documentación que soporte la complementación monetaria de la obra de acuerdo a lo establecido por contrato.\n• Recibir y revisar los antecedentes de la licitación ya adjudicada, de parte del CGA.\n• Publicar los antecedentes de las licitaciones adjudicadas en el Portal Mercado Público.\n• Controlar el cumplimiento de los contratos de suministros y/o servicios."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1 — Compromiso institucional — — — 4\n2 — Adaptación y Flexibilidad — — — 4\n3 — Iniciativa y autonomía — — — 4\n4 — Planificación y organización — — — 4\n5 — Trabajo en equipo — — — 4"
      },
      {
        "heading": "observaciones",
        "text": "El cargo requiere sólidos conocimientos de la Ley y Reglamento de Compras Públicas y mantener acreditación vigente en el Mercado Publico."
      }
    ],
    "aliases": [
      "administrador de contratos"
    ]
  },
  {
    "file": "01-7-Asesor-de-Planificaci-n.txt",
    "title": "ASESOR ADMINISTRATIVO DE BIENESTAR",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — Requerido — Personal Civil de procedencia militar\nGrado: — — PAC (A) / TCC (A)\nEscalafón: — — Personal Civil\nEspecialidad Primaria: — — -----------\nEspecialidad Secundaria: — — -----------\nTítulo profesional o técnico: — Requerido — Oficial de Ejército\nConocimientos técnicos o de gestión: — Deseable — Con especialización en planificación\nCon conocimientos de computación (nivel usuario)\nIdioma: — — -----------\nExperiencia laboral: — Deseable — Haberse desempeñado como Asesor de Planificación en CGs de UACs o Secc. 3ª de URs."
      },
      {
        "heading": "misión del cargo",
        "text": "Proponer la planificación estratégica al Comandante de la Zona de Bienestar, orientada al cumplimiento de las misiones y los objetivos estratégicos del Comando de Bienestar."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Jefe Administrativo\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Comandante de Zona Bienestar, Jefe Administrativo, Jefes Secciones Habitacional, Asistencial, Recreacional y Apoyo, Con sus homólogos de los Deptos. del CG del COB, de ARs, Cdos. y CGs de UACs..\nCargo(s) de personal subordinado: — -------"
      },
      {
        "heading": "FUNCIONES Y TAREAS PRINCIPALES",
        "text": "FUNCIONES — TAREAS\n1. — Asesorar al Comandante de la Zona de Bienestar en materias de planificación estratégicas. — • Elaborar y proponer la totalidad de la documentación de carácter estratégico de la Zona de Bienestar\n• Elaborar los estudios y/o emitir su opinión fundada respecto de materias propias del ámbito estratégico que le sean solicitadas a la Zona de Bienestar.\n2. — Evaluar y proponer actualización de los procedimientos del nivel estratégico que ejecuta la Zona de Bienestar. — • Controlar que se mantenga actualizada la planificación estratégica de la Zona de Bienestar y su documentación de respaldo.\n• Proponer oportunamente las modificaciones a la planificación estratégica de la Zona de Bienestar necesarias para mantener y mejorar el desarrollo de la Zona de Bienestar en su gestión de bienestar.\n3. — Mantener actualizado el Cuadro de Mando de la Unidad — Chequeo y corrección de las siguientes materias:\n• Tabla de Distribución.\n• Organigramas.\n• Mapas Funcionales y de Macroprocesos.\n• Procesos y flujogramas.\n• Descriptores y Perfiles de Cargos."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1 — Asesoría — — — 4\n2 — Pensamiento analítico y sistémico — — — 3\n3 — Planificación y organización — — — 3\n4 — Calidad y metodicidad — — — 3\n5 — Trabajo en equipo — — — 3"
      },
      {
        "heading": "observaciones",
        "text": "El cargo requiere mantener actualizados los procesos de Control de Gestión, elaboración de Matrices de Riesgos de la Unidad y respuestas de pre informes y/o informes de auditorías y/o revistas inspectoras que realicen los estamentos contralores del Ejército. Elaboración de toda la documentación directiva de la Unidad. Elaboración de la Memoria Institucional de la Unidad e informes para la memoria del Escalón Superior. Elaboración de las presentaciones que realice el Comandante de ZB."
      }
    ],
    "aliases": [
      "asesor administrativo de bienestar",
      "asesor de planificación",
      "oficina de planificación"
    ]
  },
  {
    "file": "02-2-T-cnico-Administraci-n-de-Personal.txt",
    "title": "TÉCNICO EN ADMINISTRACIÓN DE PERSONAL",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — — Cuadro Permanente - Personal Civil\nGrado: — — SG1 / SG2-CB1-CB2 / PAC (T) / TCC (T)\nEscalafón: — — Servicio de Personal (Ayudantía General) /\nDe Servicios / Personal Civil\nEspecialidad Primaria: — — -------\nEspecialidad Secundaria: — — -------\nTítulo profesional o técnico:\n(Para personal civil) — Requerido — Técnico en Administración de Recursos Humanos\nConocimientos técnicos o de gestión: — Deseable — Manejo avanzado de Excel, Word y PowerPoint, conocimiento cabal del DFL. 1, Código del Trabajo, CARPROS. Reglamento de Disciplina para las Fas. Ley Orgánica Constitucional de las FAs.\nIdioma: — — -------\nExperiencia laboral: — Deseable — Haber trabajado como mínimo, dos años en trabajos similares a los del área de personal."
      },
      {
        "heading": "misión del cargo",
        "text": "Ejecutar planes y programas pertinentes a la administración de personal a fin de contribuir con el desarrollo de los procesos administrativos relacionados con la gestión del área de personal."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Jefe de la Plana Mayor\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Grupo Personal de Comandante de ZB, Secciones Habitacional, Asistencial, Recreacional y Apoyo General, Depto. Personal del COB.,\nCargo(s) de personal subordinado: — -------"
      },
      {
        "heading": "funciones y tareas principales",
        "text": "FUNCIONES — TAREAS\n1. — Ejecutar los procesos de selección de personal.\n\n• Solicitar y hacer seguimiento de todos los documentos exigidos para contratación de personal.\n• Contactar telefónicamente a los aspirantes a entrevista y a los que serán contratados.\n• Diligenciar formatos de afiliaciones a seguridad social y caja de compensación del personal civil contratado\n2. — Mantener actualizados los antecedentes del personal de la ZB\n\n• Mantener actualizadas las Carpetas de Antecedentes Personales (TAPs y HAO.)\n• Fotocopiar y archivar la documentación referida al proceso de calificaciones de oficiales, cuadro permanente y empleados civiles (Hojas de Vida y hojas de calificaciones).\n3. — Mantener actualizado el cargo de reglamentos y cartillas de procedimiento\n• Solicitar al GEOMIL, las peticiones de reglamentos, documentación relativa al proceso de calificación, CARPROS, CAPs., TAPS y HAO.\n4. — Mantener archivo organizado de la documentación\n\n• Mantener la documentación salida y llegada del año en curso, en los respectivos archivadores.\n• Archivar la documentación pasiva, separadas por años.\n• Recibir y llevar para el registro la documentación referida al área de recursos humanos.\n5. — Realizar funciones propias del cargo.\n\n• Entregar las respectivas liquidaciones de sueldo al personal de dotación de la ZB.\n• Efectuar trámites diversos concernientes a las actividades de la unidad y ante organismos públicos y privados.\n• Elaboración de certificados diversos solicitados por el personal.\n• Tramitación formularios multipropósitos para reconocimientos de asignaciones familiares, cambios de estado civil, etc.\n• Solicitudes de diplomas por ascensos, condecoraciones y medallas.\n• Elaboración de los estados de fuerza y mantener actualizadas las relaciones del personal.\n• Elaboración de TIM y TIFAS y mantener actualizado los recibos de control de estos formularios entregados al personal\n• Elaboración de las ROCR.\n• Revisión mensual de las novedades en las liquidaciones de sueldo (pagos no efectuados, asignaciones indebidas, etc.)\n• Remitir al COB, fotografías por ascenso y destinación del personal.\n• Elaborar cuando corresponda, la declaración de patrimonio y de intereses de los oficiales superiores y entregarlos en la Contraloría Regional, con copia al COP y COB.\n6. — Controlará, asesorará y apoyará los requerimientos del personal civil.\n\n• Concurrir cuando sea del caso al COMPIN, paran entregar las licencias médicas del personal civil.\n• Mantener actualizado el libro de control de llegada y salida de personal civil."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1 — Calidad y metodicidad en el trabajo — — — 4\n2 — Pensamiento analítico y sistémico — — — 3\n3 — Manejo de crisis y contingencias — — — 2\n4 — Orientación y servicio a las personas — — — 2\n5 — Trabajo en equipo — — — 2"
      },
      {
        "heading": "observaciones",
        "text": "El cargo no registra observaciones."
      }
    ],
    "aliases": [
      "técnico en administración de personal",
      "técnico administración de personal",
      "oficina de personal"
    ]
  },
  {
    "file": "02-7-Asistente-Mozo-Mod.-ZB-Arica.txt",
    "title": "ASISTENTE MOZO",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — — Personal Civil\nGrado: — — PAC (A) / PAJ / TCC (A)\nEscalafón: — — Personal Civil\nEspecialidad Primaria: — — ----------\nEspecialidad Secundaria: — — ----------\nTítulo profesional o técnico:\n(Para personal civil) — Requerido — Licencia Enseñanza Media\nConocimientos técnicos o de gestión: — — ----------\nIdioma: — — ----------\nExperiencia laboral: — Deseable — Experiencia de 02 años en cargo similar"
      },
      {
        "heading": "misión del cargo",
        "text": "Brindar atención al Comandante de la Guarnición Ejército Arica durante las audiencias que se llevan a efecto en la CGEA y realizar el mantenimiento de las dependencias de la Ayudantía y Comandancia."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Jefe Sección Apoyo General\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Jefe de la Plana Mayor y Ayudante de la CGEA\nCargo(s) de personal subordinado: — -----------"
      },
      {
        "heading": "funciones y tareas principales",
        "text": "FUNCIONES — TAREAS\n1. — Brindar la atención en la Comandancia Guarnición Ejército Arica — • Atender al Comandante de la Guarnición Arica\n• Atender a las autoridades e invitados que concurren a la CGEA.\n2. — Realizar el mantenimiento de la Oficina y dependencias al interior de la Comandancia Ejército Arica — • Realizar aseo y limpieza de la oficina del Comandante de Guarnición, Jefe de Plana Mayor y Ayudante.\n• Realizar aseo y limpieza de la cocina de la CGEA.\n• Velar por el cargo de inventario existente en las dependencias.\n• Efectuar el aseo y limpieza de las áreas comunes."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1 — Compromiso institucional — — — 4\n2 — Adaptación y Flexibilidad — — — 4\n3 — Iniciativa y autonomía — — — 4\n4 — Planificación y organización — — — 4\n5 — Trabajo en equipo — — — 4"
      },
      {
        "heading": "observaciones",
        "text": "El cargo requiere un trabajo detallista, programado y coordinado con las actividades protocolares propias del CGEA."
      }
    ],
    "aliases": [
      "asistente mozo"
    ]
  },
  {
    "file": "03-6-Cond.-Mil.-Veh.-Mot.-Mod.-ZB-Arica.txt",
    "title": "CONDUCTOR MILITAR DE VEHÍCULO MOTORIZADO",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — — Cuadro Permanente / CPRASA\nGrado: — — SG1 / SG2 - CB1 - CB2\nEscalafón: — — Transporte / CPRASA\nEspecialidad Primaria: — — ----------\nEspecialidad Secundaria: — — ----------\nTítulo profesional o técnico: — Requerido — Conductor Militar de Vehículo Motorizado\nConducción especializada para transporte de autoridades\nConocimientos técnicos o de gestión: — — ----------\nIdioma: — — ----------\nExperiencia laboral: — Deseable — Experiencia de 05 años en cargo similar"
      },
      {
        "heading": "misión del cargo",
        "text": "Desempeñarse como conductor de vehículo militar de automóvil comando de la CGEA."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Jefe Sección Apoyo General\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Comandante Guarnición Ejército Arica, Jefe de la Plana Mayor y Ayudante de la CGEA\nCargo(s) de personal subordinado: — -----------"
      },
      {
        "heading": "funciones y tareas principales",
        "text": "FUNCIONES — TAREAS\n1. — Transporte del Comandante Guarnición Ejército Arica — • Planificar las rutas según las necesidades y programa del CGEA.\n• Materializar los recorridos programados del Comandante de la Guarnición Ejército Arica, en los tiempos establecidos.\n• Planificar y coordinar los sectores de estacionamiento.\n• Brindar la seguridad directa del Comandante de Guarnición durante el trayecto.\n• Efectuar las coordinaciones que correspondan con los organismos civiles y Carabineros de Chile.\n• Solicitar semanalmente programación de transporte del CGEA.\n2. — Velar por el correcto funcionamiento del vehículo Comando de la CGEA — • Mantener actualizada las carpetas y libreta del vehículo motorizado.\n• Programas y materializar las solicitudes de repuestos al Escalón Superior.\n• Efectuar cotizaciones de repuestos y/o reparaciones en el comercio establecido.\n• Materializar las LICOM al Escalón Superior.\n• Coordinar el mantenimiento programado del vehículo.\n• Efectuar las solicitudes de líquidos y combustible cuando corresponda.\n• Presentar el vehículo motorizado en revista cuando corresponda."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1 — Compromiso institucional — — — 4\n2 — Adaptación y Flexibilidad — — — 4\n3 — Iniciativa y autonomía — — — 4\n4 — Planificación y organización — — — 4\n5 — Trabajo en equipo — — — 4"
      },
      {
        "heading": "observaciones",
        "text": "El cargo requiere un trabajo detallista, programado y coordinado con las actividades protocolares propias del CGEA."
      }
    ],
    "aliases": [
      "conductor militar de vehículo motorizado",
      "conductor militar de vehículo",
      "conductor militar"
    ]
  },
  {
    "file": "03-8-Auxiliar-de-Seguridad.txt",
    "title": "AUXILIAR DE SEGURIDAD",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — Requerido — Personal Civil de procedencia militar\nGrado: — — PAC (A) / TCC (A)\nEscalafón: — — Personal civil\nEspecialidad Primaria: — — ---------\nEspecialidad Secundaria: — Deseable — Analista de Seguridad\nTítulo profesional o técnico: — Requerido — Suboficial Mayor o Clase de Ejército\nConocimientos técnicos o de gestión: — Deseable — Con especialización en Seguridad\nCon conocimientos de computación (nivel usuario)\nIdioma: — — ----------\nExperiencia laboral: — Deseable — Haberse desempeñado como Asesor de Seguridad en CGs de UACs."
      },
      {
        "heading": "misión del cargo",
        "text": "Proponer y Asesorar en el ámbito de seguridad de las instalaciones dependientes de la ZB al Comandante de la Zona de Bienestar, orientado al cumplimiento de las misiones y los objetivos trazados por el Comando de Bienestar."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Jefe de la Plana Mayor\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Comandante de Zona de Bienestar, Jefe de la Plana Mayor, Jefes de Secciones Habitacional, Asistencial, Recreacional y Apoyo General, Clase de Turno, Cdtes. de Guardias en Instalaciones PAF, con sus homólogos de los Deptos. del CG del COB, de ARs, Cdos. y CGs de UACs..\nCargo(s) de personal subordinado: — -------"
      },
      {
        "heading": "FUNCIONES Y TAREAS PRINCIPALES",
        "text": "FUNCIONES — TAREAS\n1. — Asesorar al Comandante de la Zona de Bienestar en materias de Seguridad.\n\n• Elaborar y proponer la totalidad de la documentación de Seguridad de la Zona de Bienestar\n• Elaborar los estudios y/o emitir su opinión fundada respecto de materias propias del ámbito de seguridad que le sean solicitadas a la Zona de Bienestar.\n2. — Evaluar y proponer actualización de los procedimientos de nivel de seguridad que ejecuta la Zona de Bienestar.\n\n• Controlar que se mantenga actualizada la planificación de seguridad de la Zona de Bienestar y su documentación de respaldo.\n• Proponer oportunamente las modificaciones a la planificación de seguridad y logística de la Zona de Bienestar necesarias para mantener y mejorar el desarrollo de la Zona de Bienestar en su gestión de bienestar."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1 — Asesoría — — — 4\n2 — Pensamiento analítico y sistémico — — — 3\n3 — Planificación y organización — — — 3\n4 — Calidad y metodicidad — — — 3\n5 — Trabajo en equipo — — — 3"
      },
      {
        "heading": "observaciones",
        "text": "El cargo requiere la actualización permanente de los planes y/o estudios de seguridad de las instalaciones dependientes de la ZB. Elaboración y actualización del Plan de Cuentas de informática de la Unidad. Elaboración de Carpetas de Seguridad de Personal."
      }
    ],
    "aliases": [
      "auxiliar de seguridad",
      "oficina de seguridad"
    ]
  },
  {
    "file": "04-5-Encargado-a-Hig.-Amb.-Prev.-Riesgos.txt",
    "title": "ENCARGADO (A) DE HIGIENE AMBIENTAL, PREVENSION DE RIESGOS",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — — Cuadro Permanente / Personal Civil\nGrado: — — CB1 / SG2 - CB1 - CB2 / TCC (T)\nEscalafón: — — Veterinaria / Personal Civil\nEspecialidad Primaria: — — ----------\nEspecialidad Secundaria: — — ----------\nTítulo profesional o técnico:\n(Para personal civil) — Requerido — Técnico en Prevención de Riesgos y Medio Ambiente\nConocimientos técnicos o de gestión: — Deseable — Curso Monitor en Prevención de Riesgos y Medio Ambiente\nIdioma: — — -----------\nExperiencia laboral: — Deseable — Mínimo 1 años en cargos anteriores."
      },
      {
        "heading": "misiones del cargo",
        "text": "Establecer medidas de Higiene Ambiental y Prevención de Riesgos en las instalaciones de la Zona de Bienestar."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Jefe Sección Apoyo General\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Comandante Zona de Bienestar, Jefe de la Plana Mayor, Instalaciones de la Zona de Bienestar, Veterinario del R.L.6 “Pisagua”\nCargo(s) de personal subordinado: — ------------"
      },
      {
        "heading": "funciones Y TAREAS principales",
        "text": "FUNCIONES — TAREAS\n1. — En el ámbito de Higiene Ambiental\n\n• Coordinará con los Jefes de Instalaciones las actividades calendarizadas de Higiene Ambiental que realiza el RLN° 6 “Pisagua”, en la Sala Cuna y Jardín Infantil, Cine Tacora y Club Militar de Campo, debiendo adoptar las medidas para proporcionar los insumos básicos requeridos por dicho personal veterinario.\n• Cooperará a los Jefes de Instalaciones en la presentación de proyectos y/o actividades vinculados al ámbito en sus respectivas instalaciones (reciclaje, eficiencia energética, etc).\n• Preverá que toda actividad vinculada al Medio Ambiente debe quedar registrada en la respectiva instalación, manteniendo una copia de lo realizado en el área bajo su responsabilidad.\n• Preverá controlar que cada instalación deberá llevar un registro por separado de los desechos que genera (orgánicos, papel, cartón, vidrio, latas, etc), antecedentes que serán solicitados ECSO por el Escalón Superior. En este sentido, será responsable de emitir los informes de medio ambiente que solicite el Escalón Superior.\n• Supervigilará quincenalmente con los respectivos encargados de las instalaciones (ZB, SC y JI, CT, CMCA y ex HM), el correcto registro de los consumos básicos (electricidad, agua potable y gas a granel), debiendo informar al mando de la Unidad, cuando se generen excesos en los consumos, con la finalidad de adoptar medidas para solucionar la situación y disminuir dichos consumos.\n• Deberá tener estrecha relación con los encargados de medio ambiente de las instalaciones, con quienes deberá coordinar proyectos y/o actividades concretas y posibles de realizar.\n2. — En el ámbito de Prevención de Riesgos — • Velará por la minimización de Condiciones y Acciones Inseguras que puedan presentarse en las Instalaciones antes mencionadas, incluyendo las dependencias de la ZB.\n• Controlará la operacionalidad de los extintores y/o sistemas de contra incendios existentes en las instalaciones de la ZB, coordinando con los responsables sus cargas o mantenciones.\n• Se coordinará con la Oficina de Personal, para adoptar los procedimientos en caso de accidentes laborales y enfermedades profesionales.\n• Propondrá una programación de capacitaciones y fiscalizaciones en prevención de riesgos al personal de la ZB por instalaciones."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1\nAsesoría — — — 4\n2\nAuto preparación continua — — — 4\n3\nIniciativa y autonomía — — — 3\n4 — Planificación y organización — — — 3\n5\nTrabajo en equipo — — — 2"
      },
      {
        "heading": "observaciones",
        "text": "El cargo requiere en sus funciones la coordinación permanente con el Asesor de Veterinaria del RLN° 6 “Pisagua”, para el desarrollo de las actividades de Higiene Ambiental."
      }
    ],
    "aliases": [
      "encargado de higiene ambiental",
      "higiene ambiental",
      "prevención de riesgos"
    ]
  },
  {
    "file": "04-6-Auxiliar-Financiero.txt",
    "title": "AUXILIAR FINANCIERO",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — — Cuadro Permanente / Personal Civil\nGrado: — — CB2 / SG2 - CB1 - CB2 / PAC (A) / TCC (A)\nEscalafón: — — Intendencia / Personal Civil\nEspecialidad Primaria: — — -------\nEspecialidad Secundaria: — — -------\nTítulo profesional o técnico:\nRequerido — Licencia de Enseñanza Media\nConocimientos técnicos o de gestión: — Deseable — Básicos en contabilidad. Manejo nivel usuario de Excel y Word.\nIdioma: — — -------\nExperiencia laboral: — Deseable — Experiencia mínima de dos años de experiencia progresiva de carácter operativo en el área de análisis de estados financieros."
      },
      {
        "heading": "misión del cargo",
        "text": "Efectuar la administración, control y tratamiento de la documentación financiera de solicitudes de compras de materiales y/o insumos que se realizan en los Centros de Costos, debiendo ser presentada mensualmente en Reunión Financiera, tramitar los descuentos al personal de usuarios de inmuebles fiscales que correspondan y cancelación de consumos básicos de viviendas fiscales no asignadas."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Jefe Oficina Finanzas ZB\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Comandante de Zona de Bienestar, Jefe de la Plana Mayor, Jefe y personal Oficina Finanzas ZB, Jefes de Centros de Costos, Usuarios de VFs., y proveedores.\nCargo(s) de personal subordinado: — -------"
      },
      {
        "heading": "funciones y tareas principales",
        "text": "FUNCIÓN — TAREAS\n1. — Administración, control y tratamiento de documentación financiera de los Centros de Costos — • Tramitación normal de solicitud de compra de materiales y/o insumos.\n• Tramitación de solicitud de compra de materiales por emergencia.\n• Tramitación de descuentos al personal usuarios de inmuebles fiscales.\n• Cancelación de consumos básicos de inmuebles fiscales mediante Comprobante de Egresos y/o efectivo.\n• Administración de los libros de actas de los respectivos Centros de Costos."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1 — Calidad y metodicidad en el trabajo — — — 3\n2 — Pensamiento analítico y sistémico — — — 3\n3 — Manejo de crisis y contingencias — — — 2\n4 — Orientación y servicio a las personas — — — 2\n5 — Trabajo en equipo — — — 2"
      },
      {
        "heading": "observaciones",
        "text": "El cargo requiere de un trabajo ordenado y metódico, debiendo dar estricto cumplimiento a los procesos contables estipulados en la Sección Habitacional."
      }
    ],
    "aliases": [
      "auxiliar financiero",
      "técnico administración de finanzas",
      "técnico en administración de finanzas"
    ]
  },
  {
    "file": "05-4-Encargado-a-de-Inventarios.txt",
    "title": "ENCARGADO (A) DE INVENTARIOS",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — — Cuadro Permanente / CPRASA\nGrado: — — SOF / SOF - SG1 / SG2 - CB1 - CB2\nEscalafón: — — Intendencia / Abastecimiento / CPRASA\nEspecialidad Primaria: — — ----------\nEspecialidad Secundaria: — — ----------\nTítulo profesional o técnico: — Deseable — Técnico Administrador\n\nConocimientos técnicos o de gestión: — Deseable — Curso control de bodega y manejo de inventários\nManejo de programa MASINV WEB\nIdioma: — — ----------\nExperiencia laboral: — Deseable — Experiencia de a lo menos 2 años en la administración de cargos de inventarios"
      },
      {
        "heading": "misión del cargo",
        "text": "Conocer y controlar la totalidad de los cargos de inventarios de la Zona de Bienestar, Instalación Parvularia, Cine Tacora e Instalaciones Recreacional"
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Jefe Sección Apoyo General\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Encargados de Oficinas e Instalaciones de la Zona de Bienestar, Comisión Matriz de Inventario del COB\nCargo(s) de personal subordinado: — -----------"
      },
      {
        "heading": "funciones principales",
        "text": "FUNCIONES — TAREAS\n1. — Altas de inventario\n\n• Trámite de facturas con elementos inventariables una vez llegadas a la oficina de finanzas de la Zona de Bienestar\n• Tramite de alta por la orden de la Zona de Bienestar\n• Ingreso del inventario al sistema de inventarios\n2. — Revistas a la instalaciones de la Zona de Bienestar e instalaciones recreacionales.\n\n• Revistar la totalidad de las instalaciones dependientes de esta Zona de Bienestar.\n• Confrontación de cargos por plancheta y físicos\n3. — Bajas de inventario\n\n• ingreso de los cargos que son propuestos para las bajas durante el año al sistema de inventario\n• reunión de los elementos propuesto para la baja\n• presentación de los elementos propuestos para la baja a la comisión matriz\n4. — Masinv web\n\n• Ingreso de todo el material dado de alta por la Orden Zona de Bienestar."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1\nCompromiso a nivel Jefatura — — — 4\n2\nTrabajo en equipo. — — — 3\n3\nAsesoría. — — — 3\n4 — Iniciativa y Autonomía — — — 3\n5\nPensamiento analítico y sistémico — — — 2"
      },
      {
        "heading": "observaciones",
        "text": "Permanente actualización en los sistemas informáticos para el control de los cargos."
      }
    ],
    "aliases": [
      "encargado de inventarios",
      "inventarios"
    ]
  },
  {
    "file": "05-5-Revisor-y-Analista-Contable.txt",
    "title": "REVISOR Y ANALISTA CONTABLE",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — — Cuadro Permanente / CPRASA / Personal Civil\nGrado: — — CB2 / SG2 - CB1 - CB2 / PAC (T) / TCC (T)\nEscalafón: — — Intendencia / CPRASA / Personal Civil\nEspecialidad Primaria: — — --------------\nEspecialidad Secundaria: — — --------------\nTítulo profesional o técnico:\n(Para personal civil) — Requerido — Técnico en Administración Financiera\nConocimientos técnicos o de gestión: — Requerido — Análisis contables y revisión de cuentas\nIdioma: — Deseable — ----------------\nExperiencia laboral: — Deseable — Experiencia en materias propias de la Administración Financiera"
      },
      {
        "heading": "misión del cargo",
        "text": "Efectuar la revisión y análisis de los documentos contables de la Unidad, llevando un estricto control del Libro de Plazos de la documentación contable y debiendo contar con la totalidad de la documentación contable mensual a pago de cada centro de costo, de manera de dar cumplimiento a la planificación financiera y al pago dentro de los 30 días a proveedores."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Jefe Oficina Finanzas de la ZB\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Jefe Oficina Finanzas ZB, Técnicos Administradores Financieros, Jefes de Centros de Costos\nCargo(s) de personal subordinado: — ----------------------"
      },
      {
        "heading": "funciones Y TAREAS principales",
        "text": "FUNCIONES — TAREAS\n1. — Revisión de documentación contables\n• Recepcionar la documentación contable de los Centros de Costos.\n• Revisión de la documentación contable.\n• Digitación y contabilización de la documentación contable.\n• Archivo de documentación contable."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1 — Compromiso Institucional — — — 4\n2 — Trabajo en equipo — — — 4\n3 — Asesoría — — — 3\n4 — Iniciativa y Autonomía — — — 2\n5 — Pensamiento Analítico y sistémico — — — 2"
      },
      {
        "heading": "observaciones",
        "text": "El cargo no requiere observaciones."
      }
    ],
    "aliases": [
      "revisor y analista contable",
      "revisor contable",
      "analista contable"
    ]
  },
  {
    "file": "06-3-Jefe-de-Oficina-de-Finanzas.txt",
    "title": "JEFE DE OFICINA DE FINANZAS",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — — Oficial / Personal Civil\nGrado: — — CAP / CAP – TTE / ECP (P)\nEscalafón: — — Intendencia, Personal Civil\nEspecialidad Primaria: — — -------------\nEspecialidad Secundaria: — — -------------\nTítulo profesional o técnico:\n(Para personal civil) — Requerido — Ingeniero Comercial o Ingeniero en Ejecución en Finanzas\nConocimientos técnicos o de gestión: — Deseable — Control de Gestión, Procedimientos Administrativos\nIdioma: — Deseable — Ingles nivel intermedio\nExperiencia laboral: — Deseable — Experiencia en materias propias de la Administración Pública"
      },
      {
        "heading": "misión del cargo",
        "text": "Asesorar al mando de la Zona de Bienestar y Orientar al Contador General en el ámbito financiero contable, conforme a las leyes y reglamentación vigente enmarcado en el marco presupuestario."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Jefe de la Plana Mayor\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Comandante de Zona de Bienestar, Secciones Habitacional, Asistencial, Recreacional y Apoyo General, Jefe de Centros de Costos, Departamentos de Finanzas del COB y CG VI DE.\nCargo(s) de personal subordinado: — Contador General, Revisor y Analista Contable y Técnicos Administradores Financieros."
      },
      {
        "heading": "funciones Y TAREAS principales",
        "text": "FUNCIONES — TAREAS\n1. — Asesoría al mando.\n\n• En base a la información que entrega el SIFIE, deberá asesorar al mando para la toma de decisiones en materias económicas y saldos de los Centros de Costos que administra la Zona de Bienestar.\n2. — Planificación de inversión.\n\n• Deberá asesorar si la imputación del gasto corresponde a la normativa legal y a las disposiciones que emana la DIFE y COTRAE\n3. — Elaboración de presupuesto por programa.\n\n• Presentará al Contador, la planificación presupuestaria de la Zona de Bienestar, todo enmarcado a las disposiciones que entrega el escalón superior para este proceso.\n4. — Control de saldo estacionario de fondos presupuestarios.\n\n• Deberá controlar de forma acuciosa los saldos presupuestarios no empleados en el mes, los que forman saldos estacionarios."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1 — Compromiso Institucional — — — 4\n2 — Trabajo en equipo — — — 4\n3 — Asesoría — — — 3\n4 — Iniciativa y Autonomía — — — 2\n5 — Pensamiento Analítico y sistémico — — — 2"
      },
      {
        "heading": "observaciones",
        "text": "El cargo no requiere observaciones."
      }
    ],
    "aliases": [
      "jefe de oficina de finanzas",
      "jefe oficina de finanzas"
    ]
  },
  {
    "file": "06-3-Operador-a-Chile-Compra.txt",
    "title": "OPERADOR (A) MERCADO PÚBLICO",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — — Cuadro Permanente / Personal Civil\nGrado: — — CB2 / PAC (T) / TCC (T).\nEscalafón: — — Intendencia / Personal Civil\nEspecialidad Primaria: — — -----------\nEspecialidad Secundaria: — — -----------\nTítulo profesional o técnico:\n(Para personal civil) — Deseable — Técnico en Administración o Finanzas, titulado en Colegio Técnico o Instituto.\nConocimientos técnicos o de gestión: — Requerido — Enseñanza Madia.\nManejo Microsoft Office.\nAcreditación como Operador de Chilecompras.\nIdioma: — Deseable — Inglés básico\nExperiencia laboral: — Deseable — De preferencia que haya trabajado como operador en otra instalación del Ejército."
      },
      {
        "heading": "misión del cargo",
        "text": "Ejecutar el proceso de compras y generación de órdenes de compra conforme a los procedimientos y normativa vigente."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Jefe Sección Apoyo General\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Comandante de Zona de Bienestar, Jefe de la Plana Mayor, Asesor Jurídico, Jefe Sección Apoyo General, Jefes de Centros de Costos, Proveedores y clientes internos (Los que requieren algún proceso del CGA.)\nCargo(s) de personal subordinado: — -------------"
      },
      {
        "heading": "funciones y tareas principales",
        "text": "FUNCIONES — TAREAS\n1. — Adquisición por Catálogo Electrónico.\n\n• Ingresar al portal mercado público\n• Ingresa catálogo electrónico\n• Buscador de productos y servicios\n• Visualizar el Carro de Compras que haya creado\n• Generar orden de compra\n• Enviar orden de compra para autorización y publicación por parte del supervisor\n2. — Crear la licitación en el Portal.\n\n• Se ingresa al módulo de licitaciones\n• Se ingresa a crear licitaciones\n• Búsqueda de productos o servicios\n• Se crea el formulario de licitación. Ingresando nombre, objeto y tipo de Licitación se crearán los datos generales de la licitación. Una vez completados, al guardar se generará el Número de ID de la adquisición\n• Completar datos\n3. — Completación de datos.\n\n• Nombre y datos básicos\n• Tipos de empresas participantes.\n• Datos del organismo demandante\n• Etapas y plazos de la licitación.\n• Requisitos para los oferentes.\n• Requerimientos legales.\n• Criterios de evaluación.\n• Montos, duración y delegación del contrato.\n• Garantías requeridas.\n• Listado de bienes y servicios requeridos.\n• Requerimientos técnicos y otras cláusulas.\n• Documentos anexos.\n• Documento que autoriza la adquisición.\n• Enviar licitación para autorización y publicación por parte del supervisor\n4. — Adjudicación de licitación.\n\n• Apertura de licitación una etapa o como se haya estipulado en las bases\n• Una vez que la licitación se encuentre en estado cerrada se procede a la apertura Acceder a las ofertas y entregarlas a la comisión evaluadora.\n• Ingresar acta de evaluación\n• Ingresar resolución de adjudicación\n• Ingresar tabla de evaluación\n• Enviar licitación para autorización y adjudicación por parte del supervisor\n• Editar orden de compra generada al adjudicar la licitación\n• Enviar orden de compra editada al supervisor para su autorización y publicación.\n• Ingresar contrato si corresponde"
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1 — Calidad y metodicidad del trabajo — — — 3\n2 — Autopreparación continua — — — 3\n3 — Planificación y organización — — — 2\n4 — Trabajo en equipo — — — 2\n5 — Disciplina — — — 2"
      },
      {
        "heading": "observaciones",
        "text": "El cargo requiere sólidos conocimientos de la Ley y Reglamento de Compras Públicas y mantener acreditación vigente en el Mercado Publico."
      }
    ],
    "aliases": [
      "operador mercado público",
      "operador de mercado público",
      "operador chile compra",
      "chile compra"
    ]
  },
  {
    "file": "07-1-Jefe-Administrativo.txt",
    "title": "JEFE ADMINISTRATIVO",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — — Oficial Jefe\nGrado: — — Mayor / Teniente Coronel – Mayor\nEscalafón: — — De Armas / De Servicio.\nEspecialidad Primaria: — — -------\nEspecialidad Secundaria: — — -------\nTítulo profesional o técnico:\nRequerido — Oficial de Ejército\nConocimientos técnicos o de gestión: — Deseable — Conocimiento del Reglamento de Comisiones Administrativas.\nConocimiento de la Ley 19.886 y su reglamento \"Ley de Compras Públicas\".\nConocimiento DFL (G) N° 1 \"Estatuto del Personal de las FAs.\", Edic. 1997.\nReglamento de Disciplina para las FAs.\"\nCódigo del Trabajo.\nIdioma: — — -------\nExperiencia laboral: — Deseable — Cinco años desempeñándose en áreas administrativas."
      },
      {
        "heading": "misión del cargo",
        "text": "Asumir el mando de la Plana Mayor de la Unidad, coordinando las prestaciones de bienestar que contribuyan al mejoramiento de la calidad de vida del personal de planta de toda la Zona Jurisdiccional de la Zona de Bienestar, su grupo familiar y asociados, accediendo a los productos y servicios que proporciona la Zona de Bienestar y por ende al COB."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Comandante de Zona de Bienestar\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Grupo Personal de Comandante de Zona de Bienestar, Oficinas de Personal, Finanzas, Planificación, Seguridad, Secciones Habitacional, Asistencial, Recreacional y Apoyo General.\nCargo(s) de personal subordinado: — Oficinas de Personal, Finanzas, Planificación, Seguridad, Secciones Habitacional, Asistencial, Recreacional y Apoyo General."
      },
      {
        "heading": "funciones y tareas principales",
        "text": "FUNCIONES — TAREAS\n1. — Responsable del control administrativo y disciplinario del personal.\n\n• — • Supervisa y distribuye las actividades del personal a su cargo.\n• Elaborará las hojas de vida y calificará al personal subordinado.\n• Emitirá los respectivos informes de desempeños del personal civil.\n• Lleva el control de contratos contraídos por la Zona de Bienestar y las diferentes empresas que mantienen convenios con la institución.\n2. — Elaborará y analizará cuadros relacionados con el movimiento y gastos administrativos.\n\n• Autorizará las órdenes de compra de mantenimiento de los equipos de las oficinas y el mantenimiento general de las instalaciones de la oficina.\n• Responsable por las implementaciones de sistemas contables, financieros y administrativos. Redacta documentos y memorándum en general.\n• Revisa, verifica y aprueba los movimientos y registros contables, estados de cuentas, conciliaciones bancarias, cierres de cuentas y balances de comprobación y licitaciones del mercado público.\n3. — Vela por el cumplimiento de la normativa legal vigente.\n\n• Lleva el control y administra los fondos de trabajo y/o caja chica.\n• Participa en el control financiero de proyectos\n• Elabora informes periódicos de las actividades realizadas\n• Establece conjuntamente con el Cdte. de la Zona de Bienestar, las políticas a seguir en todas las áreas de responsabilidad de la ZB\n4. — Vela por el cumplimiento de las políticas y normas.\n\n• Planifica y dirige las actividades del personal a su cargo establecidas en la ZB, en materia de RHs., Administrativas, Seguridad, computacional y financiera.\n• Investiga accidentes ocurridos en situaciones del servicio, determina sus causas y recomienda medidas correctivas.\n• Controla y supervisa las funciones de personal, finanzas contables y de mercado público, como también dará sus V° B° a la documentación que se genere de éstas, asimismo de las distintas oficinas de la ZB.\n• Asesorar y controlar al personal encargado de la residencia universitaria, en la elaboración de normas y procedimientos de trabajo, adaptados a las operaciones laborales que se llevan a cabo.\n• Revisará la documentación, informando si ella se ajusta a las disposiciones reglamentarias, quedando estos antecedentes ingresados en la respectiva agenda computacional, debiendo informar en las correspondientes reuniones de coordinación los resúmenes de plazos."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1 — Liderazgo — — — 4\n2 — Asesoría — — — 4\n3 — Orientación a resultados — — — 3\n4 — Planificación y Organización — — — 3\n5 — Calidad y metodicidad del trabajo — — — 3"
      },
      {
        "heading": "observaciones",
        "text": "El cargo requiere asumir el mando de la Unidad en ausencia del Comandante de Zona de Bienestar."
      }
    ],
    "aliases": [
      "jefe administrativo"
    ]
  },
  {
    "file": "07-1-Jefe-Apoyo-General.txt",
    "title": "JEFE SECCIÓN APOYO GENERAL",
    "sections": [
      {
        "heading": "requisitos",
        "text": "Categoría: — — Cuadro Permanente / CPRASA\nGrado: — — SG2 / SG2 - CB1 - CB2\nEscalafón: — — Intendencia / CPRASA\nEspecialidad Primaria: — — --------------\nEspecialidad Secundaria: — — --------------\nTítulo profesional o técnico: — Requerido — Técnico en Administración\nConocimientos técnicos o de gestión: — Deseable — Curso control de bodega y manejo de inventários\nManejo de programa MASINV WEB\nAcreditación de Mercado Público.\nIdioma: — — ----------------\nExperiencia laboral: — Deseable — 01 año en cargos similares"
      },
      {
        "heading": "misión del cargo",
        "text": "Ejercer el mando de la Sección Apoyo General de la Zona de Bienestar, administrando la gestión profesional de las áreas de Administración de Contratos, Centro de Gestión de Compras, Inventarios, Higiene Ambiental y Prevención de Riesgos y Auxiliar de Aseos de la ZB."
      },
      {
        "heading": "relaciones de dependencia y supervisión",
        "text": "Cargo del superior directo: — Comandante de Zona de Bienestar\nCargo(s), organismo(s) y/o área(s) con quienes se coordina para el desempeño de sus tareas: — Jefe de la Plana Mayor, Plana Mayor ZB, Asesor Jurídico, Oficina de Finanzas, Secciones Habitacional y Recreacional, Depto. Logístico del COB.\nCargo(s) de personal subordinado: — Administración de Contratos, Centro de Gestión de Compras, Inventarios, Higiene Ambiental y Prevención de Riesgos y Auxiliar de Aseos de la ZB."
      },
      {
        "heading": "funciones Y TAREAS principales",
        "text": "FUNCIONES — TAREAS\n1. — Dar cumplimiento a las misiones estipuladas en la Orden de Funcionamiento de la Unidad, desarrollando una gestión de mando coordinada y materializando el asesoramiento al Cdte. ZB. — • Distribuir, normalizar y supervisar los trabajos de las áreas de su sección.\n• Coordinar y colaborar en el trabajo administrativo de las áreas de su sección.\n• Desarrollar los procesos de gestión y soporte que contribuyen a los fines propios del Bienestar.\n2. — Desarrollar las responsabilidades estratégicas del puesto que desempeña — • Asegurar la correcta atención a los clientes internos y/o externos, materializar la búsqueda de información sobre sus problemas e inquietudes, crear las alternativas para solucionarlo y efectuar el asesoramiento.\n• Diseñar y mantener una estrategia de comunicación que permita a las áreas involucradas, identificar claramente sus objetivos.\n• Motivar permanentemente a los integrantes de su sección, para el cumplimiento de los objetivos que cada área cumple.\n3. — Desarrollar las responsabilidades específicas del puesto que desempeña — • Administrar proyectos y actividades de su área, realizando controles y coordinaciones que correspondan.\n• Realizar análisis lógicos, identificando problemas, reconociendo información significativa, buscando y coordinando datos relevantes.\n• Anticipar acontecimientos que puedan ocurrir en el corto y mediano plazo, creando oportunidades y minimizando los problemas potenciales, evaluando las consecuencias de las decisiones, respondiendo con agilidad a los cambios y aplicando diferentes formas de trabajo."
      },
      {
        "heading": "competencias conductuales",
        "text": "nivel esperable\norden de importancia — competencias específicas — ingreso — egreso — desempeño\n1 — Asesoría — — — 4\n2 — Compromiso Institucional — — — 4\n3 — Calidad y metocidad del trabajo — — — 3\n4 — Orientación a las personas y al servicio — — — 3\n5 — Iniciativa y Autonomía — — — 3"
      },
      {
        "heading": "observaciones",
        "text": "En cargo requiere excelentes relaciones inter personales y trato humano con elevada sicología emocional y administración de personal especial con el Asistente Mozo y Conductor de Vehículo Militar Motorizado, dependientes del Comandante de la Guarnición Ejército Arica."
      }
    ],
    "aliases": [
      "jefe sección apoyo general",
      "jefe de apoyo general",
      "jefe apoyo general"
    ]
  }
];
