// Catálogo de la Zona: tareas fundamentales, procesos (código, nombre, responsable por defecto, etapas)
export const TF = {
  TF1:{short:"Gestión",name:"Planificar, dirigir y controlar la gestión de la Zona",owner:"Jefe Administrativo",
    procs:[["ADM-CGR","Control de gestión y riesgos","m-barbara-llancavil-cortez",["Evaluación de riesgos","Seguimiento de observaciones","Cierre e informe"]],
      ["PLAN","Operaciones y control de tareas (por levantar)","m-urquieta",[]],["DOC","Gestión documental (por levantar)","m-cortes",[]]]},
  TF2:{short:"Habitacional",name:"Administrar el sistema habitacional",owner:"Sección Habitacional",
    procs:[["HAT-01","Postulación y registro de solicitudes","m-ramirez",["Difusión y recepción","Revisión y registro"]],
      ["HAT-02","Evaluación, priorización y asignación","m-ramirez",["Evaluación y priorización","Resolución y notificación"]],
      ["HAT-03","Entrega y recepción de viviendas","m-ramirez",["Inspección","Formalización"]],
      ["HAT-04","Control de ocupación e inspecciones","m-ramirez",["Inspección","Reporte"]],
      ["HAT-05","Prórrogas y restitución","m-ramirez",["Evaluación","Resolución y restitución"]],
      ["HAT-06","Daños, fallas y mantenimiento de viviendas","m-ramirez",["Registro y diagnóstico","Ejecución y cierre"]]]},
  TF3:{short:"Habitabilidad",name:"Administrar la habitabilidad del personal soltero",owner:"Sección Habitabilidad",
    procs:[["HAB-01","Difusión de disponibilidad y condiciones","m-martinez",["Preparación","Difusión"]],
      ["HAB-02","Recepción y evaluación de solicitudes","m-martinez",["Recepción","Evaluación"]],
      ["HAB-03","Asignación de dependencias","m-martinez",["Preparación","Formalización"]],
      ["HAB-04","Prestación de alojamiento","m-martinez",["Prestación diaria","Atención de novedades"]],
      ["HAB-05","Administración de servicios e ingresos","m-martinez",["Cobro y recaudación","Conciliación e informe"]],
      ["HAB-06","Restitución e inspección","m-martinez",["Verificación","Cierre"]]]},
  TF4:{short:"Recreacional",name:"Administrar las prestaciones recreacionales",owner:"Jefe Sección Recreacional",
    procs:[["REC-01","Difusión de prestaciones","m-francia-mundaca-toledo",["Preparación de la oferta","Publicación"]],
      ["REC-02","Solicitudes, reservas y eventos","m-francia-mundaca-toledo",["Solicitud y verificación","Cotización y confirmación"]],
      ["REC-03","Autorización de acceso","m-francia-mundaca-toledo",["Control de ingreso","Control de salida"]],
      ["REC-04","Administración Club de Oficiales “El Morro”","m-acuna",["Programación","Operación y control diario","Resultados"]],
      ["REC-05","Administración Centro Recreacional “Arica”","m-ariel-martinez-quezada",["Preparación","Operación","Resultados"]],
      ["REC-06","Ingresos, bienes y satisfacción","m-francia-mundaca-toledo",["Conciliación","Satisfacción y mejora"]]]},
  TF5:{short:"Asistencial",name:"Administrar las prestaciones asistenciales",owner:"Directora Sala Cuna y JI",
    procs:[["JI-01","Difusión de cupos y condiciones de ingreso","m-hermosilla",["Definición de la admisión","Difusión"]],
      ["JI-02","Recepción, registro y evaluación de solicitudes","m-hermosilla",["Recepción","Evaluación y resultado"]],
      ["JI-03","Matrícula e inducción","m-hermosilla",["Matrícula","Inducción"]],
      ["JI-04","Planificación y ejecución pedagógica","m-hermosilla",["Planificación","Ejecución y evaluación"]],
      ["JI-05","Atención integral: alimentación, higiene y seguridad","m-hermosilla",["Recepción","Atención","Entrega"]],
      ["JI-06","Seguimiento y comunicación con apoderados","m-hermosilla",["Análisis","Comunicación y acuerdos"]],
      ["JI-07","Registros obligatorios, evaluación y mejora","m-hermosilla",["Control documental","Evaluación y mejora"]],
      ["CONV","Gestión de convenios (por levantar)","m-vergara",[]]]},
  TF6:{short:"Sostenimiento",name:"Sostener administrativa y logísticamente las prestaciones",owner:"Jefe Administrativo",
    procs:[["ADM-FIN","Gestión financiera","m-rodriguez",["Programación y liquidez","Compromiso del gasto","Pago y conciliación"]],
      ["ADM-ADQ","Gestión de adquisiciones","m-veliz",["Preparación del requerimiento","Tramitación y adjudicación","Recepción y cierre"]],
      ["ADM-CON","Administración contractual","m-rodrigo-oyarce-jara",["Registro e inicio","Control de ejecución","Cierre"]],
      ["ADM-PER","Administración de personal","m-perez",["Solicitud y verificación","Resolución y registro"]],
      ["ADM-LOG","Logística y mantenimiento","m-carlos-chavez-jimenez",["Registro y diagnóstico","Ejecución","Recepción y control de bienes"]]]}
};
export const TFK = Object.keys(TF);

export const CU_LISTS = {"ADM-CGR":"901329225514","PLAN":"901329225515","DOC":"901329225517",
  "HAT-01":"901329225519","HAT-02":"901329225520","HAT-03":"901329225521","HAT-04":"901329225522","HAT-05":"901329225523","HAT-06":"901329225524",
  "HAB-01":"901329225525","HAB-02":"901329225526","HAB-03":"901329225527","HAB-04":"901329225528","HAB-05":"901329225529","HAB-06":"901329225530",
  "REC-01":"901329225531","REC-02":"901329225532","REC-03":"901329225533","REC-04":"901329225534","REC-05":"901329225538","REC-06":"901329225539",
  "JI-01":"901329225540","JI-02":"901329225541","JI-03":"901329225542","JI-04":"901329225543","JI-05":"901329225544","JI-06":"901329225545","JI-07":"901329225546","CONV":"901329225547",
  "ADM-FIN":"901329225548","ADM-ADQ":"901329225549","ADM-CON":"901329225550","ADM-PER":"901329225551","ADM-LOG":"901329225552"};

export function procInfo(code, owners) {
  for (const k of TFK) for (const p of TF[k].procs) if (p[0] === code)
    return { tf: k, code: p[0], name: p[1], owner: (owners && owners[code]) || p[2], defOwner: p[2], stages: p[3] };
  return null;
}
export function stagesFor(code) { const p = procInfo(code); return p ? p.stages.map(n => ({ n, done: false })) : []; }
export const MOTIVOS = ["Falta de insumos", "Depende de otra persona", "Carga de trabajo", "Fuerza mayor", "Otro"];
export const EVTYPES = ["Incidente", "Visita", "Reunión", "Novedad", "Otro"];
export const CATS = [["avisos", "Avisos"], ["turnos", "Turnos"], ["documentos", "Documentos"], ["social", "Social"]];
export const TF_COLORS = { TF1: "#1F3A5F", TF2: "#A14A0E", TF3: "#6B4C9A", TF4: "#0E6B84", TF5: "#A12D63", TF6: "#4D6B1F" };

// Áreas de trabajo (como en la reunión de coordinación). Agrupan el día a día;
// las TF y procesos quedan para las tareas fundamentales.
// [código, nombre, grupo, responsable por defecto, proceso por defecto]
export const AREA_GROUPS = [["GES", "Gestión"], ["HAT", "Habitacional"], ["HAB", "Habitabilidad"], ["REC", "Recreacional"], ["ASI", "Asistencial"], ["SOS", "Sostenimiento"]];
export const AREAS = [
  ["CDO", "Comando y Plana Mayor", "GES", "m-passalacqua", "PLAN"],
  ["AJ", "Asesoría Jurídica", "GES", "m-illesca", "ADM-CGR"],
  ["PER", "Personal", "GES", "m-perez", "ADM-PER"],
  ["FIN", "Finanzas", "GES", "m-rodriguez", "ADM-FIN"],
  ["SEG", "Seguridad y Computación", "GES", "m-hector-lopez-calderon", "ADM-LOG"],
  ["PLAN", "Oficina de Operaciones", "GES", "m-urquieta", "PLAN"],
  ["OCGR", "Oficina Control de Gestión y Riesgo", "GES", "m-barbara-llancavil-cortez", "ADM-CGR"],
  ["CGA", "Adquisiciones (CGA)", "GES", "m-veliz", "ADM-ADQ"],
  ["CTO", "Administración de contratos", "GES", "m-rodrigo-oyarce-jara", "ADM-CON"],
  ["VF", "Sección Habitacional (VF)", "HAT", "m-ramirez", "HAT-06"],
  ["HAB", "Sección Habitabilidad", "HAB", "m-martinez", "HAB-05"],
  ["REC", "Sección Recreacional", "REC", "m-francia-mundaca-toledo", "REC-06"],
  ["CRA", "Centro Recreacional Arica", "REC", "m-ariel-martinez-quezada", "REC-05"],
  ["COEM", "Club de Oficiales El Morro", "REC", "m-acuna", "REC-04"],
  ["JI", "Jardín Infantil", "ASI", "m-hermosilla", "JI-05"],
  ["ASI", "Sección Asistencial y Convenios", "ASI", "m-vergara", "CONV"],
  ["LOG", "Equipo Logístico", "SOS", "m-carlos-chavez-jimenez", "ADM-LOG"],
  ["MANT", "Mantenimiento de Infraestructura", "SOS", "m-cid", "ADM-LOG"],
  ["ITO", "ITO", "SOS", "m-fabian-torres-rivera", "ADM-CON"],
];
export const AREA_COLORS = { GES: "#1F3A5F", HAT: "#A14A0E", HAB: "#6B4C9A", REC: "#0E6B84", ASI: "#A12D63", SOS: "#4D6B1F" };
export function areaInfo(code) { const a = AREAS.find((x) => x[0] === code); return a ? { code: a[0], name: a[1], group: a[2], owner: a[3], proc: a[4], color: AREA_COLORS[a[2]] } : null; }
// Unidad del encuadramiento → área por defecto
export const UNIT_AREA = {
  "Comando ZB Arica": "CDO", "Jefatura Administrativa": "CDO", "Registratura": "CDO", "Oficina de Planificación": "PLAN", "Oficina de Operaciones": "PLAN",
  "Oficina Control de Gestión y Riesgo": "OCGR", "Asesoría Jurídica": "AJ", "Oficina de Personal": "PER", "Oficina de Finanzas": "FIN",
  "Oficina de Seguridad": "SEG", "SICE": "SEG", "Centro de Gestión de Adquisiciones": "CGA", "Inspección Técnica de Obras (ITO)": "ITO",
  "Oficina de Coordinación Logística": "LOG", "Sección Mantenimiento de Infraestructura (Sección de Apoyo)": "MANT",
  "Sección Habitacional": "VF", "Sección Habitabilidad": "HAB", "Sección Recreacional": "REC", "Centro Recreacional Arica": "CRA",
  "Club de Oficiales El Morro": "COEM", "Jardín Infantil Soldadito de Plomo": "JI", "Sección Asistencial": "ASI", "Área Convenios": "ASI",
};
export function areaColor(t) { const a = areaInfo(t && t.area); return a ? a.color : null; }
