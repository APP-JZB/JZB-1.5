// Pasos del procedimiento (desde los diagramas), botón "Ver diagrama" y sugerencia de derivar pasos.
import React, { useState } from "react";
import { View, Text, Pressable, Alert, Platform } from "react-native";
import { supabase, errMsg } from "./lib";
import { msgDerivacion } from "./correo";
import { FLUJOS } from "./flujos";
import { DIAGRAMAS } from "./diagramas";
import { C, S, Btn, Card, Row, Between } from "./ui";

export const flujo = (code) => FLUJOS[code] || null;
export const tieneDiagrama = (code) => !!DIAGRAMAS[code];

export async function verDiagrama(code) {
  let ventana = null;
  try {
    if (!DIAGRAMAS[code]) return Alert.alert("Diagrama no disponible", "No se encontró el archivo del diagrama " + code + ".");
    if (Platform.OS === "web") {
      // Abrir la pestaña inmediatamente desde el toque para evitar el bloqueo de ventanas emergentes.
      ventana = typeof window !== "undefined" ? window.open("about:blank", "_blank") : null;
      if (!ventana) return Alert.alert("No se pudo abrir", "Permite las ventanas emergentes para ver el diagrama.");
      const { Asset } = require("expo-asset");
      const a = Asset.fromModule(DIAGRAMAS[code]);
      await a.downloadAsync();
      const uri = a.uri || a.localUri;
      if (!uri) throw new Error("No se pudo cargar el archivo PDF.");
      ventana.location.href = uri;
      return;
    }
    const { Asset } = require("expo-asset");
    const { File, Paths } = require("expo-file-system");
    const a = Asset.fromModule(DIAGRAMAS[code]); await a.downloadAsync();
    const src = new File(a.localUri || a.uri);
    const dst = new File(Paths.cache, code + "_Diagrama.pdf");
    if (dst.exists) dst.delete();
    src.copy(dst);
    await dst.preview({ title: "Diagrama " + code, mimeType: "application/pdf" });
  } catch (e) {
    if (ventana) ventana.close();
    Alert.alert("No se pudo abrir el diagrama", String((e && e.message) || e));
  }
}

function personaId(members, per) {
  if (!per) return null;
  const m = members.find((x) => x.name === per) || members.find((x) => per.includes(x.name));
  return m ? m.id : null;
}

export function Procedimiento({ t, d, canEdit, canDerive, open }) {
  const f = flujo(t.proc);
  const [busy, setBusy] = useState(false);
  if (!f || !f.pasos.length) return null;
  const done = new Set((t.pasos || []).map(Number));
  const total = f.pasos.length;
  async function toggle(n) {
    if (!canEdit || busy) return;
    const s = new Set(done); s.has(n) ? s.delete(n) : s.add(n);
    const arr = [...s].sort((a, b) => a - b);
    setBusy(true);
    const { error } = await supabase.from("tasks").update({ pasos: arr, progress: Math.round((100 * arr.length) / total) }).eq("id", t.id);
    setBusy(false);
    if (error) Alert.alert("No se pudo guardar", errMsg(error));
  }
  async function derivar(id, paso) {
    const nm = (d.members.find((m) => m.id === id) || {}).name || "";
    const log = (t.log || []).concat([{ t: "derivada a " + nm + " (paso " + paso.n + ": " + paso.a + ") por " + d.me.name, at: Date.now() }]);
    const { error } = await supabase.from("tasks").update({ delegado: id, delegado_por: d.me.id, log }).eq("id", t.id);
    if (error) return Alert.alert("No se pudo derivar", errMsg(error));
    if (open) open({ kind: "notificar", msg: msgDerivacion(d, t, id, paso) }); else Alert.alert("Derivada a " + nm, "Se avisó al Comandante.");
  }
  let lastEt = null;
  const nextN = (f.pasos.find((p) => !done.has(p.n)) || {}).n;
  return (
    <Card>
      <Between>
        <Text style={S.label}>Procedimiento {t.proc} · {done.size}/{total} pasos</Text>
        {tieneDiagrama(t.proc) ? <Pressable onPress={() => verDiagrama(t.proc)}><Text style={{ color: C.accent, fontWeight: "800", padding: 4 }}>Ver diagrama</Text></Pressable> : null}
      </Between>
      {f.pasos.map((p) => {
        const head = p.et && p.et !== lastEt ? (lastEt = p.et) : null;
        const ok = done.has(p.n);
        const sug = personaId(d.members, p.per);
        const showSug = canDerive && !ok && p.n === nextN && sug && sug !== t.member_id && sug !== t.delegado;
        return (
          <View key={p.n}>
            {head ? <Text style={{ fontSize: 11, fontWeight: "800", color: C.muted, marginTop: 6, letterSpacing: 0.5 }}>{head.toUpperCase()}</Text> : null}
            <Pressable onPress={() => toggle(p.n)} style={{ flexDirection: "row", gap: 10, paddingVertical: 7, borderTopWidth: 1, borderColor: C.line, opacity: canEdit ? 1 : 0.85 }}>
              <View style={{ width: 24, height: 24, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: ok ? C.accent : C.surface2 }}>
                <Text style={{ color: ok ? "#fff" : C.ink2, fontSize: 12, fontWeight: "800" }}>{ok ? "✓" : p.n}</Text>
              </View>
              <View style={{ flex: 1, gap: 2 }}>
                <Row style={{ flexWrap: "wrap", gap: 6 }}>
                  <Text style={{ color: C.ink, fontSize: 14, textDecorationLine: ok ? "line-through" : "none", flexShrink: 1 }}>{p.a}</Text>
                  {p.pc ? <View style={{ backgroundColor: C.redSoft, borderRadius: 4, paddingHorizontal: 5 }}><Text style={{ color: C.redInk, fontSize: 10, fontWeight: "800" }}>PUNTO DE CONTROL</Text></View> : null}
                </Row>
                <Text style={S.small}>{p.rol}{p.per && !/^Según|^Por designar|^Designada|^Dependiente|^Jefe|^Personal/.test(p.per) ? " · " + p.per : ""}</Text>
                {p.doc ? <Text style={{ fontSize: 12, color: C.blueInk }}>📄 {p.doc}</Text> : null}
              </View>
            </Pressable>
            {showSug ? <Btn small title={"Derivar este paso a " + (d.members.find((m) => m.id === sug) || {}).name} onPress={() => derivar(sug, p)} /> : null}
          </View>);
      })}
      {f.dec && f.dec.length ? <Text style={S.small}>Decisiones del flujo: {f.dec.join(" · ")}</Text> : null}
    </Card>
  );
}
