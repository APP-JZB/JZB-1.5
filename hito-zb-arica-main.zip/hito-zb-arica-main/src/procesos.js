// Pestaña "Procesos": base de agrupación de tareas y propuesta de proceso tras un mes de observación.
// La ven el Comandante, Bárbara Llancavil, Viviana Urrutia, SOF Urquieta y SOF Ramírez (control en la base de datos).
// Todos ellos pueden sugerir grupos o procesos; solo el Comandante crea, adopta, descarta o aprueba.
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { View, Text, Alert } from "react-native";
import { supabase, fmtDay, norm, errMsg, DAY } from "./lib";
import { claves } from "./screens";
import { C, S, Btn, Chip, Card, Field, Note, Sheet, Row, Between, Empty, Badge } from "./ui";

const MIN_DIAS = 30, MIN_TAREAS = 3;
const dias = (x) => (x == null ? "—" : x < 1 ? "menos de 1 día" : Math.round(x) + (Math.round(x) === 1 ? " día" : " días"));
const EST = { observando: "Observando", adoptado: "Proceso adoptado", descartado: "Descartado" };

function listo(g) { return g.n >= MIN_TAREAS && g.primera && (Date.now() - new Date(g.primera).getTime()) >= MIN_DIAS * DAY; }
function faltan(g) { const d = g.primera ? Math.max(0, Math.ceil(MIN_DIAS - (Date.now() - new Date(g.primera).getTime()) / DAY)) : MIN_DIAS; return { d, t: Math.max(0, MIN_TAREAS - g.n) }; }

function propuesta(g) {
  const pct = g.cumplidas ? Math.round(100 * g.a_tiempo / g.cumplidas) : null;
  const resp = (g.responsables || []);
  const lineas = [];
  lineas.push("Se repite " + g.n + " veces" + (g.intervalo ? ", una cada ~" + dias(g.intervalo) : "") + ".");
  if (resp.length) lineas.push("Lo ejecutan: " + resp.map((r) => r.name + " (" + r.n + ")").join(", ") + (resp.length > 1 ? " → conviene fijar un responsable titular y un reemplazo." : " → responsable natural del proceso."));
  if (g.dur_mediana != null) lineas.push("Tarda normalmente " + dias(g.dur_mediana) + (pct != null ? " y se cumple a tiempo el " + pct + "%" : "") + ".");
  if (pct != null && pct < 70) lineas.push("Cumplimiento bajo: el plazo estándar debería ser mayor o dividirse en etapas.");
  const et = g.etapas && g.etapas.length ? g.etapas : null;
  lineas.push("Etapas propuestas: " + (et ? et.join(" → ") : "Preparar → Ejecutar → Verificar → Informar") + (g.proc ? " (proceso base del catálogo: " + g.proc + ")" : "") + ".");
  lineas.push("Plazo sugerido: " + dias(Math.max(g.dur_mediana || 1, 1) * 1.25) + " desde que se asigna.");
  return lineas;
}

function NuevoGrupo({ ini, es, onClose, onOk }) {
  const [nombre, setNombre] = useState(ini ? ini.nombre : ""); const [pal, setPal] = useState(ini ? ini.palabras.join(", ") : "");
  const [det, setDet] = useState(""); const [busy, setBusy] = useState(false);
  async function crear() {
    if (!nombre.trim()) return Alert.alert("Escribe un nombre");
    const palabras = pal.split(",").map((x) => x.trim()).filter(Boolean);
    if (!palabras.length) return Alert.alert("Escribe al menos una palabra clave");
    setBusy(true);
    const { error } = es ? await supabase.rpc("crear_grupo", { p_nombre: nombre.trim(), p_palabras: palabras })
      : await supabase.rpc("sugerir_proceso", { p_titulo: nombre.trim(), p_detalle: det.trim(), p_palabras: palabras, p_grupo: null });
    setBusy(false);
    if (error) return Alert.alert(es ? "No se pudo crear" : "No se pudo enviar", errMsg(error));
    if (!es) Alert.alert("Sugerencia enviada", "El Comandante la revisa. Verás aquí si la aprueba o la rechaza.");
    onOk(); onClose();
  }
  return (
    <Sheet visible title={es ? "Nuevo grupo de tareas" : "Sugerir grupo de tareas"} onClose={onClose}>
      <Field label="Nombre del grupo" value={nombre} onChangeText={setNombre} placeholder="Ej.: Reparación de viviendas fiscales" />
      <Field label="Palabras clave (separadas por coma)" value={pal} onChangeText={setPal} placeholder="Ej.: reparacion, vf" />
      {es ? null : <Field label="¿Por qué lo sugieres? (opcional)" value={det} onChangeText={setDet} placeholder="Ej.: se repite todos los meses" />}
      <Note kind="info" text="Entran al grupo todas las tareas cuyo título contenga TODAS las palabras (sin importar tildes ni mayúsculas), las actuales y las que se creen desde ahora." />
      <Btn title={busy ? "Enviando…" : es ? "Crear grupo" : "Enviar sugerencia al Comandante"} kind="primary" disabled={busy} onPress={crear} />
    </Sheet>);
}

function SugerirProceso({ g, onClose, onOk }) {
  const [det, setDet] = useState(""); const [busy, setBusy] = useState(false);
  async function enviar() {
    setBusy(true);
    const { error } = await supabase.rpc("sugerir_proceso", { p_titulo: "Adoptar como proceso: " + g.nombre, p_detalle: det.trim(), p_palabras: [], p_grupo: g.id });
    setBusy(false);
    if (error) return Alert.alert("No se pudo enviar", errMsg(error));
    Alert.alert("Sugerencia enviada", "El Comandante decide si se adopta como proceso.");
    onOk(); onClose();
  }
  return (
    <Sheet visible title="Sugerir adoptar como proceso" onClose={onClose}>
      <Text style={S.title}>{g.nombre}</Text>
      <Field label="Comentario para el Comandante (opcional)" value={det} onChangeText={setDet} placeholder="Ej.: responsable titular, plazo, etapas" />
      <Btn title={busy ? "Enviando…" : "Enviar sugerencia"} kind="primary" disabled={busy} onPress={enviar} />
    </Sheet>);
}

const EST_SUG = { pendiente: "PENDIENTE", aprobada: "APROBADA", rechazada: "RECHAZADA" };
function Sugerencias({ list, es, onOk }) {
  if (!list.length) return null;
  const resolver = async (s, ok, motivo) => {
    const { error } = await supabase.rpc("resolver_sugerencia", { p_id: s.id, p_aprobar: ok, p_motivo: motivo || "" });
    if (error) return Alert.alert("No se pudo", errMsg(error)); onOk();
  };
  const rechazar = (s) => {
    if (Alert.prompt) return Alert.prompt("Rechazar sugerencia", "Motivo (opcional)", (m) => resolver(s, false, m));
    Alert.alert("¿Rechazar “" + s.titulo + "”?", "", [{ text: "No", style: "cancel" }, { text: "Rechazar", style: "destructive", onPress: () => resolver(s, false, "") }]);
  };
  const pend = list.filter((s) => s.estado === "pendiente");
  return (<>
    <Text style={S.label}>📨 Sugerencias del equipo{pend.length ? " · " + pend.length + " pendientes" : ""}</Text>
    {list.slice(0, 15).map((s) => (
      <Card key={s.id} tone={s.estado === "pendiente" && es ? "warn" : undefined} style={{ gap: 4 }}>
        <Between><Text style={[S.title, { flex: 1 }]}>{s.titulo}</Text><Badge kind={s.estado === "aprobada" ? "done" : s.estado === "rechazada" ? "over" : "soon"} text={EST_SUG[s.estado]} /></Between>
        <Text style={S.small}>{(s.tipo === "grupo" ? "Grupo nuevo · palabras: " + (s.palabras || []).join(", ") : "Proceso" + (s.grupo ? " · grupo " + s.grupo : "")) + " · sugiere " + (s.autor || "—") + " · " + fmtDay(new Date(s.creada).getTime())}</Text>
        {s.detalle ? <Text style={S.body}>{s.detalle}</Text> : null}
        {s.estado === "rechazada" && s.motivo ? <Text style={S.small}>Motivo: {s.motivo}</Text> : null}
        {es && s.estado === "pendiente" ? <Row><Btn small kind="primary" title="✓ Aprobar" onPress={() => resolver(s, true)} /><Btn small title="Rechazar" onPress={() => rechazar(s)} /></Row> : null}
      </Card>))}
  </>);
}

export function Procesos({ d }) {
  const [data, setData] = useState(null); const [err, setErr] = useState(""); const [nuevo, setNuevo] = useState(null);
  const [ver, setVer] = useState(null); const [sugProc, setSugProc] = useState(null);
  const cargar = useCallback(async () => {
    const { data: r, error } = await supabase.rpc("procesos_panel");
    if (error) return setErr(errMsg(error)); setErr(""); setData(r);
  }, []);
  useEffect(() => { cargar(); }, [cargar]);

  // Sugerencias de grupos nuevos entre las tareas sin agrupar (similitud de palabras clave)
  const sugeridos = useMemo(() => {
    const items = ((data && data.sin_grupo) || []).map((x) => ({ ...x, k: claves(x.titulo) })).filter((x) => x.k.length >= 2);
    const usados = new Set(); const out = [];
    for (let i = 0; i < items.length; i++) {
      if (usados.has(i)) continue; const base = items[i]; const grupo = [i];
      for (let j = i + 1; j < items.length; j++) {
        if (usados.has(j)) continue;
        const com = base.k.filter((w) => items[j].k.includes(w));
        if (com.length >= 2) grupo.push(j);
      }
      if (grupo.length >= 2) {
        const comunes = grupo.map((x) => items[x].k).reduce((a, b) => a.filter((w) => b.includes(w)));
        if (comunes.length >= 1) { grupo.forEach((x) => usados.add(x)); out.push({ items: grupo.map((x) => items[x]), palabras: comunes.slice(0, 3) }); }
      }
    }
    return out.sort((a, b) => b.items.length - a.items.length).slice(0, 8);
  }, [data]);

  if (err) return <Note kind="bad" text={"No se pudo cargar: " + err + ". Si es la primera vez, falta aplicar la base de datos de Procesos."} />;
  if (!data) return <Empty text="Cargando…" />;
  const es = !!data.es_cdte;
  const grupos = data.grupos || []; const listos = grupos.filter((g) => listo(g) && g.estado === "observando");
  const cambiar = async (g, estado) => { const { error } = await supabase.rpc("estado_grupo", { p_id: g.id, p_estado: estado }); if (error) return Alert.alert("No se pudo", errMsg(error)); cargar(); };
  const borrar = (g) => Alert.alert("¿Eliminar el grupo “" + g.nombre + "”?", "Las tareas no se borran: vuelven a “sin agrupar”.", [{ text: "No", style: "cancel" }, { text: "Eliminar", style: "destructive", onPress: async () => { const { error } = await supabase.rpc("borrar_grupo", { p_id: g.id }); if (error) return Alert.alert("No se pudo", errMsg(error)); cargar(); } }]);

  return (
    <View style={{ gap: 12 }}>
      <Note kind="info" text={"Aquí se agrupan las tareas parecidas. Cuando un grupo lleva " + MIN_DIAS + " días y al menos " + MIN_TAREAS + " tareas, la app propone un proceso. La ven el Comandante, CB1 Llancavil, Viviana Urrutia, SG1 Urquieta y SOF Ramírez. " + (es ? "Ellos pueden sugerir; tú apruebas." : "Puedes sugerir grupos y procesos; el Comandante los aprueba.")} />

      <Sugerencias list={data.sugerencias || []} es={es} onOk={cargar} />

      {listos.length ? <><Text style={S.label}>💡 Posibles procesos · listos para revisar ({listos.length})</Text>
        {listos.map((g) => (
          <Card key={g.id} tone="warn" style={{ gap: 6 }}>
            <Text style={S.title}>{g.nombre}</Text>
            {propuesta(g).map((l, i) => <Text key={i} style={S.body}>• {l}</Text>)}
            {es ? <Row><Btn small kind="primary" title="✓ Adoptar como proceso" onPress={() => cambiar(g, "adoptado")} /><Btn small title="Descartar" onPress={() => cambiar(g, "descartado")} /></Row>
              : <Row><Btn small kind="primary" title="Sugerir adoptarlo" onPress={() => setSugProc(g)} /></Row>}
          </Card>))}</> : null}

      <Between><Text style={S.label}>Grupos de tareas ({grupos.length})</Text><Btn small title={es ? "＋ Nuevo grupo" : "＋ Sugerir grupo"} onPress={() => setNuevo({})} /></Between>
      {grupos.length ? grupos.map((g) => {
        const f = faltan(g); const pct = g.cumplidas ? Math.round(100 * g.a_tiempo / g.cumplidas) : null;
        return (
          <Card key={g.id} style={{ gap: 4 }}>
            <Between><Text style={[S.title, { flex: 1 }]}>{g.nombre}</Text><Badge kind={g.estado === "adoptado" ? "done" : g.estado === "descartado" ? "over" : "ok"} text={EST[g.estado].toUpperCase()} /></Between>
            <Text style={S.small}>{g.n} tareas · {g.abiertas} abiertas · {g.cumplidas} cumplidas{pct != null ? " (" + pct + "% a tiempo)" : ""} · palabras: {g.palabras.join(", ")}</Text>
            {g.estado === "observando" && !listo(g) ? <Text style={S.small}>Observando: faltan {f.d > 0 ? f.d + " días" : ""}{f.d > 0 && f.t > 0 ? " y " : ""}{f.t > 0 ? f.t + " tareas" : ""} para proponer un proceso.</Text> : null}
            {g.estado === "adoptado" ? propuesta(g).map((l, i) => <Text key={i} style={S.small}>• {l}</Text>) : null}
            <Row><Btn small title={ver === g.id ? "Ocultar" : "Ver propuesta"} onPress={() => setVer(ver === g.id ? null : g.id)} />{es && g.estado !== "observando" ? <Btn small title="Volver a observar" onPress={() => cambiar(g, "observando")} /> : null}{es ? <Btn small kind="danger" title="Eliminar" onPress={() => borrar(g)} /> : null}</Row>
            {ver === g.id ? <View style={{ gap: 2, marginTop: 4 }}>{g.n < 2 ? <Text style={S.small}>Aún hay muy pocos datos para proponer un proceso.</Text> : propuesta(g).map((l, i) => <Text key={i} style={S.small}>• {l}</Text>)}</View> : null}
          </Card>);
      }) : <Empty text="Aún no hay grupos. Crea uno o usa las sugerencias de abajo." />}

      {sugeridos.length ? <><Text style={S.label}>🧩 Sugerencias: tareas parecidas sin grupo</Text>
        {sugeridos.map((s, i) => (
          <Card key={i} style={{ gap: 4 }}>
            <Text style={S.title}>{s.items.length} tareas parecidas · {s.palabras.join(", ")}</Text>
            {s.items.slice(0, 4).map((x) => <Text key={x.id} style={S.small}>• {x.titulo}{x.responsable ? " · " + x.responsable : ""}</Text>)}
            {s.items.length > 4 ? <Text style={S.small}>… y {s.items.length - 4} más</Text> : null}
            <Btn small kind="primary" title={es ? "Crear grupo con estas palabras" : "Sugerir grupo con estas palabras"} onPress={() => setNuevo({ nombre: "", palabras: s.palabras })} />
          </Card>))}</> : null}
      <Text style={S.small}>{(data.sin_grupo || []).length} tareas sin agrupar.</Text>
      {nuevo ? <NuevoGrupo ini={nuevo.palabras ? nuevo : null} es={es} onClose={() => setNuevo(null)} onOk={cargar} /> : null}
      {sugProc ? <SugerirProceso g={sugProc} onClose={() => setSugProc(null)} onOk={cargar} /> : null}
    </View>);
}
