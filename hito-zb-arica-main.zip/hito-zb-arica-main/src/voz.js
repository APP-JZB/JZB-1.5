// Dictado por voz (micrófono) en español de Chile. Web: Web Speech API. Android/iOS: expo-speech-recognition.
import React, { useEffect, useRef, useState } from "react";
import { Platform, Alert, Text, View } from "react-native";
import { Btn } from "./ui";

function modNativo() { try { return require("expo-speech-recognition").ExpoSpeechRecognitionModule; } catch (e) { return null; } }

export function Dictar({ onText, label }) {
  const [on, setOn] = useState(false); const [parcial, setParcial] = useState("");
  const ref = useRef(null); const subs = useRef([]);
  const limpiar = () => { subs.current.forEach((s) => { try { s.remove(); } catch (e) {} }); subs.current = []; };
  useEffect(() => () => { limpiar(); try { ref.current && ref.current.stop && ref.current.stop(); } catch (e) {} }, []);

  async function start() {
    setParcial("");
    if (Platform.OS === "web") {
      const SR = typeof window !== "undefined" && (window.SpeechRecognition || window.webkitSpeechRecognition);
      if (!SR) return Alert.alert("Sin dictado en este navegador", "Usa Chrome o Safari, o el micrófono del teclado del teléfono.");
      const r = new SR(); r.lang = "es-CL"; r.interimResults = true; r.continuous = true;
      r.onresult = (e) => { let fin = "", tmp = ""; for (let i = e.resultIndex; i < e.results.length; i++) { const t = e.results[i][0].transcript; if (e.results[i].isFinal) fin += t; else tmp += t; } if (fin) onText(fin.trim()); setParcial(tmp); };
      r.onerror = (e) => { if (e.error === "not-allowed") Alert.alert("Micrófono bloqueado", "Permite el micrófono para esta página en el navegador."); setOn(false); };
      r.onend = () => { setOn(false); setParcial(""); };
      ref.current = r; r.start(); setOn(true); return;
    }
    const M = modNativo();
    if (!M) return Alert.alert("Dictado no disponible", "Actualiza Hito a la última versión o usa el micrófono del teclado.");
    const perm = await M.requestPermissionsAsync();
    if (!perm.granted) return Alert.alert("Sin permiso de micrófono", "Actívalo en Ajustes → Aplicaciones → Hito → Permisos → Micrófono.");
    limpiar();
    subs.current.push(M.addListener("result", (e) => { const t = (e.results && e.results[0] && e.results[0].transcript) || ""; if (e.isFinal) { if (t) onText(t.trim()); setParcial(""); } else setParcial(t); }));
    subs.current.push(M.addListener("error", (e) => { if (e.error !== "no-speech" && e.error !== "aborted") Alert.alert("Dictado", e.message || e.error); setOn(false); }));
    subs.current.push(M.addListener("end", () => { setOn(false); setParcial(""); limpiar(); }));
    ref.current = M;
    M.start({ lang: "es-CL", interimResults: true, continuous: true, addsPunctuation: true });
    setOn(true);
  }
  function stop() { try { ref.current && ref.current.stop && ref.current.stop(); } catch (e) {} setOn(false); }

  return (
    <View style={{ gap: 4 }}>
      <Btn title={on ? "■ Detener dictado" : "🎤 " + (label || "Dictar")} kind={on ? "danger" : "default"} onPress={on ? stop : start} />
      {on ? <Text style={{ fontSize: 12, color: "#4B5A54" }}>Escuchando… {parcial ? "“" + parcial + "”" : "habla ahora"}</Text> : null}
    </View>
  );
}
