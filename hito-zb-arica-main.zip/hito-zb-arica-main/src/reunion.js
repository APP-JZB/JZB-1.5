// Reunión de Coordinación semanal: foto de tareas guardada cada jueves 17:00 (tabla reuniones),
// vista en pantalla completa y descarga en PowerPoint con el formato de la ZB Arica.
import React, { useEffect, useMemo, useState, useCallback, useRef } from "react";
import { View, Text, Pressable, ScrollView, Modal, Platform, Alert, useWindowDimensions, Image, TextInput } from "react-native";
import { supabase } from "./lib";
import { C, Btn, Card, Note, Row, Chip } from "./ui";
import { entregar } from "./exportar";
import { ESCUDO_ZB } from "./escudo_zb";

const MES = ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"];
const fd = (iso) => (iso ? iso.slice(8, 10) + MES[Number(iso.slice(5, 7)) - 1] : "");
const fLarga = (iso) => (iso ? Number(iso.slice(8, 10)) + " " + MES[Number(iso.slice(5, 7)) - 1] + " " + iso.slice(0, 4) : "");
const fCorta = (iso) => (iso ? iso.slice(8, 10) + MES[Number(iso.slice(5, 7)) - 1] + iso.slice(0, 4) : "");
const plus = (iso, n) => { const d = new Date(iso + "T12:00:00"); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
const pesos = (n) => "$ " + Math.round(Number(n || 0)).toLocaleString("es-CL").replace(/,/g, ".");
const corto = (name) => { const p = String(name || "").trim().split(/\s+/); if (p.length >= 4) return p[0] + " " + p[2]; return p.length > 1 ? p[0] + " " + p[p.length - 1] : p[0] || "—"; };

const HX = { navy: "14213D", red: "C8102E", gold: "E9B824", green: "1E8E5A", blue: "2563A6", amber: "D98E04", ink: "1B2333", muted: "5B6578", line: "D5DAE3", soft: "EEF1F6" };
export const Q = {
  EJE: { t: "Tareas ejecutadas · última semana", c: HX.green, tint: "E7F4ED", g: "✓" },
  DES: { t: "Tareas en desarrollo", c: HX.blue, tint: "E8EFF8", g: "↻" },
  POR: { t: "Tareas por ejecutar", c: HX.amber, tint: "FBF1E1", g: "☰" },
  CRI: { t: "Sucesos críticos · vencidas", c: HX.red, tint: "FBE7EA", g: "!" },
};
const KS = ["EJE", "DES", "POR", "CRI"];
// Diapositivas por sección (mismo orden de la presentación de la ZB)
const SECCIONES = [
  ["Comando y Grupo Personal", "Asesoría Jurídica · CGA · Administración de contratos", [["Asesoría Jurídica", ["AJ"]], ["Centro de Gestión de Adquisiciones", ["CGA"]], ["Administrador de Contratos", ["CTO"]]]],
  ["Jefatura Administrativa · Plana Mayor", "Comando · Personal · Seguridad · Operaciones y OCGR · Logística · Finanzas", [["Comando y Plana Mayor", ["CDO"]], ["Oficina de Personal", ["PER"]], ["Oficina de Seguridad y Computación", ["SEG"]], ["Asesor de Operaciones y OCGR", ["PLAN", "OCGR"]], ["Oficina de Coordinación Logística", ["LOG"]], ["Finanzas", ["FIN"]]]],
  ["Sección Habitacional", "Viviendas fiscales · reparaciones · restituciones", [["Sección Habitacional", ["VF"]]]],
  ["Sección Asistencial", "Jardín Infantil “Soldadito de Plomo” · Convenios", [["Jardín Infantil", ["JI"]], ["Sección Asistencial y Convenios", ["ASI"]]]],
  ["Sección Recreacional", "Recreacional · CRA · Club de Oficiales El Morro", [["Sección Recreacional", ["REC"]], ["Centro Recreacional Arica", ["CRA"]], ["Club de Oficiales El Morro", ["COEM"]]]],
  ["Sección Habitabilidad", "Pabellones · salas de bombas · quincho", [["Sección Habitabilidad", ["HAB"]]]],
  ["Personal de Apoyo General y CC", "ITO · Equipo de apoyo y mantenimiento", [["ITO (Contraparte Técnica)", ["ITO"]], ["Equipo de Apoyo · Mantenimiento", ["MANT"]]]],
];
const ORDEN = SECCIONES.flatMap((s) => s[2].flatMap((a) => a[1]));

// Clasifica las tareas de la foto en los 4 cuadrantes, respecto de la fecha de la reunión.
export function procesar(reu, aportes, soloAreas) {
  const seen = new Set();
  const T = (reu.datos || []).map((t) => ({ area: t.area || "CDO", title: t.titulo, resp: corto(t.resp), due: t.plazo, done: !!t.hecha, doneAt: t.hecha_el, prog: Number(t.avance || 0) }))
    .filter((t) => { const k = t.area + t.title + t.resp; if (seen.has(k)) return false; seen.add(k); return true; });
  T.forEach((t) => { t.est = t.done ? "EJE" : t.due < reu.semana ? "CRI" : t.prog > 0 ? "DES" : "POR"; });
  const grupo = (codes) => {
    const l = T.filter((t) => codes.includes(t.area)); const o = {};
    KS.forEach((k) => {
      o[k] = l.filter((t) => t.est === k).sort(k === "EJE" ? (a, b) => (b.doneAt || "").localeCompare(a.doneAt || "") : (a, b) => a.due.localeCompare(b.due) || b.prog - a.prog);
      // Aportes de los jefes: se agregan al final, nunca reemplazan lo que viene de Hito
      (aportes || []).filter((x) => codes.includes(x.area) && x.cuadrante === k).forEach((x) => o[k].push({ title: x.texto, resp: x.autorNombre || "", extra: true, est: k, due: "", prog: 0 }));
    });
    o.resps = [...new Set(l.map((t) => t.resp))]; return o;
  };
  const cnt = {}; KS.forEach((k) => (cnt[k] = T.filter((t) => t.est === k).length));
  const porArea = ORDEN.map((a) => { const o = { a }; KS.forEach((k) => (o[k] = T.filter((t) => t.area === a && t.est === k).length)); return o; });
  const cri = T.filter((t) => t.est === "CRI").sort((a, b) => a.due.localeCompare(b.due));
  const saldos = (reu.saldos || []).filter((s) => s.monto != null);
  return { T, grupo, cnt, porArea, cri, saldos, soloAreas };
}

/* ====================== PowerPoint ====================== */
export async function descargarPpt(reu, aportes) {
  const PptxGenJS = require("pptxgenjs");
  const P = PptxGenJS.default || PptxGenJS;
  const pres = new P();
  const R = procesar(reu, aportes);
  const corteTxt = fCorta(String(reu.generado_at || "").slice(0, 10));
  pres.layout = "LAYOUT_WIDE"; pres.title = "Reunión de Coordinación " + fCorta(reu.semana); pres.company = "Zona de Bienestar Arica";
  pres.theme = { headFontFace: "Cambria", bodyFontFace: "Calibri" };
  const H = "Cambria", B = "Calibri";
  pres.defineSlideMaster({ title: "OSCURA", background: { color: HX.navy } });
  pres.defineSlideMaster({
    title: "CONTENIDO", background: { color: "FFFFFF" },
    objects: [
      { image: { data: ESCUDO_ZB, x: 12.25, y: 0.3, w: 0.62, h: 0.62 } },
      { text: { text: "ZB Arica · Reunión de Coordinación " + fCorta(reu.semana) + " · Fuente: Hito al " + corteTxt, options: { x: 0.5, y: 7.08, w: 9, h: 0.3, fontFace: B, fontSize: 10, color: HX.muted, margin: 0 } } },
    ],
    slideNumber: { x: 12.3, y: 7.08, w: 0.6, h: 0.3, fontFace: B, fontSize: 10, color: HX.muted, align: "right" },
  });
  const sombra = () => ({ type: "outer", color: "8090A8", blur: 6, offset: 2, angle: 90, opacity: 0.25 });
  const titulo = (s, t) => s.addText(t, { x: 0.5, y: 0.3, w: 11.4, h: 0.65, fontFace: H, fontSize: 30, bold: true, color: HX.navy, valign: "middle", margin: 0, isTextBox: true });
  const sub = (s, t) => s.addText(t, { x: 0.5, y: 0.98, w: 11.4, h: 0.34, fontFace: B, fontSize: 12, color: HX.muted, margin: 0, valign: "middle", isTextBox: true });

  // Portada
  let s = pres.addSlide({ masterName: "OSCURA" });
  s.addImage({ data: ESCUDO_ZB, x: 8.35, y: 1.05, w: 4.1, h: 4.1 });
  s.addText("Reunión de Coordinación", { x: 0.7, y: 2.0, w: 7.4, h: 1.7, fontFace: H, fontSize: 44, bold: true, color: "FFFFFF", valign: "bottom", margin: 0, isTextBox: true });
  s.addText([
    { text: fLarga(reu.semana), options: { bold: true, fontSize: 26, color: HX.gold, breakLine: true } },
    { text: "Zona de Bienestar “Arica”", options: { color: "FFFFFF", fontSize: 18, breakLine: true } },
    { text: "Pendientes de la semana " + fd(reu.semana) + " – " + fd(plus(reu.semana, 7)) + ", tomados de Hito", options: { color: "C9D2E3", fontSize: 14 } },
  ], { x: 0.7, y: 3.85, w: 7.4, h: 1.5, fontFace: B, valign: "top", margin: 0, isTextBox: true });
  s.addText("Foto guardada el " + corteTxt + " (" + (reu.generado_por || "") + ")", { x: 0.7, y: 6.35, w: 9, h: 0.4, fontFace: B, fontSize: 12, color: "C9D2E3", margin: 0, isTextBox: true });

  // Resumen
  s = pres.addSlide({ masterName: "CONTENIDO" }); titulo(s, "Resumen de la semana");
  KS.forEach((k, i) => {
    const x = 0.5 + i * 3.1, y = 1.2;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 2.85, h: 1.45, fill: { color: Q[k].c }, line: { color: Q[k].c }, rectRadius: 0.1, shadow: sombra() });
    s.addText(String(R.cnt[k]), { x: x + 0.25, y: y + 0.12, w: 1.6, h: 0.8, fontFace: H, fontSize: 44, bold: true, color: "FFFFFF", margin: 0, isTextBox: true });
    s.addText(Q[k].g, { x: x + 2.0, y: y + 0.2, w: 0.65, h: 0.65, fontFace: B, fontSize: 28, bold: true, color: "FFFFFF", align: "center", valign: "middle", margin: 0, isTextBox: true });
    s.addText(Q[k].t.split(" · ")[0].replace("Tareas ", "").replace(/^./, (m) => m.toUpperCase()), { x: x + 0.25, y: y + 0.92, w: 2.5, h: 0.4, fontFace: B, fontSize: 14, bold: true, color: "FFFFFF", margin: 0, isTextBox: true });
  });
  const lab = R.porArea.map((o) => o.a).reverse();
  s.addChart(pres.charts.BAR, KS.map((k) => ({ name: Q[k].t.split(" · ")[0].replace("Tareas ", ""), labels: lab, values: R.porArea.map((o) => o[k]).reverse() })), {
    x: 0.5, y: 2.85, w: 12.35, h: 4.15, barDir: "bar", barGrouping: "stacked", chartColors: [HX.green, HX.blue, HX.amber, HX.red],
    showLegend: true, legendPos: "t", legendFontSize: 11, legendFontFace: B, legendColor: HX.ink, catAxisLabelFrequency: 1,
    catAxisLabelFontSize: 10, catAxisLabelColor: HX.ink, catAxisLabelFontFace: B, valAxisLabelFontSize: 10, valAxisLabelColor: HX.muted, valAxisLabelFontFace: B,
    valGridLine: { color: "E3E7EE", size: 0.5 }, catGridLine: { style: "none" }, barGapWidthPct: 45,
    showTitle: true, title: "Tareas por área", titleFontSize: 13, titleColor: HX.ink, titleFontFace: B,
  });

  // Críticos
  const pages = []; for (let i = 0; i < R.cri.length; i += 12) pages.push(R.cri.slice(i, i + 12));
  pages.forEach((pg, pi) => {
    s = pres.addSlide({ masterName: "CONTENIDO" });
    titulo(s, "Sucesos críticos: tareas vencidas" + (pages.length > 1 ? " (" + (pi + 1) + "/" + pages.length + ")" : ""));
    sub(s, R.cri.length + " tareas con plazo vencido antes de la reunión. Requieren resolución o prórroga.");
    const head = ["Área", "Tarea", "Responsable", "Plazo", "Avance"].map((h) => ({ text: h, options: { bold: true, color: "FFFFFF", fill: { color: HX.red }, fontSize: 12 } }));
    const rows = pg.map((t, i) => { const f = { color: i % 2 ? "FFFFFF" : "FBF2F3" }; return [
      { text: t.area, options: { bold: true, color: HX.red, fill: f } }, { text: t.title, options: { fill: f } }, { text: t.resp, options: { fill: f } },
      { text: fd(t.due), options: { bold: true, fill: f } }, { text: t.prog + "%", options: { fill: f, align: "right" } }]; });
    s.addTable([head, ...rows], { x: 0.5, y: 1.5, w: 12.35, colW: [0.9, 7.05, 2.2, 1.1, 1.1], fontSize: 11, fontFace: B, color: HX.ink, border: { type: "solid", pt: 0.5, color: "E6D3D6" }, rowH: 0.36, valign: "middle", margin: [0.03, 0.08, 0.03, 0.08] });
  });

  // Saldos por centro de costo
  if (R.saldos.length) {
    s = pres.addSlide({ masterName: "CONTENIDO" }); titulo(s, "Saldos disponibles por centro de costo");
    const tot = R.saldos.reduce((a, x) => a + Number(x.monto || 0), 0);
    sub(s, "Total disponible: " + pesos(tot) + " · informado en Hito");
    const head = ["Centro de costo", "Código", "Saldo"].map((h, j) => ({ text: h, options: { bold: true, color: "FFFFFF", fill: { color: HX.navy }, align: j === 2 ? "right" : "left" } }));
    const rows = R.saldos.map((x, i) => { const f = { color: i % 2 ? "FFFFFF" : HX.soft }; return [
      { text: x.centro, options: { fill: f, bold: true } }, { text: x.codigo || "", options: { fill: f, color: HX.muted } },
      { text: pesos(x.monto), options: { fill: f, align: "right", bold: true, color: Number(x.monto) === 0 ? HX.red : HX.ink } }]; });
    rows.push([{ text: "TOTAL", options: { bold: true, fill: { color: "FBF1E1" } } }, { text: "", options: { fill: { color: "FBF1E1" } } }, { text: pesos(tot), options: { bold: true, align: "right", fill: { color: "FBF1E1" } } }]);
    s.addTable([head, ...rows], { x: 0.5, y: 1.45, w: 6.4, colW: [3.3, 1.4, 1.7], fontSize: 11, fontFace: B, color: HX.ink, rowH: Math.min(0.4, 5.4 / (rows.length + 1)), valign: "middle", border: { type: "solid", pt: 0.5, color: HX.line }, margin: [0.03, 0.06, 0.03, 0.06] });
    const srt = R.saldos.slice().sort((a, b) => a.monto - b.monto);
    s.addChart(pres.charts.BAR, [{ name: "Saldo (MM$)", labels: srt.map((x) => x.centro), values: srt.map((x) => Math.round(Number(x.monto) / 1e5) / 10) }], {
      x: 7.15, y: 1.35, w: 5.7, h: 5.6, barDir: "bar", chartColors: [HX.red], showLegend: false, showValue: true, dataLabelPosition: "outEnd", dataLabelFontSize: 10, dataLabelColor: HX.ink, dataLabelFontFace: B, dataLabelFormatCode: "0.0",
      catAxisLabelFrequency: 1, catAxisLabelFontSize: 9, catAxisLabelColor: HX.ink, catAxisLabelFontFace: B, valAxisHidden: true, valGridLine: { style: "none" }, catGridLine: { style: "none" },
      showTitle: true, title: "Saldo disponible (millones de $)", titleFontSize: 13, titleColor: HX.ink, titleFontFace: B, barGapWidthPct: 40,
    });
  }

  // Áreas
  const MAXI = 6;
  const cuad = (sl, k, list, x, y, w, h) => {
    sl.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, fill: { color: Q[k].tint }, line: { color: Q[k].tint }, rectRadius: 0.1 });
    sl.addShape(pres.shapes.OVAL, { x: x + 0.18, y: y + 0.13, w: 0.46, h: 0.46, fill: { color: Q[k].c }, line: { color: Q[k].c } });
    sl.addText(Q[k].g, { x: x + 0.18, y: y + 0.13, w: 0.46, h: 0.46, fontFace: B, fontSize: 16, bold: true, color: "FFFFFF", align: "center", valign: "middle", margin: 0, isTextBox: true });
    sl.addText(Q[k].t.toUpperCase(), { x: x + 0.75, y: y + 0.13, w: w - 1.6, h: 0.46, fontFace: B, fontSize: 12.5, bold: true, color: Q[k].c, margin: 0, valign: "middle", isTextBox: true });
    sl.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + w - 0.78, y: y + 0.17, w: 0.6, h: 0.38, fill: { color: Q[k].c }, line: { color: Q[k].c }, rectRadius: 0.19 });
    sl.addText(String(list.length), { x: x + w - 0.78, y: y + 0.17, w: 0.6, h: 0.38, fontFace: B, fontSize: 13, bold: true, color: "FFFFFF", align: "center", valign: "middle", margin: 0, isTextBox: true });
    const by = y + 0.7;
    if (!list.length) { sl.addText(k === "CRI" ? "Sin tareas vencidas" : "Sin registros en Hito", { x: x + 0.3, y: by, w: w - 0.6, h: 0.4, fontFace: B, fontSize: 12, italic: true, color: HX.muted, margin: 0, isTextBox: true }); return; }
    const ex = list.filter((t) => t.extra), base = list.filter((t) => !t.extra);
    const show = base.slice(0, Math.max(2, MAXI - ex.length)).concat(ex); const runs = [];
    const resto = list.length - show.length;
    show.forEach((t, i) => {
      if (t.extra) {
        runs.push({ text: "＋ " + t.title, options: { bullet: false, fontSize: 11.5, bold: true, color: Q[k].c } });
        runs.push({ text: "  agregado por " + t.resp, options: { fontSize: 10, italic: true, color: HX.muted, breakLine: i < show.length - 1 || resto > 0 } });
        return;
      }
      const meta = "  " + t.resp + " · " + (t.est === "EJE" ? "lista " + fd(t.doneAt) : fd(t.due)) + (t.est === "DES" || (t.est === "CRI" && t.prog) ? " · " + t.prog + "%" : "");
      runs.push({ text: t.title.length > 92 ? t.title.slice(0, 89).trim() + "…" : t.title, options: { bullet: { indent: 12 }, fontSize: 11.5, color: HX.ink } });
      runs.push({ text: meta, options: { fontSize: 10, color: HX.muted, breakLine: i < show.length - 1 || resto > 0 } });
    });
    if (resto > 0) runs.push({ text: "+ " + resto + " más en Hito", options: { fontSize: 10.5, italic: true, bold: true, color: Q[k].c } });
    sl.addText(runs, { x: x + 0.2, y: by, w: w - 0.4, h: h - 0.82, fontFace: B, valign: "top", margin: [0, 2, 0, 2], paraSpaceAfter: 3, fit: "shrink", isTextBox: true });
  };
  SECCIONES.forEach(([sec, subt, areas]) => {
    s = pres.addSlide({ masterName: "OSCURA" });
    s.addImage({ data: ESCUDO_ZB, x: 0.7, y: 2.05, w: 3.4, h: 3.4 });
    s.addText(sec, { x: 4.6, y: 2.4, w: 8.0, h: 1.5, fontFace: H, fontSize: 40, bold: true, color: "FFFFFF", valign: "bottom", margin: 0, isTextBox: true });
    s.addText(subt, { x: 4.6, y: 4.05, w: 8.0, h: 1.0, fontFace: B, fontSize: 18, color: HX.gold, valign: "top", margin: 0, isTextBox: true });
    areas.forEach(([nombre, codes]) => {
      const g = R.grupo(codes);
      const sl = pres.addSlide({ masterName: "CONTENIDO" }); titulo(sl, nombre);
      sub(sl, "Responsables: " + (g.resps.length ? g.resps.slice(0, 6).join(" · ") : "sin tareas asignadas"));
      const X0 = 0.5, Y0 = 1.45, W = 6.05, Hh = 2.68, G = 0.25;
      cuad(sl, "EJE", g.EJE, X0, Y0, W, Hh); cuad(sl, "DES", g.DES, X0 + W + G, Y0, W, Hh);
      cuad(sl, "POR", g.POR, X0, Y0 + Hh + G, W, Hh); cuad(sl, "CRI", g.CRI, X0 + W + G, Y0 + Hh + G, W, Hh);
    });
  });
  s = pres.addSlide({ masterName: "OSCURA" });
  s.addImage({ data: ESCUDO_ZB, x: 8.35, y: 1.05, w: 4.1, h: 4.1 });
  s.addText("Fin de la presentación", { x: 0.7, y: 2.0, w: 7.4, h: 1.7, fontFace: H, fontSize: 44, bold: true, color: "FFFFFF", valign: "bottom", margin: 0, isTextBox: true });
  s.addText([{ text: "Próxima reunión: " + fLarga(plus(reu.semana, 7)), options: { bold: true, color: HX.gold, fontSize: 20, breakLine: true } }, { text: "Mantener las tareas al día en Hito: esta presentación se arma con ellas.", options: { color: "C9D2E3", fontSize: 14 } }], { x: 0.7, y: 3.85, w: 7.4, h: 1.4, fontFace: B, valign: "top", margin: 0, isTextBox: true });

  const bytes = await pres.write({ outputType: "uint8array" });
  await entregar(bytes, "Reunion_Coordinacion_" + fCorta(reu.semana) + ".pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation");
}

/* ====================== Pantalla completa ====================== */
const hx = (c) => "#" + c;
function Cuadro({ k, list, compact }) {
  const max = compact ? 5 : 7;
  return (
    <View style={{ flex: 1, minHeight: compact ? 0 : 180, backgroundColor: hx(Q[k].tint), borderRadius: 14, padding: 12 }}>
      <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}>
        <View style={{ width: 28, height: 28, borderRadius: 14, backgroundColor: hx(Q[k].c), alignItems: "center", justifyContent: "center", marginRight: 8 }}><Text style={{ color: "#fff", fontWeight: "900" }}>{Q[k].g}</Text></View>
        <Text style={{ flex: 1, color: hx(Q[k].c), fontWeight: "800", fontSize: 13 }}>{Q[k].t.toUpperCase()}</Text>
        <View style={{ backgroundColor: hx(Q[k].c), borderRadius: 12, paddingHorizontal: 10, paddingVertical: 2 }}><Text style={{ color: "#fff", fontWeight: "800" }}>{list.length}</Text></View>
      </View>
      {!list.length ? <Text style={{ color: hx(HX.muted), fontStyle: "italic" }}>{k === "CRI" ? "Sin tareas vencidas" : "Sin registros en Hito"}</Text> : null}
      {list.filter((t) => !t.extra).slice(0, max).concat(list.filter((t) => t.extra)).map((t, i) => t.extra ? (
        <Text key={i} style={{ fontSize: 14, color: hx(Q[k].c), fontWeight: "800", marginBottom: 4 }}>＋ {t.title}<Text style={{ fontSize: 12, fontStyle: "italic", fontWeight: "400", color: hx(HX.muted) }}>{"  agregado por " + t.resp}</Text></Text>
      ) : (
        <Text key={i} style={{ fontSize: 14, color: hx(HX.ink), marginBottom: 4 }}>• {t.title}
          <Text style={{ fontSize: 12, color: hx(HX.muted) }}>{"  " + t.resp + " · " + (t.est === "EJE" ? "lista " + fd(t.doneAt) : fd(t.due)) + (t.est === "DES" || (t.est === "CRI" && t.prog) ? " · " + t.prog + "%" : "")}</Text></Text>
      ))}
      {list.filter((t) => !t.extra).length > max ? <Text style={{ fontSize: 12, fontWeight: "700", fontStyle: "italic", color: hx(Q[k].c) }}>+ {list.filter((t) => !t.extra).length - max} más</Text> : null}
    </View>
  );
}

function armarDiapos(reu, R, estado) {
  if (estado) {
    const out = [{ tipo: "compilado-portada", estado }];
    SECCIONES.forEach(([sec, , areas]) => {
      const incluidas = areas.filter(([, codes]) => (!R.soloAreas || codes.some((c) => R.soloAreas.includes(c))) && codes.some((c) => R.grupo([c])[estado].length));
      if (incluidas.length) out.push({ tipo: "compilado", sec, areas: incluidas, estado });
    });
    return out;
  }
  if (R.soloAreas) {
    const out = [{ tipo: "portada" }];
    SECCIONES.forEach(([, , areas]) => areas.forEach(([nombre, codes]) => { if (codes.some((c) => R.soloAreas.includes(c))) out.push({ tipo: "area", nombre, codes }); }));
    return out;
  }
  const out = [{ tipo: "portada" }, { tipo: "resumen" }];
  if (R.cri.length) out.push({ tipo: "criticos" });
  if (R.saldos.length) out.push({ tipo: "saldos" });
  SECCIONES.forEach(([sec, subt, areas]) => { out.push({ tipo: "seccion", sec, subt }); areas.forEach(([nombre, codes]) => out.push({ tipo: "area", nombre, codes })); });
  out.push({ tipo: "fin" });
  return out;
}

function Diapo({ x, reu, R, w, h }) {
  const wide = w >= 760;
  const Oscura = ({ children }) => <View style={{ flex: 1, backgroundColor: hx(HX.navy), flexDirection: wide ? "row" : "column", alignItems: "center", justifyContent: "center", padding: 24, gap: 24 }}>{children}</View>;
  const escudo = (sz) => <Image source={{ uri: "data:" + ESCUDO_ZB }} style={{ width: sz, height: sz }} resizeMode="contain" />;
  const Marco = ({ titulo, subt, children }) => (
    <ScrollView style={{ flex: 1, backgroundColor: "#fff" }} contentContainerStyle={{ padding: wide ? 28 : 14, paddingBottom: 76, flexGrow: 1 }}>
      <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 4 }}>
        <Text style={{ flex: 1, fontSize: wide ? 30 : 22, fontWeight: "800", color: hx(HX.navy) }}>{titulo}</Text>
        <View style={{ marginRight: 96 }}>{escudo(wide ? 52 : 36)}</View>
      </View>
      {subt ? <Text style={{ color: hx(HX.muted), marginBottom: 12, fontSize: 13 }}>{subt}</Text> : null}
      {children}
    </ScrollView>
  );
  if (x.tipo === "portada" || x.tipo === "fin") return (
    <Oscura>
      <View style={{ flex: wide ? 1 : 0, maxWidth: 620 }}>
        <Text style={{ color: "#fff", fontSize: wide ? 46 : 32, fontWeight: "800" }}>{x.tipo === "fin" ? "Fin de la presentación" : "Reunión de Coordinación"}</Text>
        <Text style={{ color: hx(HX.gold), fontSize: wide ? 26 : 20, fontWeight: "800", marginTop: 10 }}>{x.tipo === "fin" ? "Próxima reunión: " + fLarga(plus(reu.semana, 7)) : fLarga(reu.semana)}</Text>
        <Text style={{ color: "#fff", fontSize: 18, marginTop: 6 }}>Zona de Bienestar “Arica”</Text>
        <Text style={{ color: "#C9D2E3", fontSize: 14, marginTop: 4 }}>{"Foto de Hito del " + fCorta(String(reu.generado_at || "").slice(0, 10))}</Text>
      </View>
      {escudo(wide ? Math.min(h * 0.55, 340) : 180)}
    </Oscura>
  );
  if (x.tipo === "compilado-portada") return (
    <Oscura>
      <View style={{ flex: wide ? 1 : 0, maxWidth: 700 }}>
        <Text style={{ color: "#fff", fontSize: wide ? 42 : 30, fontWeight: "800" }}>Compilado de la Zona</Text>
        <Text style={{ color: hx(Q[x.estado].c), fontSize: 22, fontWeight: "800", marginTop: 10 }}>{Q[x.estado].t.split(" · ")[0]}</Text>
        <Text style={{ color: "#C9D2E3", fontSize: 16, marginTop: 8 }}>Resumen por áreas. Desliza para recorrer los antecedentes de toda la Zona.</Text>
      </View>
      {escudo(wide ? Math.min(h * 0.45, 260) : 150)}
    </Oscura>
  );
  if (x.tipo === "compilado") {
    const areas = x.areas.map(([nombre, codes]) => ({ nombre, tareas: codes.flatMap((c) => R.grupo([c])[x.estado]) })).filter((a) => a.tareas.length);
    const total = areas.reduce((n, a) => n + a.tareas.length, 0);
    return (
      <Marco titulo={"Compilado · " + x.sec} subt={Q[x.estado].t.split(" · ")[0] + " · " + total + " antecedente(s)"}>
        {areas.map((a) => (
          <View key={a.nombre} style={{ marginBottom: 12, borderWidth: 1, borderColor: hx(Q[x.estado].tint), borderRadius: 10, overflow: "hidden" }}>
            <View style={{ flexDirection: "row", alignItems: "center", backgroundColor: hx(Q[x.estado].tint), padding: 9 }}>
              <Text style={{ flex: 1, fontWeight: "800", color: hx(Q[x.estado].c) }}>{a.nombre}</Text>
              <Text style={{ fontWeight: "800", color: hx(Q[x.estado].c) }}>{a.tareas.length}</Text>
            </View>
            {a.tareas.map((t, i) => (
              <View key={i} style={{ paddingHorizontal: 9, paddingVertical: 7, borderTopWidth: 1, borderColor: hx(Q[x.estado].tint), backgroundColor: i % 2 ? "#fff" : "#FAFBFC" }}>
                <Text style={{ fontWeight: "700", color: hx(HX.ink) }}>{t.extra ? "＋ " : "• "}{t.title}</Text>
                <Text style={{ color: hx(HX.muted), fontSize: 12, marginTop: 2 }}>{t.extra ? "Agregado por " + (t.resp || "—") : t.resp + " · " + (t.est === "EJE" ? "lista " + fd(t.doneAt) : "plazo " + fd(t.due)) + ((t.est === "DES" || (t.est === "CRI" && t.prog)) ? " · " + t.prog + "%" : "")}</Text>
              </View>
            ))}
          </View>
        ))}
      </Marco>
    );
  }
  if (x.tipo === "seccion") return (
    <Oscura>
      {escudo(wide ? Math.min(h * 0.45, 260) : 150)}
      <View style={{ flex: wide ? 1 : 0, maxWidth: 700 }}>
        <Text style={{ color: "#fff", fontSize: wide ? 42 : 30, fontWeight: "800" }}>{x.sec}</Text>
        <Text style={{ color: hx(HX.gold), fontSize: 18, marginTop: 8 }}>{x.subt}</Text>
      </View>
    </Oscura>
  );
  if (x.tipo === "resumen") {
    const max = Math.max(1, ...R.porArea.map((o) => KS.reduce((a, k) => a + o[k], 0)));
    return (
      <Marco titulo="Resumen de la semana">
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 14 }}>
          {KS.map((k) => (
            <View key={k} style={{ flexGrow: 1, flexBasis: wide ? 0 : "45%", backgroundColor: hx(Q[k].c), borderRadius: 14, padding: 14 }}>
              <Text style={{ color: "#fff", fontSize: 40, fontWeight: "900" }}>{R.cnt[k]}</Text>
              <Text style={{ color: "#fff", fontWeight: "800" }}>{Q[k].t.split(" · ")[0]}</Text>
            </View>
          ))}
        </View>
        {R.porArea.map((o) => (
          <View key={o.a} style={{ flexDirection: "row", alignItems: "center", marginBottom: 4 }}>
            <Text style={{ width: 48, fontSize: 12, fontWeight: "700", color: hx(HX.ink) }}>{o.a}</Text>
            <View style={{ flex: 1, flexDirection: "row", height: 14 }}>
              {KS.map((k) => (o[k] ? <View key={k} style={{ width: (o[k] / max) * 100 + "%", backgroundColor: hx(Q[k].c) }} /> : null))}
            </View>
            <Text style={{ width: 34, textAlign: "right", fontSize: 12, color: hx(HX.muted) }}>{KS.reduce((a, k) => a + o[k], 0)}</Text>
          </View>
        ))}
      </Marco>
    );
  }
  if (x.tipo === "criticos") return (
    <Marco titulo="Sucesos críticos: tareas vencidas" subt={R.cri.length + " tareas con plazo vencido antes de la reunión"}>
      {R.cri.map((t, i) => (
        <View key={i} style={{ flexDirection: "row", paddingVertical: 7, borderBottomWidth: 1, borderColor: "#F0DDE0", backgroundColor: i % 2 ? "#fff" : "#FBF2F3", paddingHorizontal: 8 }}>
          <Text style={{ width: 52, fontWeight: "800", color: hx(HX.red) }}>{t.area}</Text>
          <Text style={{ flex: 1, color: hx(HX.ink) }}>{t.title}</Text>
          <Text style={{ width: wide ? 160 : 90, color: hx(HX.muted), fontSize: 12 }}>{t.resp}</Text>
          <Text style={{ width: 56, fontWeight: "800", color: hx(HX.ink) }}>{fd(t.due)}</Text>
        </View>
      ))}
    </Marco>
  );
  if (x.tipo === "saldos") {
    const tot = R.saldos.reduce((a, s) => a + Number(s.monto || 0), 0);
    const max = Math.max(1, ...R.saldos.map((s) => Number(s.monto || 0)));
    return (
      <Marco titulo="Saldos disponibles por centro de costo" subt={"Total disponible: " + pesos(tot)}>
        {R.saldos.map((s, i) => (
          <View key={i} style={{ marginBottom: 8 }}>
            <View style={{ flexDirection: "row" }}>
              <Text style={{ flex: 1, fontWeight: "700", color: hx(HX.ink) }}>{s.centro}</Text>
              <Text style={{ fontWeight: "800", color: Number(s.monto) === 0 ? hx(HX.red) : hx(HX.ink) }}>{pesos(s.monto)}</Text>
            </View>
            <View style={{ height: 10, backgroundColor: hx(HX.soft), borderRadius: 5, marginTop: 3 }}>
              <View style={{ height: 10, width: Math.max(1, (Number(s.monto) / max) * 100) + "%", backgroundColor: hx(HX.red), borderRadius: 5 }} />
            </View>
          </View>
        ))}
      </Marco>
    );
  }
  const g = R.grupo(x.codes);
  return (
    <Marco titulo={x.nombre} subt={"Responsables: " + (g.resps.length ? g.resps.slice(0, 6).join(" · ") : "sin tareas asignadas")}>
      <View style={{ flex: 1, gap: 12 }}>
        <View style={{ flexDirection: wide ? "row" : "column", gap: 12, flex: wide ? 1 : 0 }}><Cuadro k="EJE" list={g.EJE} /><Cuadro k="DES" list={g.DES} /></View>
        <View style={{ flexDirection: wide ? "row" : "column", gap: 12, flex: wide ? 1 : 0 }}><Cuadro k="POR" list={g.POR} /><Cuadro k="CRI" list={g.CRI} /></View>
      </View>
    </Marco>
  );
}

export function PantallaCompleta({ reu, aportes, soloAreas, estado, onClose }) {
  const { width: w, height: h } = useWindowDimensions();
  const R = useMemo(() => procesar(reu, aportes, soloAreas), [reu, aportes, soloAreas]);
  const diapos = useMemo(() => armarDiapos(reu, R, estado), [reu, R, estado]);
  const [i, setI] = useState(0);
  const toque = useRef(null);
  const ir = useCallback((n) => setI((x) => Math.max(0, Math.min(diapos.length - 1, x + n))), [diapos.length]);
  const iniciarToque = (e) => { const t = e.nativeEvent.touches && e.nativeEvent.touches[0]; if (t) toque.current = { x: t.pageX, y: t.pageY }; };
  const terminarToque = (e) => {
    const t = e.nativeEvent.changedTouches && e.nativeEvent.changedTouches[0];
    const ini = toque.current; toque.current = null;
    if (!t || !ini) return;
    const dx = t.pageX - ini.x, dy = t.pageY - ini.y;
    if (Math.abs(dx) > 55 && Math.abs(dx) > Math.abs(dy) * 1.25) ir(dx < 0 ? 1 : -1);
  };
  const cerrar = () => { if (Platform.OS === "web") { try { if (document.fullscreenElement) document.exitFullscreen(); } catch (e) {} } onClose(); };
  useEffect(() => {
    if (Platform.OS !== "web") return;
    try { const el = document.documentElement; if (el.requestFullscreen && !document.fullscreenElement) el.requestFullscreen().catch(() => {}); } catch (e) {}
    const k = (e) => { if (e.key === "ArrowRight" || e.key === "PageDown" || e.key === " ") ir(1); if (e.key === "ArrowLeft" || e.key === "PageUp") ir(-1); if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", k);
    const fs = () => { if (!document.fullscreenElement) {} };
    document.addEventListener("fullscreenchange", fs);
    return () => { window.removeEventListener("keydown", k); document.removeEventListener("fullscreenchange", fs); };
  }, [ir, onClose]);
  const btn = { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 999, backgroundColor: "rgba(20,33,61,0.85)" };
  return (
    <Modal visible animationType="fade" presentationStyle="fullScreen" statusBarTranslucent supportedOrientations={["portrait", "landscape", "landscape-left", "landscape-right"]} onRequestClose={cerrar}>
      <View onTouchStart={iniciarToque} onTouchEnd={terminarToque} style={{ flex: 1, backgroundColor: "#000" }}>
        <Diapo x={diapos[i]} reu={reu} R={R} w={w} h={h} />
        <View pointerEvents="box-none" style={{ position: "absolute", left: 0, right: 0, bottom: 14, flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 10 }}>
          <Pressable accessibilityLabel="Anterior" onPress={() => ir(-1)} style={btn}><Text style={{ color: "#fff", fontSize: 18, fontWeight: "800" }}>‹</Text></Pressable>
          <View style={btn}><Text style={{ color: "#fff", fontWeight: "700" }}>{i + 1} / {diapos.length}</Text></View>
          <Pressable accessibilityLabel="Siguiente" onPress={() => ir(1)} style={btn}><Text style={{ color: "#fff", fontSize: 18, fontWeight: "800" }}>›</Text></Pressable>
        </View>
        <Pressable accessibilityLabel="Cerrar pantalla completa" onPress={cerrar} style={[btn, { position: "absolute", top: Platform.OS === "web" ? 14 : 40, right: 14 }]}><Text style={{ color: "#fff", fontWeight: "800" }}>✕ Salir</Text></Pressable>
      </View>
    </Modal>
  );
}

/* ====================== Pestaña ====================== */
const NOMBRE_AREA = Object.fromEntries(SECCIONES.flatMap(([, , areas]) => areas.flatMap(([n, codes]) => codes.map((c) => [c, codes.length > 1 ? n + " (" + c + ")" : n]))));
const SUPERVISORES = ["m-passalacqua", "m-azocar", "m-urquieta"];

export function ReunionSemanal({ d }) {
  const me = d.me || {};
  const admin = me.role === "admin";
  const veTodo = admin || SUPERVISORES.includes(me.id);
  const [lista, setLista] = useState(null);
  const [sel, setSel] = useState(null);
  const [full, setFull] = useState(false);
  const [estadoFull, setEstadoFull] = useState(null);
  const [busy, setBusy] = useState("");
  const [misAreas, setMisAreas] = useState([]);
  const [aportes, setAportes] = useState([]);
  const [fArea, setFArea] = useState(null);
  const [fCuad, setFCuad] = useState("POR");
  const [fTexto, setFTexto] = useState("");
  const nombre = (id) => corto((d.members.find((m) => m.id === id) || {}).name);
  const cargar = useCallback(async () => {
    const [r, a] = await Promise.all([
      supabase.from("reuniones").select("*").order("semana", { ascending: false }).limit(26),
      supabase.rpc("mis_areas_aporte"),
    ]);
    const data = (r && !r.error && r.data) || [];
    setLista(data); setSel((s) => (s && data.find((x) => x.semana === s.semana)) || data[0] || null);
    const ma = (a && !a.error && a.data) || []; setMisAreas(ma); setFArea((x) => x || ma[0] || null);
  }, []);
  const cargarAportes = useCallback(async (semana) => {
    if (!semana) return setAportes([]);
    const { data } = await supabase.from("reunion_aportes").select("*").eq("semana", semana).order("created_at");
    setAportes(data || []);
  }, []);
  useEffect(() => { cargar(); }, [cargar]);
  useEffect(() => { cargarAportes(sel && sel.semana); }, [sel, cargarAportes]);
  const aportesN = useMemo(() => aportes.map((x) => ({ ...x, autorNombre: nombre(x.autor) })), [aportes, d.members]);
  const soloAreas = veTodo ? null : misAreas;
  const R = useMemo(() => (sel ? procesar(sel, aportesN, soloAreas) : null), [sel, aportesN, soloAreas]);

  async function actualizar() {
    setBusy("act");
    const { error } = await supabase.rpc("generar_reunion");
    setBusy("");
    if (error) return Alert.alert("No se pudo actualizar", error.message);
    await cargar();
  }
  async function ppt() {
    setBusy("ppt");
    try { await descargarPpt(sel, aportesN); } catch (e) { Alert.alert("No se pudo descargar", String((e && e.message) || e)); }
    setBusy("");
  }
  async function agregar() {
    const texto = fTexto.trim();
    if (!texto || !fArea || !sel) return;
    setBusy("add");
    const { error } = await supabase.from("reunion_aportes").insert({ semana: sel.semana, area: fArea, cuadrante: fCuad, texto, autor: me.id });
    setBusy("");
    if (error) return Alert.alert("No se pudo agregar", error.message);
    setFTexto(""); cargarAportes(sel.semana);
  }
  async function quitar(x) {
    const { error } = await supabase.from("reunion_aportes").delete().eq("id", x.id);
    if (error) return Alert.alert("No se pudo quitar", error.message);
    cargarAportes(sel.semana);
  }

  if (lista === null) return <Note kind="info" text="Cargando reuniones…" />;
  if (!veTodo && !misAreas.length) return <Note kind="info" text="La Reunión de Coordinación la ven el Comandante, el Jefe Administrativo, la Plana Mayor y los jefes de área." />;
  const misAportes = aportesN.filter((x) => admin || x.autor === me.id);
  return (
    <View style={{ gap: 10 }}>
      <Note kind="info" text={"Cada jueves a las 17:00 Hito guarda la foto de las tareas para la Reunión de Coordinación del viernes; queda una presentación por semana." + (misAreas.length ? " Puedes agregar puntos a tu área: se suman a lo que viene de Hito, sin quitar nada." : "")} />
      {!lista.length ? <Note kind="warn" text="Aún no hay reuniones guardadas." /> : null}
      {lista.length ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {lista.map((r) => <Chip key={r.semana} label={"Reunión " + fCorta(r.semana)} on={sel && sel.semana === r.semana} onPress={() => setSel(r)} />)}
        </ScrollView>
      ) : null}
      {sel && R ? (
        <Card>
          <Text style={{ fontSize: 18, fontWeight: "800", color: C.ink }}>Reunión de Coordinación · {fLarga(sel.semana)}</Text>
          <Text style={{ color: C.muted, fontSize: 12, marginBottom: 8 }}>Foto del {new Date(sel.generado_at).toLocaleString("es-CL")} · {sel.generado_por}{aportes.length ? " · " + aportes.length + " punto(s) agregado(s)" : ""}</Text>
          {veTodo ? (
            <Row style={{ flexWrap: "wrap", gap: 6, marginBottom: 10 }}>
              {KS.map((k) => (
                <Pressable key={k} accessibilityRole="button" accessibilityLabel={"Ver compilado de la Zona: " + Q[k].t.split(" · ")[0]} onPress={() => { setEstadoFull(k); setFull(true); }} style={{ flexGrow: 1, minWidth: 70, backgroundColor: hx(Q[k].c), borderRadius: 10, padding: 8, alignItems: "center" }}>
                  <Text style={{ color: "#fff", fontSize: 22, fontWeight: "900" }}>{R.cnt[k]}</Text>
                  <Text style={{ color: "#fff", fontSize: 11, fontWeight: "700", textAlign: "center" }}>{Q[k].t.split(" · ")[0].replace("Tareas ", "")}</Text>
                  <Text style={{ color: "#fff", fontSize: 10, fontWeight: "700", textAlign: "center", marginTop: 2 }}>Toca para ver Zona</Text>
                </Pressable>
              ))}
            </Row>
          ) : null}
          <View style={{ gap: 8 }}>
            <Btn title="⛶  Ver pantalla completa" kind="dark" onPress={() => { setEstadoFull(null); setFull(true); }} />
            {veTodo ? <Btn title={busy === "ppt" ? "Armando PowerPoint…" : "Descargar PowerPoint"} kind="primary" disabled={!!busy} onPress={ppt} /> : null}
            {admin ? <Btn title={busy === "act" ? "Actualizando…" : "Actualizar ahora con las tareas de hoy"} disabled={!!busy} onPress={actualizar} /> : null}
          </View>
        </Card>
      ) : null}
      {sel && misAreas.length ? (
        <Card>
          <Text style={{ fontSize: 16, fontWeight: "800", color: C.ink, marginBottom: 6 }}>Agregar un punto a la reunión</Text>
          {misAreas.length > 1 ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 4 }}>
              {misAreas.map((a) => <Chip key={a} label={NOMBRE_AREA[a] || a} on={fArea === a} onPress={() => setFArea(a)} />)}
            </ScrollView>
          ) : <Text style={{ color: C.muted, marginBottom: 6 }}>{NOMBRE_AREA[fArea] || fArea}</Text>}
          <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
            {KS.map((k) => <Chip key={k} label={Q[k].t.split(" · ")[0].replace("Tareas ", "").replace(/^./, (m) => m.toUpperCase())} color={hx(Q[k].c)} on={fCuad === k} onPress={() => setFCuad(k)} />)}
          </View>
          <TextInput value={fTexto} onChangeText={setFTexto} placeholder="Ej.: Se recibió la boleta de garantía del empalme" multiline
            style={{ minHeight: 70, borderWidth: 1, borderColor: C.line2, borderRadius: 12, padding: 10, fontSize: 15, color: C.ink, backgroundColor: C.surface, textAlignVertical: "top", marginBottom: 8 }} />
          <Btn title={busy === "add" ? "Agregando…" : "＋ Agregar a la reunión"} kind="primary" disabled={!!busy || !fTexto.trim()} onPress={agregar} />
          {misAportes.length ? <Text style={{ fontWeight: "700", color: C.ink2, marginTop: 12, marginBottom: 4 }}>Puntos agregados esta semana</Text> : null}
          {misAportes.map((x) => (
            <View key={x.id} style={{ flexDirection: "row", alignItems: "center", paddingVertical: 6, borderTopWidth: 1, borderColor: C.line }}>
              <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: hx(Q[x.cuadrante].c), marginRight: 8 }} />
              <Text style={{ flex: 1, color: C.ink }}>{x.texto}<Text style={{ color: C.muted, fontSize: 12 }}>{"  " + (NOMBRE_AREA[x.area] || x.area) + " · " + x.autorNombre}</Text></Text>
              <Pressable onPress={() => quitar(x)} style={{ padding: 6 }}><Text style={{ color: C.red, fontWeight: "700" }}>Quitar</Text></Pressable>
            </View>
          ))}
        </Card>
      ) : null}
      {full && sel ? <PantallaCompleta reu={sel} aportes={aportesN} soloAreas={soloAreas} estado={estadoFull} onClose={() => setFull(false)} /> : null}
    </View>
  );
}
