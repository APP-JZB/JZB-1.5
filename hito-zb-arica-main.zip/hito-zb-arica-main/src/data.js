import { useEffect, useRef, useState, useCallback } from "react";
import { supabase, rank } from "./lib";
import { diffAlerts, reschedule } from "./notify";
import { generarPeriodicas } from "./control";
import { Platform } from "react-native";
let bg = null; if (Platform.OS !== "web") { try { bg = require("./background"); } catch (e) {} }

// Carga todo lo que la persona puede ver (las reglas RLS filtran por rol) y se mantiene al día en tiempo real.
export function useData(session) {
  const [d, setD] = useState({ members: [], tasks: [], prorrogas: [], events: [], posts: [], parte: [], novedades: [], actividades: [], riesgos: [], avisos: [], config: {}, me: null, loaded: false, error: "" });
  const timer = useRef(null);
  const prev = useRef(null);

  const load = useCallback(async () => {
    if (!session) return;
    try {
      const [m, t, p, e, po, c, pc, pf, nv, ac, ri, cat, av, so] = await Promise.all([
        supabase.from("members").select("*"),
        supabase.from("tasks").select("*").order("due"),
        supabase.from("prorrogas").select("*").order("created_at", { ascending: false }),
        supabase.from("events").select("*").order("at"),
        supabase.from("posts").select("*").order("created_at", { ascending: false }),
        supabase.from("config").select("*"),
        supabase.from("position_profiles").select("*").order("cargo"),
        supabase.from("parte_fuerza").select("*").gte("fecha", new Date(Date.now() - 75 * 864e5).toISOString().slice(0, 10)),
        supabase.from("novedades").select("*").gte("hasta", new Date(Date.now() - 75 * 864e5).toISOString().slice(0, 10)).order("desde"),
        supabase.from("actividades").select("*").order("codigo"),
        supabase.from("riesgos").select("*").order("created_at"),
        supabase.from("cc_catalogo").select("*"),
        supabase.from("avisos_admin").select("*").gte("created_at", new Date(Date.now() - 30 * 864e5).toISOString()).order("created_at", { ascending: false }),
        supabase.from("solicitudes").select("*").gte("created_at", new Date(Date.now() - 30 * 864e5).toISOString()).order("created_at", { ascending: false }),
      ]);
      const err = [m, t, p, e, po, c].find((r) => r.error);
      if (err) throw err.error;
      const members = (m.data || []).sort((a, b) => (a.unit_order - b.unit_order) || (rank(a) - rank(b)) || a.name.localeCompare(b.name));
      const config = {}; (c.data || []).forEach((r) => (config[r.key] = r.value));
      const me = members.find((x) => x.user_id === session.user.id) || null;
      const nd = { members, profiles: (pc && !pc.error && pc.data) || [], tasks: t.data || [], prorrogas: p.data || [], events: e.data || [], posts: po.data || [], parte: (pf && !pf.error && pf.data) || [], novedades: (nv && !nv.error && nv.data) || [], actividades: (ac && !ac.error && ac.data) || [], riesgos: (ri && !ri.error && ri.data) || [], avisos: (av && !av.error && av.data) || [], catalogo: (cat && !cat.error && cat.data) || [], solicitudes: (so && !so.error && so.data) || [], config, me, loaded: true, error: "" };
      diffAlerts(prev.current, nd); prev.current = nd;
      setD(nd);
      reschedule(nd);
      generarPeriodicas(nd);
      if (bg) { bg.guardarSnapshot(nd); bg.registrarFondo(); }
    } catch (e) {
      setD((x) => ({ ...x, loaded: true, error: "No se pudo cargar la información. Revisa tu conexión." }));
    }
  }, [session]);

  useEffect(() => {
    if (!session) return;
    load();
    const ch = supabase.channel("hito")
      .on("postgres_changes", { event: "*", schema: "public" }, () => { clearTimeout(timer.current); timer.current = setTimeout(load, 400); })
      .subscribe();
    const iv = setInterval(load, 60000);
    return () => { supabase.removeChannel(ch); clearInterval(iv); clearTimeout(timer.current); };
  }, [session, load]);

  return [d, load];
}
