-- Reunión de Coordinación semanal: cada jueves a las 17:00 (hora de Chile) se guarda una foto de las tareas
-- de la semana. La app arma con ella la presentación PPT. Una fila por semana (fecha de la reunión, viernes).
create table if not exists public.reuniones (
  semana date primary key,
  generado_at timestamptz not null default now(),
  generado_por text,
  datos jsonb not null default '[]'::jsonb
);
alter table public.reuniones enable row level security;
drop policy if exists reuniones_read on public.reuniones;
create policy reuniones_read on public.reuniones for select to authenticated using (public.is_admin() or public.es_supervisor());
grant select on public.reuniones to authenticated;

create or replace function public.area_de_unidad(u text) returns text language sql immutable as $$
  select case u
    when 'Comando ZB Arica' then 'CDO' when 'Jefatura Administrativa' then 'CDO' when 'Registratura' then 'CDO'
    when 'Oficina de Planificación' then 'PLAN' when 'Oficina Control de Gestión y Riesgo' then 'OCGR'
    when 'Asesoría Jurídica' then 'AJ' when 'Oficina de Personal' then 'PER' when 'Oficina de Finanzas' then 'FIN'
    when 'Oficina de Seguridad' then 'SEG' when 'SICE' then 'SEG' when 'Centro de Gestión de Adquisiciones' then 'CGA'
    when 'Inspección Técnica de Obras (ITO)' then 'ITO' when 'Oficina de Coordinación Logística' then 'LOG'
    when 'Sección Mantenimiento de Infraestructura (Sección de Apoyo)' then 'MANT' when 'Sección Habitacional' then 'VF'
    when 'Sección Habitabilidad' then 'HAB' when 'Sección Recreacional' then 'REC' when 'Centro Recreacional Arica' then 'CRA'
    when 'Club de Oficiales El Morro' then 'COEM' when 'Jardín Infantil Soldadito de Plomo' then 'JI'
    when 'Sección Asistencial' then 'ASI' when 'Área Convenios' then 'ASI' else 'CDO' end
$$;

-- Genera (o actualiza) la foto de la semana. La reunión es el viernes siguiente (o el mismo viernes).
create or replace function public.generar_reunion() returns date
language plpgsql security definer set search_path = public as $$
declare
  hoy date := (now() at time zone 'America/Santiago')::date;
  reu date := hoy + ((5 - extract(isodow from hoy)::int + 7) % 7);
  quien text := public.my_member_id();
begin
  if auth.uid() is not null and not public.is_admin() then
    raise exception 'Solo el Comandante puede generar la reunión';
  end if;
  insert into public.reuniones (semana, generado_at, generado_por, datos)
  select reu, now(), coalesce(quien, 'automático (jueves 17:00)'), coalesce(json_agg(json_build_object(
      'area', coalesce(t.area, public.area_de_unidad(coalesce(m.parte_unit, m.unit))),
      'titulo', t.title,
      'resp', coalesce(m.name, ''),
      'plazo', to_char(t.due at time zone 'America/Santiago', 'YYYY-MM-DD'),
      'hecha', t.done,
      'hecha_el', to_char(t.done_at at time zone 'America/Santiago', 'YYYY-MM-DD'),
      'avance', t.progress
    ) order by t.due)::jsonb, '[]'::jsonb)
  from public.tasks t left join public.members m on m.id = t.member_id
  where (t.done and t.done_at > now() - interval '7 days')
     or (not t.done and t.due < (reu + 21)::timestamp at time zone 'America/Santiago')
  on conflict (semana) do update set generado_at = excluded.generado_at, generado_por = excluded.generado_por, datos = excluded.datos;
  return reu;
end $$;
revoke all on function public.generar_reunion() from public, anon;
grant execute on function public.generar_reunion() to authenticated;

-- Llamada del programador: corre a las 20:00 y 21:00 UTC de cada jueves y solo actúa cuando en Chile son las 17:00
-- (así funciona con horario de verano e invierno).
create or replace function public.generar_reunion_programada() returns void
language plpgsql security definer set search_path = public as $$
begin
  if extract(hour from now() at time zone 'America/Santiago') = 17 then perform public.generar_reunion(); end if;
end $$;
revoke all on function public.generar_reunion_programada() from public, anon, authenticated;

create extension if not exists pg_cron;
select cron.unschedule(jobid) from cron.job where jobname = 'reunion-semanal';
select cron.schedule('reunion-semanal', '0 20,21 * * 4', 'select public.generar_reunion_programada()');

-- Primera foto (semana en curso)
select public.generar_reunion() as semana, (select jsonb_array_length(datos) from public.reuniones order by semana desc limit 1) as tareas,
       (select schedule from cron.job where jobname = 'reunion-semanal') as programacion;
