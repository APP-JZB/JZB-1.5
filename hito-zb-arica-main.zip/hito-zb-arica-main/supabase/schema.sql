-- Hito ZB Arica · versión 2 · esquema de base de datos (Supabase / PostgreSQL)
-- Ejecutar completo en: Supabase → SQL Editor → New query → Run.

create extension if not exists pgcrypto;

-- ============ Configuración ============
create table if not exists public.config (
  key text primary key,
  value jsonb not null default '{}'::jsonb
);

-- ============ Integrantes (encuadramiento) ============
create table if not exists public.members (
  id text primary key,
  name text not null,
  grado text default '',
  cargo text default '',
  unit text default '',
  unit_order int default 99,
  nivel text default 'X',
  phone text default '',
  phone_digits text generated always as (regexp_replace(coalesce(phone,''), '\D', '', 'g')) stored,
  reemplazo text default '',
  reemplazo_id text references public.members(id) on delete set null,
  wa_name text default '',
  role text not null default 'member' check (role in ('member','admin')),
  user_id uuid unique references auth.users(id) on delete set null,
  created_at timestamptz default now()
);
create index if not exists members_phone_idx on public.members(phone_digits);

-- ============ Tareas ============
create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  tf text not null,
  proc text default '',
  member_id text references public.members(id) on delete set null,
  due timestamptz not null,
  stages jsonb not null default '[]'::jsonb,
  progress int not null default 0,
  done boolean not null default false,
  done_at timestamptz,
  late boolean not null default false,
  no_shows int not null default 0,
  overdue_ack_at timestamptz,
  log jsonb not null default '[]'::jsonb,
  created_at timestamptz default now()
);
create index if not exists tasks_member_idx on public.tasks(member_id);
create index if not exists tasks_due_idx on public.tasks(due);

-- ============ Solicitudes de prórroga ============
create table if not exists public.prorrogas (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  member_id text references public.members(id) on delete set null,
  requested_due timestamptz not null,
  motivo text default '',
  argumento text default '',
  status text not null default 'pendiente' check (status in ('pendiente','aprobada','otra fecha','rechazada')),
  decided_due timestamptz,
  comment text default '',
  created_at timestamptz default now(),
  decided_at timestamptz
);

-- ============ Eventos del calendario ============
create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  type text default 'Novedad',
  at timestamptz not null,
  detail text default '',
  by_member text references public.members(id) on delete set null,
  created_at timestamptz default now()
);

-- ============ Diario mural ============
create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text default '',
  cat text default 'avisos',
  pinned boolean default false,
  created_at timestamptz default now()
);

-- ============ Funciones de identidad ============
create or replace function public.my_member_id() returns text
language sql stable security definer set search_path = public as $$
  select id from public.members where user_id = auth.uid() limit 1
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.members where user_id = auth.uid() and role = 'admin')
$$;

-- Vincular la cuenta recién creada con su ficha del encuadramiento.
-- Integrantes: correo técnico <digitos>@hito.app (lo genera la app a partir del teléfono).
-- Administrador: el correo guardado en config 'admin_email'.
create or replace function public.link_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  digits text;
  admin_mail text;
  mid text;
begin
  select value->>'email' into admin_mail from public.config where key = 'admin_email';
  if admin_mail is not null and lower(new.email) = lower(admin_mail) then
    update public.members set user_id = new.id, role = 'admin' where id = (select value->>'member_id' from public.config where key = 'admin_email');
    return new;
  end if;
  if new.email like '%@hito.app' then
    digits := split_part(new.email, '@', 1);
    select id into mid from public.members
      where phone_digits = digits and user_id is null
      limit 1;
    if mid is null then
      raise exception 'Ese número no está registrado en el equipo de la Zona o ya tiene acceso.';
    end if;
    update public.members set user_id = new.id where id = mid;
    return new;
  end if;
  raise exception 'Acceso no autorizado.';
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.link_new_user();

-- Un integrante solo puede cambiar avance, etapas, cumplimiento y acuse de vencida de SUS tareas.
create or replace function public.guard_task_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() then return new; end if;
  new.title := old.title; new.tf := old.tf; new.proc := old.proc; new.member_id := old.member_id;
  new.due := old.due; new.late := old.late; new.no_shows := old.no_shows; new.created_at := old.created_at;
  if old.done = false and new.done = true then new.done_at := now(); end if;
  if new.done = false then new.done_at := null; end if;
  return new;
end $$;
drop trigger if exists tasks_guard on public.tasks;
create trigger tasks_guard before update on public.tasks for each row execute function public.guard_task_update();

-- La prórroga solo se pide antes del vencimiento; vencida = citación presencial.
create or replace function public.guard_prorroga() returns trigger
language plpgsql security definer set search_path = public as $$
declare t public.tasks;
begin
  select * into t from public.tasks where id = new.task_id;
  if not public.is_admin() then
    if t.member_id is distinct from public.my_member_id() then raise exception 'La tarea no es tuya.'; end if;
    if t.due < now() then raise exception 'La tarea ya venció: debes presentarte en la oficina del Comandante.'; end if;
    new.member_id := t.member_id; new.status := 'pendiente'; new.decided_due := null; new.decided_at := null;
  end if;
  return new;
end $$;
drop trigger if exists prorrogas_guard on public.prorrogas;
create trigger prorrogas_guard before insert on public.prorrogas for each row execute function public.guard_prorroga();

-- ============ Seguridad por filas (RLS) ============
alter table public.config enable row level security;
alter table public.members enable row level security;
alter table public.tasks enable row level security;
alter table public.prorrogas enable row level security;
alter table public.events enable row level security;
alter table public.posts enable row level security;

drop policy if exists config_read on public.config;
create policy config_read on public.config for select to authenticated using (key <> 'admin_email' or public.is_admin());
drop policy if exists config_write on public.config;
create policy config_write on public.config for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists members_read on public.members;
create policy members_read on public.members for select to authenticated using (true);
drop policy if exists members_write on public.members;
create policy members_write on public.members for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists tasks_read on public.tasks;
create policy tasks_read on public.tasks for select to authenticated using (public.is_admin() or member_id = public.my_member_id());
drop policy if exists tasks_insert on public.tasks;
create policy tasks_insert on public.tasks for insert to authenticated with check (public.is_admin());
drop policy if exists tasks_update on public.tasks;
create policy tasks_update on public.tasks for update to authenticated using (public.is_admin() or member_id = public.my_member_id());
drop policy if exists tasks_delete on public.tasks;
create policy tasks_delete on public.tasks for delete to authenticated using (public.is_admin());

drop policy if exists prorrogas_read on public.prorrogas;
create policy prorrogas_read on public.prorrogas for select to authenticated using (public.is_admin() or member_id = public.my_member_id());
drop policy if exists prorrogas_insert on public.prorrogas;
create policy prorrogas_insert on public.prorrogas for insert to authenticated with check (true);
drop policy if exists prorrogas_update on public.prorrogas;
create policy prorrogas_update on public.prorrogas for update to authenticated using (public.is_admin());

drop policy if exists events_read on public.events;
create policy events_read on public.events for select to authenticated using (true);
drop policy if exists events_insert on public.events;
create policy events_insert on public.events for insert to authenticated with check (public.is_admin() or by_member = public.my_member_id());
drop policy if exists events_delete on public.events;
create policy events_delete on public.events for delete to authenticated using (public.is_admin() or by_member = public.my_member_id());

drop policy if exists posts_read on public.posts;
create policy posts_read on public.posts for select to authenticated using (true);
drop policy if exists posts_write on public.posts;
create policy posts_write on public.posts for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Tiempo real para que los cambios lleguen al instante a todos los teléfonos.
do $$ begin
  begin alter publication supabase_realtime add table public.tasks; exception when others then null; end;
  begin alter publication supabase_realtime add table public.prorrogas; exception when others then null; end;
  begin alter publication supabase_realtime add table public.events; exception when others then null; end;
  begin alter publication supabase_realtime add table public.posts; exception when others then null; end;
  begin alter publication supabase_realtime add table public.members; exception when others then null; end;
end $$;

-- Permisos de la API (por si el proyecto no expone tablas nuevas automáticamente).
grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant execute on function public.my_member_id(), public.is_admin() to authenticated;
