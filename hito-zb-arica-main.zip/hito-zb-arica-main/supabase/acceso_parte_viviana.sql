-- Hito ZB Arica · acceso delegado de Viviana Urrutia a Parte y consulta de Equipo
-- Ejecutar en Supabase SQL Editor antes de usar las nuevas pestañas.
-- El acceso se vincula a la ficha m-viviana-urrutia-salinas autenticada, no a un nombre visible.

create or replace function public.can_manage_part() returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_admin()
      or public.my_member_id() = 'm-viviana-urrutia-salinas'
$$;

grant execute on function public.can_manage_part() to authenticated;

-- Parte diario: lectura y escritura para administración y la cuenta autorizada.
drop policy if exists parte_staff_manage on public.parte_fuerza;
create policy parte_staff_manage on public.parte_fuerza
  for all to authenticated
  using (public.can_manage_part())
  with check (public.can_manage_part());

-- Novedades: la cuenta autorizada puede registrar y corregir novedades del parte.
drop policy if exists novedades_staff_manage on public.novedades;
create policy novedades_staff_manage on public.novedades
  for all to authenticated
  using (public.can_manage_part())
  with check (public.can_manage_part());

-- Solo permite cambiar la configuración de columnas del parte.
drop policy if exists config_parte_staff_insert on public.config;
create policy config_parte_staff_insert on public.config
  for insert to authenticated
  with check (key = 'parte_cols' and public.can_manage_part());

drop policy if exists config_parte_staff_update on public.config;
create policy config_parte_staff_update on public.config
  for update to authenticated
  using (key = 'parte_cols' and public.can_manage_part())
  with check (key = 'parte_cols' and public.can_manage_part());

-- La administración del parte puede agregar personas y modificar solo los campos
-- de incorporación/permanencia en el parte. El resto de los datos de integrantes
-- queda protegido incluso si se invoca la API directamente.
drop policy if exists members_part_staff_insert on public.members;
create policy members_part_staff_insert on public.members
  for insert to authenticated
  with check (public.can_manage_part());

drop policy if exists members_part_staff_update on public.members;
create policy members_part_staff_update on public.members
  for update to authenticated
  using (public.can_manage_part())
  with check (public.can_manage_part());

create or replace function public.guard_part_staff_member_changes() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() then
    return new;
  end if;

  if public.my_member_id() <> 'm-viviana-urrutia-salinas' then
    raise exception 'No autorizado para administrar el parte.';
  end if;

  if tg_op = 'UPDATE' then
    if (to_jsonb(new) - array['parte','parte_unit','parte_desde','parte_hasta','salida_motivo'])
       is distinct from
       (to_jsonb(old) - array['parte','parte_unit','parte_desde','parte_hasta','salida_motivo']) then
      raise exception 'Solo se pueden modificar campos de incorporación y permanencia en el parte.';
    end if;
  elsif tg_op = 'INSERT' then
    if new.role <> 'member' or new.user_id is not null or new.email is not null then
      raise exception 'No se permite crear cuentas ni asignar roles desde el parte.';
    end if;
  end if;
  return new;
end $$;

drop trigger if exists members_part_staff_guard on public.members;
create trigger members_part_staff_guard
  before insert or update on public.members
  for each row execute function public.guard_part_staff_member_changes();

select 'Acceso de Parte habilitado para la ficha autorizada' as estado;
