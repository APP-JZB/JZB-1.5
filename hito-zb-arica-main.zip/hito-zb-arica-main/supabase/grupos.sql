alter table public.tasks add column if not exists grupo text;
alter table public.tasks add column if not exists grupo_label text;
create index if not exists tasks_grupo_idx on public.tasks(grupo);
