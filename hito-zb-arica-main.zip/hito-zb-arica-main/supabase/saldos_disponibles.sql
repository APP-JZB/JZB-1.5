-- Saldo disponible por centro de costo.
-- El Oficial de Finanzas y el Comandante pueden registrar saldos.
-- Ejecutar en Supabase → SQL Editor → New query → Run.

create or replace function public.actualizar_saldo_disponible(
  p_cc_key text,
  p_monto numeric
) returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_member public.members%rowtype;
  v_cc_exists boolean;
begin
  select * into v_member
  from public.members
  where user_id = auth.uid()
  limit 1;

  if not found then
    raise exception 'No se encontró el integrante asociado a esta sesión.';
  end if;

  if v_member.role <> 'admin'
     and lower(trim(coalesce(v_member.cargo, ''))) <> 'oficial de finanzas' then
    raise exception 'Solo el Oficial de Finanzas o el Comandante puede actualizar saldos.';
  end if;

  if p_monto is null or p_monto < 0 or p_monto <> trunc(p_monto) then
    raise exception 'El saldo debe ser un monto entero igual o mayor que cero.';
  end if;

  select exists (
    select 1
    from public.config cfg
    cross join lateral jsonb_array_elements(coalesce(cfg.value->'cc', '[]'::jsonb)) as items(cc)
    where cfg.key = 'zona'
      and ((items.cc->>'codigo') || '|' || (items.cc->>'centro')) = p_cc_key
  ) into v_cc_exists;

  if not v_cc_exists then
    raise exception 'El centro de costo indicado no existe.';
  end if;

  insert into public.config as cfg (key, value)
  values (
    'saldos_disponibles',
    jsonb_build_object(
      p_cc_key,
      jsonb_build_object(
        'monto', p_monto,
        'actualizado_en', now(),
        'actualizado_por', v_member.id
      )
    )
  )
  on conflict (key) do update
    set value = cfg.value || excluded.value;
end;
$$;

revoke all on function public.actualizar_saldo_disponible(text, numeric) from public;
grant execute on function public.actualizar_saldo_disponible(text, numeric) to authenticated;
