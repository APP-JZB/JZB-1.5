-- Aviso al Comandante cuando un integrante cambia o elimina una tarea sin su autorización (desde la app o la IA)
create table if not exists public.avisos_admin (
  id uuid primary key default gen_random_uuid(),
  task_id uuid,
  actor text references public.members(id) on delete set null,
  titulo text not null,
  detalle text default '',
  revisado boolean not null default false,
  created_at timestamptz default now()
);
alter table public.avisos_admin enable row level security;
drop policy if exists avisos_admin_all on public.avisos_admin;
create policy avisos_admin_all on public.avisos_admin for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select, update, delete on public.avisos_admin to authenticated;
do $$ begin begin alter publication supabase_realtime add table public.avisos_admin; exception when others then null; end; end $$;

create or replace function public.aviso_cambio_tarea() returns trigger
language plpgsql security definer set search_path = public as $$
declare c text[] := '{}'; f text := 'DD-MM-YYYY HH24:MI'; nm text;
begin
  if auth.uid() is null or public.is_admin() then return coalesce(new, old); end if;
  if tg_op = 'DELETE' then
    insert into public.avisos_admin (task_id, actor, titulo, detalle) values (old.id, public.my_member_id(), old.title, 'Eliminó la tarea');
    return old;
  end if;
  if new.title is distinct from old.title then c := c || ('Título: "' || coalesce(old.title,'') || '" → "' || coalesce(new.title,'') || '"'); end if;
  if new.due is distinct from old.due then c := c || ('Plazo: ' || to_char(old.due at time zone 'America/Santiago', f) || ' → ' || to_char(new.due at time zone 'America/Santiago', f)); end if;
  if new.member_id is distinct from old.member_id then
    select name into nm from public.members where id = new.member_id;
    c := c || ('Responsable cambiado a ' || coalesce(nm, '—')); end if;
  if new.apoyo is distinct from old.apoyo then
    select name into nm from public.members where id = new.apoyo;
    c := c || ('Responsable secundario: ' || coalesce(nm, 'quitado')); end if;
  if new.participantes is distinct from old.participantes then c := c || 'Cambió participantes'::text; end if;
  if new.area is distinct from old.area or new.proc is distinct from old.proc then c := c || 'Cambió área o proceso'::text; end if;
  if coalesce(new.evidencia,'') is distinct from coalesce(old.evidencia,'') then c := c || 'Cambió producto / evidencia'::text; end if;
  if array_length(c, 1) > 0 then
    insert into public.avisos_admin (task_id, actor, titulo, detalle) values (new.id, public.my_member_id(), new.title, array_to_string(c, ' · '));
  end if;
  return new;
exception when others then
  return coalesce(new, old); -- el aviso nunca debe impedir guardar
end $$;

drop trigger if exists tasks_aviso_cambio on public.tasks;
create trigger tasks_aviso_cambio after update or delete on public.tasks
  for each row execute function public.aviso_cambio_tarea();
select 'ok' estado;
