-- Eventos editables con responsable
alter table public.events add column if not exists responsable text references public.members(id) on delete set null;
drop policy if exists events_update on public.events;
create policy events_update on public.events for update to authenticated
  using (public.is_admin() or by_member = public.my_member_id())
  with check (public.is_admin() or by_member = public.my_member_id());
grant update on public.events to authenticated;
select 'ok' estado;
