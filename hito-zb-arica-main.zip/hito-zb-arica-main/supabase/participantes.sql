-- Participantes adicionales en tareas y eventos
alter table public.tasks add column if not exists participantes text[] not null default '{}';
alter table public.events add column if not exists participantes text[] not null default '{}';
drop policy if exists tasks_read_part on public.tasks;
create policy tasks_read_part on public.tasks for select to authenticated using (public.my_member_id() = any(participantes));
create or replace function public.ics_datos(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare m text; adm boolean;
begin
  if p_token is null or length(p_token) < 20 then return null; end if;
  select c.member_id, (mb.role = 'admin') into m, adm from public.cal_tokens c join public.members mb on mb.id = c.member_id where c.token = p_token;
  if m is null then return null; end if;
  return jsonb_build_object(
    'admin', adm,
    'tasks', coalesce((select jsonb_agg(jsonb_build_object('id', t.id, 'title', t.title, 'due', t.due, 'done', t.done, 'proc', t.proc,
        'progress', t.progress, 'resp', (select name from public.members x where x.id = t.member_id), 'evidencia', t.evidencia,
        'mia', (t.member_id = m or t.apoyo = m or t.delegado = m or m = any(t.participantes))))
      from public.tasks t
      where (adm or t.member_id = m or t.apoyo = m or t.delegado = m or t.publico or m = any(t.participantes))
        and t.due > now() - interval '45 days'), '[]'::jsonb),
    'events', coalesce((select jsonb_agg(jsonb_build_object('id', e.id, 'title', e.title, 'type', e.type, 'at', e.at, 'detail', e.detail))
      from public.events e where e.at > now() - interval '45 days'), '[]'::jsonb));
end $$;
select 'ok' estado;
