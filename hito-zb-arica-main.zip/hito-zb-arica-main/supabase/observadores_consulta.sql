-- Cuentas externas de consulta: sin alterar roles, tablas ni políticas existentes.
begin;
create schema if not exists hito_observation;
revoke all on schema hito_observation from public,anon,authenticated;
grant usage on schema hito_observation to service_role;
create table if not exists hito_observation.accounts (
 id uuid primary key default gen_random_uuid(), name text not null, phone text not null unique,
 email text, password_hash text not null, active boolean not null default true,
 password_change_required boolean not null default true,
 failures int not null default 0, blocked_until timestamptz, created_at timestamptz not null default now()
);
create table if not exists hito_observation.sessions (
 token_hash text primary key, account_id uuid not null references hito_observation.accounts(id) on delete cascade,
 expires_at timestamptz not null
);
alter table hito_observation.accounts enable row level security;
alter table hito_observation.sessions enable row level security;
drop policy if exists observer_server_only on hito_observation.accounts;
create policy observer_server_only on hito_observation.accounts for all to service_role using (true) with check (true);
drop policy if exists observer_server_only on hito_observation.sessions;
create policy observer_server_only on hito_observation.sessions for all to service_role using (true) with check (true);
revoke all on hito_observation.accounts,hito_observation.sessions from public,anon,authenticated;
grant all on hito_observation.accounts,hito_observation.sessions to service_role;

-- Todos estos RPC son de servidor: solo service_role puede ejecutarlos.
create or replace function public.hito_observer_manage(p_action text,p_data jsonb) returns jsonb
language plpgsql security invoker set search_path='' as $$
declare result jsonb; uid uuid; digits text;
begin
 if p_action='list' then
  select coalesce(jsonb_agg(jsonb_build_object('id','obs-'||id::text,'name',name,'phone',phone,'email',email,'role','observer','active',active,'user_id',id) order by name),'[]'::jsonb) into result from hito_observation.accounts;
  return result;
 elsif p_action='create' then
  digits:=regexp_replace(coalesce(p_data->>'phone',''),'\D','','g');
  if digits !~ '^569[0-9]{8}$' then raise exception 'Ingresa un celular chileno válido'; end if;
  if length(trim(coalesce(p_data->>'name','')))<5 then raise exception 'Escribe nombre y apellidos'; end if;
  if coalesce(p_data->>'password','') !~ '^[0-9]{12}$' then raise exception 'Clave temporal inválida'; end if;
  insert into hito_observation.accounts(name,phone,email,password_hash)
  values(trim(p_data->>'name'),digits,nullif(trim(p_data->>'email'),''),extensions.crypt(p_data->>'password',extensions.gen_salt('bf',10))) returning id into uid;
  return jsonb_build_object('id','obs-'||uid::text);
 elsif p_action in ('reset','activate','deactivate') then
  uid:=replace(p_data->>'id','obs-','')::uuid;
  if not exists(select 1 from hito_observation.accounts where id=uid) then raise exception 'Observador no encontrado'; end if;
  if p_action='reset' then
   if coalesce(p_data->>'password','') !~ '^[0-9]{12}$' then raise exception 'Clave temporal inválida'; end if;
   update hito_observation.accounts set password_hash=extensions.crypt(p_data->>'password',extensions.gen_salt('bf',10)),password_change_required=true,failures=0,blocked_until=null where id=uid;
  else update hito_observation.accounts set active=(p_action='activate') where id=uid;
  end if;
  delete from hito_observation.sessions where account_id=uid;
  return jsonb_build_object('ok',true);
 end if;
 raise exception 'Acción inválida';
end $$;

create or replace function public.hito_observer_login(p_phone text,p_password text,p_token text) returns jsonb
language plpgsql security invoker set search_path='' as $$
declare a hito_observation.accounts%rowtype;
begin
 if length(coalesce(p_password,''))<6 or length(coalesce(p_password,''))>64 or length(coalesce(p_token,''))<>64 then return jsonb_build_object('error','Credenciales inválidas'); end if;
 select * into a from hito_observation.accounts where phone=p_phone for update;
 if not found or not a.active then return jsonb_build_object('error','Número o clave incorrectos'); end if;
 if a.blocked_until>now() then return jsonb_build_object('error','Demasiados intentos. Espera 15 minutos.'); end if;
 if a.password_hash<>extensions.crypt(p_password,a.password_hash) then
  update hito_observation.accounts set failures=failures+1,blocked_until=case when failures+1>=5 then now()+interval '15 minutes' else null end where id=a.id;
  return jsonb_build_object('error','Número o clave incorrectos');
 end if;
 update hito_observation.accounts set failures=0,blocked_until=null where id=a.id;
 delete from hito_observation.sessions where expires_at<=now();
 insert into hito_observation.sessions values(encode(extensions.digest(p_token,'sha256'),'hex'),a.id,now()+interval '8 hours');
 return jsonb_build_object('ok',true);
end $$;

create or replace function public.hito_observer_session(p_token text,p_action text default 'read',p_password text default null) returns jsonb
language plpgsql security invoker set search_path='' as $$
declare a hito_observation.accounts%rowtype; result jsonb; v_from timestamptz; v_to timestamptz;
begin
 if length(coalesce(p_token,''))<>64 then raise exception 'Sesión inválida' using errcode='42501'; end if;
 select ac.* into a from hito_observation.sessions s join hito_observation.accounts ac on ac.id=s.account_id
 where s.token_hash=encode(extensions.digest(p_token,'sha256'),'hex') and s.expires_at>now() and ac.active;
 if not found then raise exception 'Sesión vencida. Ingresa nuevamente.' using errcode='42501'; end if;
 if p_action='logout' then
  delete from hito_observation.sessions where token_hash=encode(extensions.digest(p_token,'sha256'),'hex');return jsonb_build_object('ok',true);
 elsif p_action='change_password' then
  if coalesce(p_password,'') !~ '^[0-9]{8,64}$' then raise exception 'El PIN debe tener entre 8 y 64 dígitos'; end if;
  if a.password_hash=extensions.crypt(p_password,a.password_hash) then raise exception 'Elige un PIN distinto del actual'; end if;
  update hito_observation.accounts set password_hash=extensions.crypt(p_password,extensions.gen_salt('bf',10)),password_change_required=false where id=a.id;
  delete from hito_observation.sessions where account_id=a.id and token_hash<>encode(extensions.digest(p_token,'sha256'),'hex');
  return jsonb_build_object('ok',true);
 elsif p_action not in ('read','read_month','read_year','read_all') then raise exception 'Solo lectura' using errcode='42501'; end if;
 if a.password_change_required then return jsonb_build_object('password_change_required',true,'me',jsonb_build_object('id','obs-'||a.id,'name',a.name,'role','observer')); end if;
 -- Los observadores solo reciben indicadores agregados, nunca tareas ni fichas.
 if p_action='read_all' then v_from:='2000-01-01';v_to:='2100-01-01';
 elsif p_action='read_year' then
  v_from:=date_trunc('year',now() at time zone 'America/Santiago') at time zone 'America/Santiago';v_to:=v_from+interval '1 year';
 else
  v_from:=date_trunc('month',now() at time zone 'America/Santiago') at time zone 'America/Santiago';v_to:=v_from+interval '1 month';
 end if;
 with base as (
  select t.done,t.done_at,t.due,t.late,t.progress,t.proc,coalesce(nullif(m.unit,''),'Sin unidad') unit,
   (t.done is true and t.done_at<=t.due and not coalesce(t.late,false)) on_time
  from public.tasks t left join public.members m on m.id=t.member_id where t.due>=v_from and t.due<v_to
 ), totals as (
  select count(*) total,count(*) filter(where done is true) completed,
   count(*) filter(where done is not true and due<now()) overdue,
   count(*) filter(where done is not true and due>=now() and due<now()+interval '48 hours') soon,
   count(*) filter(where due<=now()) matured,count(*) filter(where due<=now() and on_time) on_time,
   round(avg(case when done is true then 100 else greatest(0,least(coalesce(progress,0),100)) end),1) progress_pct from base
 ) select jsonb_build_object('loaded',true,'error','','scope','dashboard_aggregates',
  'me',jsonb_build_object('id','obs-'||a.id,'name',a.name,'role','observer'),
  'dashboard',jsonb_build_object('as_of',now(),'from',v_from,'to',v_to,'aggregated_only',true,
   'metrics',(select to_jsonb(t)||jsonb_build_object('compliance_pct',round(100.0*on_time/nullif(matured,0),1)) from totals t),
   'units',(select coalesce(jsonb_agg(to_jsonb(q)),'[]'::jsonb) from (
    select unit name,count(*) total,count(*) filter(where done is true) completed,count(*) filter(where done is not true and due<now()) overdue,
     round(100.0*count(*) filter(where due<=now() and on_time)/nullif(count(*) filter(where due<=now()),0),1) compliance_pct
    from base group by unit having count(*)>=5) q),
   'processes',(select coalesce(jsonb_agg(to_jsonb(q)),'[]'::jsonb) from (
    select coalesce(nullif(proc,''),'Sin proceso') name,count(*) total,count(*) filter(where done is true) completed from base group by coalesce(nullif(proc,''),'Sin proceso') having count(*)>=5) q),
   'alerts','[]'::jsonb)
 ) into result;
 return result;
end $$;
revoke all on function public.hito_observer_manage(text,jsonb),public.hito_observer_login(text,text,text),public.hito_observer_session(text,text,text) from public,anon,authenticated;
grant execute on function public.hito_observer_manage(text,jsonb),public.hito_observer_login(text,text,text),public.hito_observer_session(text,text,text) to service_role;
notify pgrst,'reload schema';
commit;
