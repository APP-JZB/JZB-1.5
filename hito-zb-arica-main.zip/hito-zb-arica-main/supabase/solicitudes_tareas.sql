-- Todos pueden mandar trabajos a todos.
-- · Al Jefe Administrativo o al Comandante: llega como solicitud que ellos aceptan, modifican o rechazan.
-- · A una persona de OTRA organización (área): la aprueba 1° el Jefe Administrativo y 2° el Comandante; recién ahí se publica.
-- · Dentro de la misma organización: se publica directo.
create table if not exists public.solicitudes (
  id uuid primary key default gen_random_uuid(),
  tipo text not null check (tipo in ('tarea','derivacion')),
  task_id uuid references public.tasks(id) on delete cascade,
  datos jsonb not null default '{}'::jsonb,
  destino text not null references public.members(id) on delete cascade,
  solicitante text not null references public.members(id) on delete cascade,
  estado text not null default 'pend_ja',
  motivo text default '',
  ja_por text, ja_at timestamptz, cdte_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.solicitudes drop constraint if exists solicitudes_estado_check;
alter table public.solicitudes add constraint solicitudes_estado_check check (estado in ('pend_ja','pend_cdte','pend_destino','aprobada','rechazada'));
alter table public.solicitudes enable row level security;
drop policy if exists solicitudes_read on public.solicitudes;
create policy solicitudes_read on public.solicitudes for select to authenticated
  using (public.is_admin() or solicitante = public.my_member_id() or destino = public.my_member_id() or public.my_member_id() = 'm-passalacqua');
grant select on public.solicitudes to authenticated;
do $$ begin alter publication supabase_realtime add table public.solicitudes; exception when others then null; end $$;

create or replace function public.misma_org(a text, b text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select public.area_estricta(coalesce(x.parte_unit, x.unit)) from public.members x where x.id = a)
              = (select public.area_estricta(coalesce(y.parte_unit, y.unit)) from public.members y where y.id = b), false)
$$;

-- Las funciones de solicitudes marcan la sesión para que los resguardos de tareas no reescriban al responsable.
create or replace function public.guard_task_insert() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() or auth.uid() is null or current_setting('hito.bypass', true) = '1' then return new; end if;
  new.member_id := public.my_member_id(); new.created_by := public.my_member_id();
  new.done := false; new.done_at := null; new.late := false; new.no_shows := 0;
  return new;
end $$;
create or replace function public.guard_task_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() or auth.uid() is null or current_setting('hito.bypass', true) = '1' then return new; end if;
  if old.member_id is distinct from public.my_member_id() then new.delegado := old.delegado; new.delegado_por := old.delegado_por;
  else new.delegado_por := case when new.delegado is null then null else public.my_member_id() end; end if;
  if old.created_by is not null and old.created_by = public.my_member_id() then
    new.member_id := old.member_id; new.created_by := old.created_by; new.late := old.late; new.no_shows := old.no_shows; new.apoyo := old.apoyo;
  else
    new.title := old.title; new.tf := old.tf; new.proc := old.proc; new.member_id := old.member_id; new.area := old.area; new.apoyo := old.apoyo;
    new.due := old.due; new.late := old.late; new.no_shows := old.no_shows; new.created_at := old.created_at; new.created_by := old.created_by;
    new.escalar := old.escalar; new.controla := old.controla;
  end if;
  if old.done = false and new.done = true then new.done_at := now(); end if;
  if new.done = false then new.done_at := null; end if;
  return new;
end $$;

create or replace function public._publicar_tarea(p_datos jsonb, p_destino text, p_solicitante text, p_nota text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform set_config('hito.bypass', '1', true);
  insert into public.tasks (title, area, tf, proc, member_id, due, stages, evidencia, participantes, created_by, log)
  values (p_datos->>'title', nullif(p_datos->>'area',''), coalesce(nullif(p_datos->>'tf',''),'TF6'), coalesce(p_datos->>'proc',''), p_destino,
          (p_datos->>'due')::timestamptz, coalesce(p_datos->'stages','[]'::jsonb), coalesce(p_datos->>'evidencia',''),
          coalesce((select array_agg(v) from jsonb_array_elements_text(coalesce(p_datos->'participantes','[]'::jsonb)) v), '{}'), p_solicitante,
          jsonb_build_array(jsonb_build_object('t', 'creada por ' || coalesce((select name from public.members where id = p_solicitante),'') || p_nota, 'at', (extract(epoch from now())*1000)::bigint)));
end $$;
revoke all on function public._publicar_tarea(jsonb, text, text, text) from public, anon, authenticated;

create or replace function public._estado_inicial(yo text, destino text) returns text
language sql stable security definer set search_path = public as $$
  select case
    when destino in ('m-passalacqua','m-cerda') and destino <> yo then 'pend_destino'
    when public.is_admin() or destino = yo or public.misma_org(yo, destino) then 'directo'
    when yo = 'm-passalacqua' then 'pend_cdte'
    else 'pend_ja' end
$$;

-- Crear una tarea para otra persona
create or replace function public.crear_tarea_para(p_datos jsonb, p_destino text) returns text
language plpgsql security definer set search_path = public as $$
declare yo text := public.my_member_id(); est text;
begin
  if yo is null then raise exception 'Sin sesión'; end if;
  est := public._estado_inicial(yo, p_destino);
  if est = 'directo' then perform public._publicar_tarea(p_datos, p_destino, yo, ''); return 'creada'; end if;
  insert into public.solicitudes (tipo, datos, destino, solicitante, estado) values ('tarea', p_datos, p_destino, yo, est);
  return est;
end $$;

-- Derivar una tarea
create or replace function public.derivar_tarea(p_task uuid, p_destino text) returns text
language plpgsql security definer set search_path = public as $$
declare yo text := public.my_member_id(); t public.tasks%rowtype; est text;
begin
  select * into t from public.tasks where id = p_task;
  if not found then raise exception 'Tarea no encontrada'; end if;
  if not (public.is_admin() or t.member_id = yo or t.delegado = yo or t.apoyo = yo) then raise exception 'Solo el responsable puede derivar'; end if;
  est := case when p_destino is null then 'directo' else public._estado_inicial(yo, p_destino) end;
  if est = 'directo' then
    perform set_config('hito.bypass', '1', true);
    update public.tasks set delegado = p_destino, delegado_por = case when p_destino is null then null else yo end,
      log = coalesce(log,'[]'::jsonb) || jsonb_build_array(jsonb_build_object('t', case when p_destino is null then 'derivación retirada' else 'derivada a ' || (select name from public.members where id = p_destino) end, 'at', (extract(epoch from now())*1000)::bigint))
    where id = p_task;
    return 'derivada';
  end if;
  insert into public.solicitudes (tipo, task_id, datos, destino, solicitante, estado)
  values ('derivacion', p_task, jsonb_build_object('title', t.title, 'due', t.due), p_destino, yo, est);
  return est;
end $$;

-- Resolver: aprobar / rechazar, pudiendo modificar título, plazo o detalle (p_datos).
-- pend_destino: lo resuelve el Jefe Administrativo o el Comandante que recibe el trabajo (acepta, modifica, rechaza o deriva con p_derivar_a).
-- pend_ja: Jefe Administrativo → pasa a pend_cdte. pend_cdte: Comandante → se publica.
drop function if exists public.resolver_solicitud(uuid, boolean, text, jsonb);
create or replace function public.resolver_solicitud(p_id uuid, p_aprobar boolean, p_motivo text default '', p_datos jsonb default null, p_derivar_a text default null) returns text
language plpgsql security definer set search_path = public as $$
declare yo text := public.my_member_id(); s public.solicitudes%rowtype; nota text; dest text;
begin
  select * into s from public.solicitudes where id = p_id for update;
  if not found then raise exception 'Solicitud no encontrada'; end if;
  if s.estado = 'pend_destino' and yo <> s.destino then raise exception 'La resuelve quien recibe el trabajo'; end if;
  if s.estado = 'pend_ja' and yo <> 'm-passalacqua' then raise exception 'La aprueba primero el Jefe Administrativo'; end if;
  if s.estado = 'pend_cdte' and not public.is_admin() then raise exception 'La aprueba el Comandante de Zona'; end if;
  if s.estado not in ('pend_ja','pend_cdte','pend_destino') then return s.estado; end if;
  if p_datos is not null then update public.solicitudes set datos = datos || p_datos where id = p_id; s.datos := s.datos || p_datos; end if;
  if not p_aprobar then
    update public.solicitudes set estado = 'rechazada', motivo = coalesce(p_motivo,'') where id = p_id;
    return 'rechazada';
  end if;
  if s.estado = 'pend_ja' and p_derivar_a is null then
    update public.solicitudes set estado = 'pend_cdte', ja_por = yo, ja_at = now() where id = p_id;
    return 'pend_cdte';
  end if;
  dest := coalesce(p_derivar_a, s.destino);
  nota := case when p_derivar_a is not null then ' · derivada por ' || (select name from public.members where id = yo)
               when s.estado = 'pend_destino' then ' · aceptada por quien la recibe' else ' · aprobada por Jefe Adm. y Cdte.' end;
  if s.tipo = 'tarea' then
    perform public._publicar_tarea(s.datos, dest, s.solicitante, nota);
  else
    perform set_config('hito.bypass', '1', true);
    update public.tasks set delegado = dest, delegado_por = case when p_derivar_a is not null then yo else s.solicitante end,
      due = coalesce((s.datos->>'due')::timestamptz, due),
      log = coalesce(log,'[]'::jsonb) || jsonb_build_array(jsonb_build_object('t', 'derivada a ' || (select name from public.members where id = dest) || nota, 'at', (extract(epoch from now())*1000)::bigint))
    where id = s.task_id;
  end if;
  update public.solicitudes set estado = 'aprobada', destino = dest, cdte_at = now(), ja_por = coalesce(ja_por, case when s.estado = 'pend_destino' then yo end) where id = p_id;
  return 'aprobada';
end $$;
grant execute on function public.misma_org(text, text) to authenticated;
grant execute on function public.crear_tarea_para(jsonb, text) to authenticated;
grant execute on function public.derivar_tarea(uuid, text) to authenticated;
grant execute on function public.resolver_solicitud(uuid, boolean, text, jsonb, text) to authenticated;
notify pgrst, 'reload schema';
select 'ok' estado;
-- NOTA 16OCT2026: también se re-aplicaron parte_jefes_seccion.sql (jefes de sección + mural) y puede_aportar(),
-- que se habían deshecho porque la prueba con begin/rollback estaba en el mismo script.
