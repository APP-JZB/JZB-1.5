-- Resetear acceso de un integrante (solo el Comandante). No se borra nada ni se fija ninguna clave:
-- se desvincula su cuenta y se libera su número para que cree un PIN nuevo con "Crear mi acceso".
create or replace function public.reset_acceso(p_member text) returns text
language plpgsql security definer set search_path = public, auth as $$
declare uid uuid; nuevo text;
begin
  if not public.is_admin() then raise exception 'Solo el Comandante puede resetear accesos'; end if;
  select user_id into uid from public.members where id = p_member;
  if uid is null then return 'sin_cuenta'; end if;
  nuevo := 'reset-' || replace(uid::text, '-', '') || '-' || to_char(now(), 'YYYYMMDDHH24MISS') || '@hito.old';
  update public.members set user_id = null where id = p_member;
  update auth.users set email = nuevo where id = uid;
  update auth.identities set identity_data = identity_data || jsonb_build_object('email', nuevo) where user_id = uid;
  return 'ok';
end $$;
revoke all on function public.reset_acceso(text) from public, anon;
grant execute on function public.reset_acceso(text) to authenticated;
notify pgrst, 'reload schema';
select 'ok' estado;
