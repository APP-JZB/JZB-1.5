-- Tareas visibles para todos en la Carta Gantt
alter table public.tasks add column if not exists publico boolean not null default false;
drop policy if exists tasks_read_publico on public.tasks;
create policy tasks_read_publico on public.tasks for select to authenticated using (publico);
update public.tasks set publico = true where title like 'Levantamiento TD 2026%';
select count(*) publicas from public.tasks where publico;
