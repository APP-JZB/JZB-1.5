-- Parte de fuerza v2: agregar/quitar personas, novedades con fechas
alter table public.members add column if not exists parte boolean;
update public.members set parte = (nivel <> 'X') where parte is null;
alter table public.members alter column parte set default true;
alter table public.members add column if not exists parte_unit text;
alter table public.members add column if not exists parte_desde date;
alter table public.members add column if not exists parte_hasta date;
alter table public.members add column if not exists salida_motivo text default '';

create table if not exists public.novedades (
  id uuid primary key default gen_random_uuid(),
  member_id text not null references public.members(id) on delete cascade,
  motivo text not null,
  desde date not null,
  hasta date not null,
  comment text default '',
  created_at timestamptz default now()
);
alter table public.novedades enable row level security;
drop policy if exists novedades_admin on public.novedades;
create policy novedades_admin on public.novedades for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.novedades to authenticated;
do $$ begin begin alter publication supabase_realtime add table public.novedades; exception when others then null; end; end $$;
do $$ begin begin alter publication supabase_realtime add table public.parte_fuerza; exception when others then null; end; end $$;
select 'ok' as estado, (select count(*) from public.members where parte) as en_parte;
