-- Cada integrante puede avisar (y retirar) sus propias ausencias
drop policy if exists novedades_own_read on public.novedades;
create policy novedades_own_read on public.novedades for select to authenticated using (member_id = public.my_member_id());
drop policy if exists novedades_own_insert on public.novedades;
create policy novedades_own_insert on public.novedades for insert to authenticated with check (member_id = public.my_member_id());
drop policy if exists novedades_own_delete on public.novedades;
create policy novedades_own_delete on public.novedades for delete to authenticated using (member_id = public.my_member_id());
