-- Actualiza la estructura funcional de Planificación y OCGR en Hito ZB Arica.
-- Ejecutar una sola vez en Supabase → SQL Editor.
-- Conserva teléfonos, correos, grado, accesos y demás datos de cada integrante.

update public.members
set unit = 'Oficina de Planificación',
    cargo = 'Titular Oficina de Planificación · apoyo secundario OCGR'
where id = 'm-urquieta';

update public.members
set unit = 'Oficina Control de Gestión y Riesgo',
    cargo = 'Encargada OCGR · PRYMA · delegada de procesos ZB Arica'
where id = 'm-barbara-llancavil-cortez';

insert into public.config (key, value)
values (
  'owners',
  jsonb_build_object(
    'PLAN', 'm-urquieta',
    'ADM-CGR', 'm-barbara-llancavil-cortez'
  )
)
on conflict (key) do update
set value = coalesce(public.config.value, '{}'::jsonb) || excluded.value;
