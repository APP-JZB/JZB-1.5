-- 16OCT2026: "Oficina de Planificación" pasa a llamarse "Oficina de Operaciones" (área PLAN se mantiene como código).
update public.members set unit = 'Oficina de Operaciones' where unit = 'Oficina de Planificación';
update public.members set parte_unit = 'Oficina de Operaciones' where parte_unit = 'Oficina de Planificación';
update public.members set cargo = replace(cargo, 'Oficina de Planificación', 'Oficina de Operaciones') where cargo like '%Oficina de Planificación%';
update public.position_profiles set cargo_key = replace(cargo_key, 'oficina de planificacion', 'oficina de operaciones'), cargo = replace(cargo, 'Oficina de Planificación', 'Oficina de Operaciones') where cargo_key like '%oficina de planificacion%';
-- area_de_unidad() y my_area() aceptan ambos nombres (ver historial del editor SQL).
