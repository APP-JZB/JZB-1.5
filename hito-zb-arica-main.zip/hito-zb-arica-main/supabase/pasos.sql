alter table public.tasks add column if not exists pasos jsonb not null default '[]'::jsonb;
