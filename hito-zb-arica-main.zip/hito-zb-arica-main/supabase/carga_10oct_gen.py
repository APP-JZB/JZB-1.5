import json, re
JA="m-passalacqua"
D16="2026-10-16 12:00"; D23="2026-10-23 12:00"
A={ # area: (owner, proc, tf)
 "CDO":(JA,"PLAN","TF1"),"AJ":("m-illesca","ADM-CGR","TF1"),"PER":("m-perez","ADM-PER","TF6"),"FIN":("m-rodriguez","ADM-FIN","TF6"),
 "SEG":("m-hector-lopez-calderon","ADM-LOG","TF6"),"PLAN":("m-urquieta","PLAN","TF1"),"OCGR":("m-barbara-llancavil-cortez","ADM-CGR","TF1"),"CGA":("m-veliz","ADM-ADQ","TF6"),
 "CTO":("m-rodrigo-oyarce-jara","ADM-CON","TF6"),"VF":("m-ramirez","HAT-06","TF2"),"HAB":("m-martinez","HAB-05","TF3"),
 "REC":("m-francia-mundaca-toledo","REC-06","TF4"),"CRA":("m-ariel-martinez-quezada","REC-05","TF4"),"COEM":("m-acuna","REC-04","TF4"),
 "JI":("m-hermosilla","JI-05","TF5"),"ASI":("m-vergara","CONV","TF5"),"LOG":("m-carlos-chavez-jimenez","ADM-LOG","TF6"),
 "MANT":("m-cid","ADM-LOG","TF6"),"ITO":("m-fabian-torres-rivera","ADM-CON","TF6")}
def mon(s):
    s=s.upper().replace(' ','')
    m=re.match(r'(\d{1,2})(SEP|OCT|NOV|DIC)',s)
    if not m: return None
    mm={'SEP':9,'OCT':10,'NOV':11,'DIC':12}[m.group(2)]
    return f"2026-{mm:02d}-{int(m.group(1)):02d} 12:00"
T=[] # (area, title, detail, plazo_original_text, who_override, due_override, proc_override)
def add(area,title,detail="",plazo="",who=None,due=None,proc=None): T.append(dict(area=area,title=title,detail=detail,plazo=plazo,who=who,due=due,proc=proc))
# Encabezado sin responsable -> Jefe Administrativo
add("CDO","Averiguar qué unidad tiene elevador de hombres y podar 1 palmera (ratones)",who=JA)
add("CDO","Ver por cada área qué temas puede ver directamente mi Comandante en Santiago",who=JA)
add("MANT","Equipo de apoyo: dejar listos cuadros para cemento y pasivo (esta semana)",who=JA,due=D16)
add("CDO","Proyecto para entrega del Cuartel Santa María",who=JA)
add("CDO","Presentación para el Jefe de la Jefatura",who=JA,due="2026-10-15 09:00")
# Tabla
rows=[
("AJ","Empresa de mantenimiento mayor","Cierre de recepción de ofertas 29OCT.","","2026-10-29 12:00"),
("AJ","Resolución déficit VF SOF y resolución VF superávit Oficiales","Junto con VF",""),
("AJ","Norma legal piscina","","05 OCT"),
("AJ","Cuándo puede ser utilizada la empresa de obras mayores","Máximo podría empezar el 15 OCT. Responsables: Cdte, SOF Ramírez, SG1 Cid","30 SEP"),
("PER","Contratos de honorarios","En revisión SOF Rodríguez y Magdalena San Martín; memos en Finanzas DIVBIE, falta JEM y mi General","01 OCT"),
("PER","Cambios en la TD","Cdte de Zona ordena realizar el trabajo de la TD conforme a reglamento","09 OCT"),
("PER","Puestos y vacantes TD","Documento en ejecución y análisis","07 OCT"),
("PER","Propuesta TD","","14OCT"),
("PER","Procesos: trabajar los procesos por área","",""),
("FIN","Saldo traslado COEM ($897.531)","",""),
("FIN","Adendum fondos JI","Seguimiento","09 OCT"),
("FIN","Presentación de gestión anual y proyección últimos 3 meses","","05 OCT"),
("FIN","Propuesta de curso de acción de aporte a Plana Mayor","","07 OCT"),
("FIN","Plazo de respuesta de CGE para empalme 2","","10 OCT"),
("VF","Resolución con fechas y plazos de recepción y entrega de viviendas fiscales","En espera de oficialización del PAD",""),
("VF","Catastro de restitución de VF ordenado el 2025","","09 oct"),
("VF","Seguimiento y control casa La Lisera","Proceso de adjudicación de oferentes","05 OCT"),
("VF","Contrato empresa áreas verdes","Prever contrato nuevo (contrato actual vence 31ENE2027)","","2026-12-01 12:00"),
("VF","Línea de tiempo para entrega de VF en reparación","","09OCT"),
("VF","Entrega y recepción de VF","Documento informativo con fecha estimada 15DIC","14 OCT"),
("VF","Trasladar los aires acondicionados a la casa de La Lisera","",""),
("VF","Licitación piscina Villa Militar Azapa","Subida al portal; seguimiento (cierre 16OCT, adjudicación 26OCT)","29 SEP"),
("CDO","Verificar saldos de los C/C y planificar gasto octubre, noviembre y diciembre","En ejecución (Operaciones)","02 OCT"),
("CDO","Revisión de presentación para el JJB","Operaciones","08OCT"),
("ASI","Organización de feria de bienestar","",""),
("OCGR","PSF","PPOZ","noviembre","2026-11-02 12:00"),
("SEG","04 equipos en condiciones de ser armados para intranet","Necesidad de compra de fuente de poder (≈$500.000 c/u)",""),
("SEG","Escáner para Personal","","09OCT"),
("HAB","Trabajos en el quincho","Compra de nivelador ejecutada",""),
("HAB","Sistema de regadío","Inicio trabajos 01OCT",""),
("HAB","Ablandador de agua: verificar si funciona y si puede usarse","","07OCT"),
("HAB","Panel de configuración de las bombas ($7.056.700)","OC 244 enviada al proveedor 05OCT",""),
("HAB","Saldo salas de bomba ($2.917.490)","",""),
("JI","Camino de evacuación y puerta","En espera de cotización","02 OCT"),
("JI","Sedil","Falta mueble aéreo, se instala al terminar la red de gas","03 OCT"),
("JI","Bomba de levante: solicitar cotización","","16 OCT"),
("JI","Acreditación: plan de trabajo y línea de tiempo","","09 OCT"),
("REC","Documento de precios especiales para unidades","En la Jefatura; seguimiento",""),
("CRA","Pago del agua","Septiembre en trámite; boleta de octubre llega aprox. 20–22",""),
("CRA","Revisión de los termos","ITO",""),
("CRA","Instagram del hotel: crear y administrar la red social","","","2026-10-15 12:00"),
("REC","Pagos IAMS","Seguimiento","30 SEP"),
("CRA","Situación termos","Seguimiento","05 OCT"),
("CRA","Cubrecamas","Seguimiento","30 SEP"),
("CRA","Snackbar CRA por $20 millones: licitar","Temporada 01ENE–28FEB2027","14OCT"),
("CRA","Lavavajillas","Seguimiento","01OCT"),
("CRA","Resolución piscinas: chequear que efectivamente esté certificada","","09 OCT"),
("REC","Informar sobre arriendos de colegios e instituciones (fiestas de fin de año)","","09OCT"),
("CRA","Levantar propuesta de fiesta de fin de año en el CRA","","09 OCT"),
("CRA","Revisión sala de bombas CRA","Equipo de apoyo",""),
("LOG","Reunión RL6: vestuario y equipo","",""),
("LOG","Licencias de conducir: averiguar fondos","","09OCT",None,JA),
("LOG","Manipuladores de alimentos","","09OCT",None,JA),
("LOG","Seguros","Seguimiento","",None,JA),
]
for r in rows:
    area,title,det,pl=r[:4]; due=r[4] if len(r)>4 else None; who=r[5] if len(r)>5 else None
    add(area,title,det,pl,who=who,due=due)
# Pendientes desde la reunión 02OCT (no repetidos)
pp=[
("AJ","Resolución designa personal control trabajos gas JJII","En desarrollo (reunión 02OCT)"),
("AJ","Resolución designa comisión receptora Empalme","En desarrollo"),
("AJ","Revisión bases motor portón VMA","En desarrollo"),
("AJ","Análisis solicitud uso CRA por fundación","En desarrollo"),
("AJ","Resolución autoriza uso tenida corporativa","Suceso crítico"),
("AJ","Adendum alimentos JJII (aumento de presupuesto, dic–ene)","Suceso crítico"),
("CTO","Recepción provisoria y final del remarcador (licitación 838099-3-LE26)","Pendiente informe MAY Passalacqua",None,JA),
("CTO","Solicitar cotizaciones previsionales y factura al proveedor R. Rocha K. (remarcador)",""),
("HAB","Informe de recepción término de trabajos (bombas, 963423-7-LE26)","Encargado SOF Martínez"),
("PER","Tramitar pagos PAH",""),
("PER","Seguimiento nuevo cheque para ex ECL (salvavidas)",""),
("OCGR","2da certificación violencia de género, acoso laboral, acoso sexual y VIF","Plazo 05OCT2026","05 OCT"),
("OCGR","Preparación PSF octubre 2026 (1ra certificación)",""),
("OCGR","Hallazgo auditoría N°1: faltan 05 cartas de compromiso","Plazo 20OCT2026",None,None,"2026-10-20 12:00"),
("LOG","Imprimir planchetas de inventario de VF para carpetas de usuarios","Novedad encontrada por COTRAE"),
("VF","Compra de elementos para áreas comunes VMA (mesas, sillas, toldos)","En proceso"),
("VF","Revisión de licitación de portones de las villas militares","En proceso"),
("FIN","Comprobantes de egreso devolución descuentos indebidos Pabellón Oficiales solteros","Confeccionados y firmados, por enviar a pago"),
("FIN","Rendiciones de cuentas por asignaciones extraordinarias",""),
("JI","Corrida familiar 06NOV: compras (poleras, medallas, pendón, premios) y apoyos","",None,None,"2026-11-06 09:00"),
("JI","Reunión técnica","",None,None,"2026-10-23 09:00"),
("JI","Certificación red húmeda (Bomberos)","Esperando datos de contacto"),
("JI","Certificación eléctrica y sala de basura (empresa externa)",""),
("COEM","Pintado exterior de cabañas de alojamiento",""),
("CRA","Filtración de piscina sala de bombas: cotizar",""),
("CRA","Generador eléctrico: comprar",""),
("CRA","Enrejado de oficinas y puerta principal",""),
("MANT","Techo CDTE Zamora, terminar pasivo, materiales quincho-emergencia y tableraje piso GYM","Equipo de apoyo"),
("ITO","Supervisión de obras de reparación y certificación del Jardín Infantil",""),
("CDO","Iniciar compra de elementos computacionales (CGA impresora, Personal escáner)","CC Plana Mayor"),
]
for r in pp:
    area,title,det=r[:3]; pl=r[3] if len(r)>3 else ""; who=r[4] if len(r)>4 else None; due=r[5] if len(r)>5 else None
    add(area,title,det,pl or "",who=who,due=due)
# Mercado Público pendientes -> CGA
mp=[
("Adjudicar licitación habitabilidad 963423-11-LE26 ($70 M, 2 ofertas)","Venció 09OCT 13:00: adjudicar o publicar nueva fecha justificada","09 OCT"),
("Enviar OC 963423-245-SE26 pintura de inmueble ($28,6 M)","Licitación 10-LE26 adjudicada 05OCT, OC guardada sin enviar",""),
("Autorizar y enviar OC 963423-228-SE26 red de gas JINF ($7,4 M)","En 'enviada a autorizar' desde 21SEP",""),
("Seguimiento aceptación OC 244 (bombas COEM), 246 (ferretería solteros) y 247 (piscina VMA)","$9,9 M en total",""),
("Difundir licitación piscinas VMA 963423-12-L126 para que no quede desierta","Cierra 16OCT, adjudica 26OCT","",None,"2026-10-15 12:00"),
("Completar o eliminar borrador OC 963423-212-SE26 en $0 (materiales VF Silva)","",""),
("Revisar 21 reclamos de proveedores (pago no oportuno)","",""),
]
for r in mp:
    add("CGA",r[0],r[1],r[2],who=r[3] if len(r)>3 else None,due=r[4] if len(r)>4 else None)

def q(s): return "$q$"+s.replace("$q$","")+"$q$"
out=[]
for t in T:
    own,proc,tf=A[t['area']]
    who=t['who'] or own
    orig=mon(t['plazo']) if t['plazo'] else None
    if t['due']: due=t['due']
    elif orig and orig>="2026-10-12": due=orig
    elif orig: due=D16
    else: due=D23
    log=[{"t":"creada","at":1791640800000}]
    if orig and due!=orig: log.append({"t":"Plazo original "+t['plazo'].strip()+" (cargado desde lista de trabajos, nuevo plazo 16OCT)","at":1791640800000})
    if t['detail']: log.append({"t":"Nivel de ejecución: "+t['detail'],"at":1791640800000})
    out.append(dict(title=t['title'],area=t['area'],tf=tf,proc=t['proc'] or proc,member_id=who,due=due+"-03",log=log,done=False))
# Ejecutadas (registro) reunión 02OCT
ex=[
("AJ","Res. autoriza uso cantina"),("AJ","Res. modifica comisión evaluadora Copacabana"),("AJ","Revisión bases mantención piscina VMA"),
("CGA","Subir licitación mantenimiento y reparación de piscinas VMA"),("CGA","Entregar a Personal relación de actualización DIP de septiembre"),
("CTO","Firma contrato licitación gas JINF"),("CTO","Remitir garantía licitación gas al CGA y Finanzas"),("CTO","Remitir a Finanzas VIDE resolución cobro boleta de fiel cumplimiento (obras menores)"),
("PER","Remitir aceptación descuento comisión Btar. SOC. DIVBIE"),("PER","Remitir evaluación anual de ECLs"),("PER","Remitir finiquito y solicitar nuevo cheque ex ECL (salvavidas)"),
("OCGR","HBC 2026 1ra BRIACO"),("OCGR","Reporte trimestral CAIGG"),("OCGR","Remisión PAC auditoría VF (cartas de compromiso y control de descuentos)"),
("FIN","Remisión Planificación Financiera 2027 a JZB"),("FIN","Remisión propuesta de Plana Mayor para aporte de $5.000.000 de la JZB (2do semestre)"),
("VF","Subir a Mercado Público plano casa La Lisera"),("VF","Compra repuesto para luz de postes VMA"),("VF","Bases de licitación reparación piscina VMA"),("VF","Documentación PON"),
("JI","Reunión semanal con educadoras y organización de actividades de octubre"),("JI","Entrevista familias interesadas en matrículas 2027"),
("JI","Tramitación FAE pendientes, revista de existencia, trámite 5% y consumos básicos"),
("HAB","Compra ágil instalación tablero de control sala de bombas"),("HAB","Tramitación facturas materiales y compra ágil para pozo"),
("ITO","Supervisión trabajos licitación 963423-7-LE26 sala de bombas habitabilidad"),
("CDO","OC trabajos mensuales empresa áreas verdes VMA"),("CDO","Tramitar facturas consumos básicos Cuartel Santa María"),
]
for area,title in ex:
    own,proc,tf=A[area]
    out.append(dict(title=title,area=area,tf=tf,proc=proc,member_id=own,due="2026-10-02 12:00-03",log=[{"t":"creada","at":1791640800000},{"t":"Registrado como ejecutado en reunión de coordinación 02OCT2026","at":1791640800000}],done=True))
print(len(out),"tareas;",sum(o['done'] for o in out),"ejecutadas")
sql=["alter table public.tasks add column if not exists area text;"]
vals=[]
for o in out:
    vals.append("(%s,%s,%s,%s,%s,%s::timestamptz,'[]'::jsonb,%d,%s,%s,%s::jsonb)"%(q(o['title']),q(o['area']),q(o['tf']),q(o['proc']),q(o['member_id']),q(o['due']),100 if o['done'] else 0,'true' if o['done'] else 'false',"'2026-10-02 11:00-03'::timestamptz" if o['done'] else 'null',q(json.dumps(o['log'],ensure_ascii=False))))
sql.append("insert into public.tasks (title,area,tf,proc,member_id,due,stages,progress,done,done_at,log) values\n"+",\n".join(vals)+";")
open('/tmp/claude-0/load/tasks.sql','w').write("\n".join(sql))
json.dump(out,open('/tmp/claude-0/load/tasks.json','w'),ensure_ascii=False,indent=0)
