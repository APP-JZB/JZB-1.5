-- Tareas de procesos y riesgo: 1° jefe de área, 2° OCGR (CB1 Llancavil), 3° Planificación (SG1 Urquieta), controla Jefe Administrativo, dirige Cdte ZB
alter table public.tasks add column if not exists dirige text references public.members(id) on delete set null;
with x as (select t.id, case t.area when 'CDO' then 'm-passalacqua' when 'AJ' then 'm-illesca' when 'PER' then 'm-perez' when 'FIN' then 'm-rodriguez' when 'SEG' then 'm-hector-lopez-calderon' when 'OCGR' then 'm-urquieta' when 'CGA' then 'm-veliz' when 'CTO' then 'm-rodrigo-oyarce-jara' when 'VF' then 'm-ramirez' when 'HAB' then 'm-martinez' when 'REC' then 'm-francia-mundaca-toledo' when 'CRA' then 'm-ariel-martinez-quezada' when 'COEM' then 'm-acuna' when 'JI' then 'm-hermosilla' when 'ASI' then 'm-vergara' when 'LOG' then 'm-carlos-chavez-jimenez' when 'MANT' then 'm-cid' when 'ITO' then 'm-fabian-torres-rivera' end as jefe from public.tasks t where t.title like 'Plan de tratamiento%' or t.title like 'Levantamiento TD 2026%')
update public.tasks t set
  member_id = coalesce(x.jefe, t.member_id),
  apoyo = case when coalesce(x.jefe, t.member_id) = 'm-barbara-llancavil-cortez' then null else 'm-barbara-llancavil-cortez' end,
  participantes = case when coalesce(x.jefe, t.member_id) = 'm-urquieta' then '{}'::text[] else array['m-urquieta'] end,
  controla = 'm-passalacqua', dirige = 'm-cerda',
  log = coalesce(t.log, '[]'::jsonb) || jsonb_build_array(jsonb_build_object('t', 'responsables reasignados: jefe de área, OCGR, Planificación; controla Jefe Administrativo; dirige Cdte ZB', 'at', 1791722400000))
from x where x.id = t.id;
update public.riesgos r set responsable = t.member_id from public.tasks t where r.task_id = t.id;
select t.title, t.member_id, t.apoyo, t.participantes, t.controla, t.dirige from public.tasks t where t.title like 'Plan de tratamiento%' or t.title like 'Levantamiento TD 2026%' order by 1;