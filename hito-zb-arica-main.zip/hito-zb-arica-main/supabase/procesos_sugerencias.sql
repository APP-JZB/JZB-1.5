-- Procesos · sugerencias (aplicado el 17-oct-2026). Complementa procesos_agrupacion.sql.
-- Ven la pestaña: Cdte, B. Llancavil, V. Urrutia, SOF Urquieta y SOF Ramírez. Crea/adopta/elimina solo el Cdte; los demás sugieren y el Cdte aprueba.
create or replace function public.puede_ver_procesos() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.my_member_id() in ('m-cerda','m-barbara-llancavil-cortez','m-viviana-urrutia-salinas','m-urquieta','m-ramirez'), false)
$$;
grant execute on function public.puede_ver_procesos() to authenticated;
create or replace function public.es_cdte_proc() returns boolean
language sql stable security definer set search_path = public as $$ select coalesce(public.my_member_id() = 'm-cerda', false) $$;
grant execute on function public.es_cdte_proc() to authenticated;

create table if not exists public.sugerencias_proceso (
  id uuid primary key default gen_random_uuid(),
  tipo text not null check (tipo in ('grupo','proceso')),
  titulo text not null check (length(trim(titulo)) > 0),
  detalle text default '',
  palabras text[] default '{}',
  grupo_id uuid references public.grupos_tareas(id) on delete set null,
  autor text references public.members(id) on delete set null,
  estado text not null default 'pendiente' check (estado in ('pendiente','aprobada','rechazada')),
  motivo text default '',
  created_at timestamptz not null default now(),
  resuelta_at timestamptz
);
alter table public.sugerencias_proceso enable row level security;

create or replace function public._crear_grupo(p_nombre text, p_palabras text[], p_autor text) returns uuid
language plpgsql security definer set search_path = public as $$
declare pal text[]; gid uuid;
begin
  pal := coalesce((select array_agg(distinct public.norm_txt(trim(x))) from unnest(p_palabras) x where length(trim(x)) >= 2), '{}');
  if cardinality(pal) = 0 then raise exception 'Indica al menos una palabra clave'; end if;
  insert into public.grupos_tareas (nombre, palabras, creado_por) values (trim(p_nombre), pal, p_autor) returning id into gid;
  update public.tarea_registro set grupo_id = public.grupo_para(titulo) where grupo_id is null and not grupo_manual;
  return gid;
end $$;
revoke all on function public._crear_grupo(text, text[], text) from public, anon, authenticated;

create or replace function public.crear_grupo(p_nombre text, p_palabras text[]) returns uuid
language plpgsql security definer set search_path = public as $$
begin
  if not public.es_cdte_proc() then raise exception 'Solo el Comandante crea grupos; los demás lo sugieren'; end if;
  return public._crear_grupo(p_nombre, p_palabras, public.my_member_id());
end $$;
grant execute on function public.crear_grupo(text, text[]) to authenticated;

create or replace function public.mover_tarea_grupo(p_task uuid, p_grupo uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.es_cdte_proc() then raise exception 'Solo el Comandante'; end if;
  update public.tarea_registro set grupo_id = p_grupo, grupo_manual = (p_grupo is not null) where task_id = p_task;
end $$;
grant execute on function public.mover_tarea_grupo(uuid, uuid) to authenticated;

create or replace function public.estado_grupo(p_id uuid, p_estado text, p_notas text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.es_cdte_proc() then raise exception 'Solo el Comandante aprueba procesos'; end if;
  update public.grupos_tareas set estado = p_estado, notas = coalesce(p_notas, notas) where id = p_id;
end $$;
grant execute on function public.estado_grupo(uuid, text, text) to authenticated;

create or replace function public.borrar_grupo(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.es_cdte_proc() then raise exception 'Solo el Comandante'; end if;
  delete from public.grupos_tareas where id = p_id;
end $$;
grant execute on function public.borrar_grupo(uuid) to authenticated;

create or replace function public.sugerir_proceso(p_titulo text, p_detalle text default '', p_palabras text[] default '{}', p_grupo uuid default null) returns text
language plpgsql security definer set search_path = public as $$
declare yo text := public.my_member_id();
begin
  if yo is null then raise exception 'Sin sesión'; end if;
  if length(trim(coalesce(p_titulo,''))) = 0 then raise exception 'Escribe un título'; end if;
  insert into public.sugerencias_proceso (tipo, titulo, detalle, palabras, grupo_id, autor)
  values (case when cardinality(coalesce(p_palabras,'{}')) > 0 then 'grupo' else 'proceso' end, trim(p_titulo), coalesce(p_detalle,''), coalesce(p_palabras,'{}'), p_grupo, yo);
  return 'pendiente';
end $$;
grant execute on function public.sugerir_proceso(text, text, text[], uuid) to authenticated;

create or replace function public.resolver_sugerencia(p_id uuid, p_aprobar boolean, p_motivo text default '') returns text
language plpgsql security definer set search_path = public as $$
declare s public.sugerencias_proceso%rowtype;
begin
  if not public.es_cdte_proc() then raise exception 'Solo el Comandante aprueba'; end if;
  select * into s from public.sugerencias_proceso where id = p_id for update;
  if not found then raise exception 'No encontrada'; end if;
  if s.estado <> 'pendiente' then return s.estado; end if;
  if not p_aprobar then
    update public.sugerencias_proceso set estado = 'rechazada', motivo = coalesce(p_motivo,''), resuelta_at = now() where id = p_id;
    return 'rechazada';
  end if;
  if s.tipo = 'grupo' then perform public._crear_grupo(s.titulo, s.palabras, s.autor);
  elsif s.grupo_id is not null then update public.grupos_tareas set estado = 'adoptado' where id = s.grupo_id; end if;
  update public.sugerencias_proceso set estado = 'aprobada', resuelta_at = now() where id = p_id;
  return 'aprobada';
end $$;
grant execute on function public.resolver_sugerencia(uuid, boolean, text) to authenticated;

create or replace function public.mis_sugerencias() returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', id, 'titulo', titulo, 'tipo', tipo, 'estado', estado, 'motivo', motivo, 'creada', created_at) order by created_at desc), '[]'::jsonb)
  from public.sugerencias_proceso where autor = public.my_member_id()
$$;
grant execute on function public.mis_sugerencias() to authenticated;

-- procesos_panel(): ver procesos_agrupacion.sql; la versión vigente además devuelve 'es_cdte' y 'sugerencias' (últimas 60, pendientes primero).
notify pgrst, 'reload schema';
