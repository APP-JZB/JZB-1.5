-- Jefes de sección: marcan y ven el parte (y novedades) de la gente de su sección.
create or replace function public.area_estricta(u text) returns text language sql immutable as $$
  select case u
    when 'Comando ZB Arica' then 'CDO' when 'Jefatura Administrativa' then 'CDO' when 'Registratura' then 'CDO'
    when 'Oficina de Planificación' then 'PLAN' when 'Oficina de Operaciones' then 'PLAN' when 'Oficina Control de Gestión y Riesgo' then 'OCGR'
    when 'Asesoría Jurídica' then 'AJ' when 'Oficina de Personal' then 'PER' when 'Oficina de Finanzas' then 'FIN'
    when 'Oficina de Seguridad' then 'SEG' when 'SICE' then 'SEG' when 'Centro de Gestión de Adquisiciones' then 'CGA'
    when 'Inspección Técnica de Obras (ITO)' then 'ITO' when 'Oficina de Coordinación Logística' then 'LOG'
    when 'Sección Mantenimiento de Infraestructura (Sección de Apoyo)' then 'MANT' when 'Sección Habitacional' then 'VF'
    when 'Sección Habitabilidad' then 'HAB' when 'Sección Recreacional' then 'REC' when 'Centro Recreacional Arica' then 'CRA'
    when 'Club de Oficiales El Morro' then 'COEM' when 'Jardín Infantil Soldadito de Plomo' then 'JI'
    when 'Sección Asistencial' then 'ASI' when 'Área Convenios' then 'ASI' end
$$;
create or replace function public.mis_areas_jefe() returns text[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(a), '{}') from (
    select a from (values
      ('CDO','m-passalacqua'), ('AJ','m-illesca'), ('PER','m-perez'), ('FIN','m-rodriguez'), ('SEG','m-hector-lopez-calderon'),
      ('PLAN','m-urquieta'), ('OCGR','m-barbara-llancavil-cortez'), ('CGA','m-veliz'), ('CTO','m-rodrigo-oyarce-jara'),
      ('VF','m-ramirez'), ('HAB','m-martinez'), ('REC','m-francia-mundaca-toledo'), ('CRA','m-ariel-martinez-quezada'),
      ('COEM','m-acuna'), ('JI','m-hermosilla'), ('ASI','m-vergara'), ('LOG','m-carlos-chavez-jimenez'), ('MANT','m-cid'),
      ('ITO','m-fabian-torres-rivera'),
      ('CRA','m-francia-mundaca-toledo'), ('COEM','m-francia-mundaca-toledo'), ('JI','m-vergara')
    ) v(a, j) where j = public.my_member_id()) x
$$;
create or replace function public.jefe_seccion_de(p_member text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.members m where m.id = p_member
    and public.area_estricta(coalesce(m.parte_unit, m.unit)) = any (public.mis_areas_jefe()))
$$;
grant execute on function public.mis_areas_jefe() to authenticated;
grant execute on function public.jefe_seccion_de(text) to authenticated;

drop policy if exists parte_seccion on public.parte_fuerza;
create policy parte_seccion on public.parte_fuerza for all to authenticated
  using (public.jefe_seccion_de(member_id)) with check (public.jefe_seccion_de(member_id));
drop policy if exists novedades_seccion on public.novedades;
create policy novedades_seccion on public.novedades for all to authenticated
  using (public.jefe_seccion_de(member_id)) with check (public.jefe_seccion_de(member_id));
notify pgrst, 'reload schema';
-- Mural: todos publican; cada uno borra lo suyo; solo el Cdte fija
alter table public.posts add column if not exists autor text references public.members(id) on delete set null;
drop policy if exists posts_insert_todos on public.posts;
create policy posts_insert_todos on public.posts for insert to authenticated with check (autor = public.my_member_id() and coalesce(pinned, false) = false);
drop policy if exists posts_delete_propio on public.posts;
create policy posts_delete_propio on public.posts for delete to authenticated using (autor = public.my_member_id());
