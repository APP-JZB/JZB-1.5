-- Hito ZB Arica · datos iniciales (encuadramiento 2.º semestre 2026 y contactos de WhatsApp)
-- Ejecutar DESPUÉS de schema.sql.
insert into public.members (id,name,grado,cargo,unit,unit_order,nivel,phone,reemplazo,wa_name) values
('m-acuna','SOF Ricardo Acuña Pérez','SOF','Jefe de instalación','Club de Oficiales El Morro',20,'C','+56 9 8391 6350','SG1 Carlos Abarca Rojas','Sof Ricardo Acuña Zba'),
('m-alejandra-godoy-pizarro','ECL Alejandra Godoy Pizarro','ECL','Manipulador de alimentos','Jardín Infantil Soldadito de Plomo',16,'C','','ECL Evelyn Rojas Alcayaga',''),
('m-alejandra-zuniga-loncomilla','ECL Alejandra Zúñiga Loncomilla','ECL','Auxiliar técnico en educación de párvulos','Jardín Infantil Soldadito de Plomo',16,'C','','ECL Daniela Vidal Montora',''),
('m-alejandro-garrido-caipa','SG1 Alejandro Garrido Caipa','SG1','Bodeguero','Club de Oficiales El Morro',20,'C','+56 9 6356 2181','Conforme lo disponga el Jefe de Instalación','Sg1 Garrido Zba'),
('m-alvaro-zuniga-serey','SOF Álvaro Zúñiga Serey','SOF','Técnico administración de personal','Oficina de Personal',6,'B','+56 9 7727 6051','SOF Edgardo Pérez Gaete','Sof Alvaro Zuñiga Zba'),
('m-andrea-pena-iribarren','ECL Andrea Peña Iribarren','ECL','Cajero','Centro Recreacional Arica',19,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-andres-palma-lopez','SG2 Andrés Palma López','SG2','Albañil','Sección Mantenimiento de Infraestructura (Sección de Apoyo)',21,'C','+56 9 9231 7388','CB2 Juan Sepúlveda Salas','Sg2 Palma Zba'),
('m-ariel-martinez-quezada','SOF Ariel Martínez Quezada','SOF','Supervisor de operaciones (responsable CRA)','Centro Recreacional Arica',19,'C','+56 9 4174 8424','SG1 Juan León Becerra','Sg1 Martinez CRA Ojitos De Piscina'),
('m-azocar','SOF Juan Azócar Olivares','SOF','Jefe de plana mayor','Comando ZB Arica',0,'A','+56 9 9643 6213','SG1 Juan Cortés Espinoza','Sof Azocar Zba'),
('m-barbara-llancavil-cortez','CB1 Bárbara Llancavil Cortéz','CB1','Encargada OCGR · PRYMA · delegada de procesos ZB Arica','Oficina Control de Gestión y Riesgo',1,'A','+56 9 6909 5145','SG1 Roberto Urquieta Rivera','Sg2 Llancavil Zba'),
('m-carlos-abarca-rojas','SG1 Carlos Abarca Rojas','SG1','Supervisor de operaciones','Club de Oficiales El Morro',20,'C','+56 9 7717 1423','SOF Ricardo Acuña Pérez','Sof Abarca Zba'),
('m-carlos-brito-bahamondes','ECL Carlos Brito Bahamondes','ECL','Maitre','Club de Oficiales El Morro',20,'C','+56 9 8400 1158','Conforme lo disponga el Jefe de Instalación','Som Carlos Brito Zba'),
('m-carlos-chavez-jimenez','SG1 Carlos Chávez Jiménez','SG1','Jefe de oficina y encargado de inventarios','Oficina de Coordinación Logística',9,'B','+56 9 7432 4533','SG1 Victor Miranda Poblete','Sof Chávez Zba'),
('m-carlos-solis-san-martin','PAC Carlos Solis San Martín','PAC','Maestro de cocina','Club de Oficiales El Morro',20,'C','+56 9 6344 6512','Conforme lo disponga el Jefe de Instalación','Maestro Solis Zba'),
('m-carmen-olivares-galleguillos','PAC Carmen Olivares Galleguillos','PAC','Auxiliar de aseo','Centro Recreacional Arica',19,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-catherine-garrido-vergara','PAC Catherine Garrido Vergara','PAC','Auxiliar técnico en educación de párvulos','Jardín Infantil Soldadito de Plomo',16,'C','','ECL Alejandra Zúñiga Loncomilla',''),
('m-cerda','TCL Sergio Cerda Larrañaga','TCL','Comandante Zona de Bienestar','Comando ZB Arica',0,'A','','MAY Leonardo Passalacqua Masafierro',''),
('m-cheryl-alfaro-bermudez','ECL Cheryl Alfaro Bermudez','ECL','Recepcionista','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-christian-del-valle-gutierrez','PAC Christian del Valle Gutierrez','PAC','Chef','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-cid','SG1 Alexis Cid Garrido','SG1','Jefe de sección y electricista','Sección Mantenimiento de Infraestructura (Sección de Apoyo)',21,'C','+56 9 5892 7979','SG2 Andrés Palma López','Sg1 Cid Zba Arica'),
('m-constanza-bermejo-perez','ECL Constanza Bermejo Pérez','ECL','Educadora de párvulos','Jardín Infantil Soldadito de Plomo',16,'C','','PAC Melissa Cortes Candia',''),
('m-cortes','SG1 Juan Cortés Espinoza','SG1','Registrador y estafeta','Registratura',3,'A','+56 9 5409 0908','SOF Juan Azócar Olivares','Sg1 Cortes Zb Arica'),
('m-daniela-vidal-montora','ECL Daniela Vidal Montora','ECL','Auxiliar técnico en educación de párvulos','Jardín Infantil Soldadito de Plomo',16,'C','','ECL Nicole Rebolledo Castillo',''),
('m-diego-collao-choque','CB1 Diego Collao Choque','CB1','Auxiliar administrativo','Sección Habitabilidad',14,'C','+56 9 8610 6963','SOF Luis Martínez García','CB1 Collao Zb Arica'),
('m-dina-mamani-alarcon','PAH Dina Mamani Alarcón','PAH','JISP','Jardín Infantil Soldadito de Plomo',16,'C','','Sin reemplazo (característica del contrato)',''),
('m-domingo-aguilera-fernandez','PAJ Domingo Aguilera Fernández','PAJ','Garzón','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-domingo-munoz-ordenes','PAJ Domingo Muñóz Órdenes','PAJ','Auxiliar de aseo','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-ester-baluarte-arancibia','PAC Ester Baluarte Arancibia','PAC','Maestro de cocina','Centro Recreacional Arica',19,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-ester-ruiz-huanca','PAC Ester Ruiz Huanca','PAC','Camarera','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-evelyn-rojas-alcayaga','ECL Evelyn Rojas Alcayaga','ECL','Manipulador de alimentos','Jardín Infantil Soldadito de Plomo',16,'C','','ECL Alejandra Godoy Pizarro',''),
('m-fabian-torres-rivera','PAH Fabián Torres Rivera','PAH','ITO, dependencia funcional del Cdo. y Grupo Pers. (honorario)','Inspección Técnica de Obras (ITO)',4,'A','+56 9 6660 6482','Sin reemplazo (característica del contrato)','Fabian Torres ITO Zba'),
('m-francia-mundaca-toledo','MAY Francia Mundaca Toledo','MAY','Jefe sección recreacional','Sección Recreacional',18,'C','','MAY Leonardo Passalacqua Masafierro',''),
('m-gabriela-bermudez-tudela','PAH Gabriela Bermúdez Tudela','PAH','JISP','Jardín Infantil Soldadito de Plomo',16,'C','','Sin reemplazo (característica del contrato)',''),
('m-gabriela-castro-ramos','PAC Gabriela Castro Ramos','PAC','Técnico en administración de finanzas','Sección Habitacional',13,'C','+56 9 4795 4940','SOF Luis Ramírez Contreras','Gaby Viviendas Fiscales'),
('m-geldy-copa-quenaya','PAJ Geldy Copa Quenaya','PAJ','Garzón','Centro Recreacional Arica',19,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-gladys-claros-ayala','PAJ Gladys Claros Ayala','PAJ','Camarera','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-hector-lopez-calderon','ECP Héctor López Calderon','ECP','Administrador red ZB Arica','SICE',12,'B','','SOF Juan Azócar Olivares',''),
('m-hermosilla','PAC Ana Hermosilla Burgos','PAC','Directora JI','Jardín Infantil Soldadito de Plomo',16,'C','','PAC Melissa Cortes Candia',''),
('m-illesca','ECL Carolina Illesca Carvajal','ECL','Asesora jurídica','Asesoría Jurídica',2,'A','+56 9 8258 5753','Asesor jurídico de la ZB Iquique','Carolina Asesora Jurídica Zba'),
('m-isaac-gonzalez-tapia','PAJ Isaac González Tapia','PAJ','Carpintero','Sección Mantenimiento de Infraestructura (Sección de Apoyo)',21,'C','+56 9 3100 9841','CB2 Juan Sepúlveda Salas','González Carpintero'),
('m-isabel-ormeno-valenzuela','PAJ Isabel Ormeño Valenzuela','PAJ','Centro costo JISP','Sección Asistencial',15,'C','+56 9 7230 3768','PAC Ana Hermosilla Burgos','Isabel Jardín Soldadito De Plomo'),
('m-isasi-acuna-contreras','CB2 Isasi Acuña Contreras','CB2','Garzón','Club de Oficiales El Morro',20,'C','','CB1 Luis Correa Pinto',''),
('m-johan-riquelme-pozo','ECL Johan Riquelme Pozo','ECL','Recepcionista','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-jose-ceballos-gallardo','PAJ José Ceballos Gallardo','PAJ','Auxiliar mantención jardines y piscina','Centro Recreacional Arica',19,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-juan-leon-becerra','SG1 Juan León Becerra','SG1','Operador sistema EPOS','Centro Recreacional Arica',19,'C','+56 9 5781 6047','SOF Ariel Martínez Quezada','Sof León Zba'),
('m-juan-sepulveda-salas','CB2 Juan Sepúlveda Salas','CB2','Gasfiter','Sección Mantenimiento de Infraestructura (Sección de Apoyo)',21,'C','+56 9 6460 5124','SG2 Andrés Palma López','Cb2 Juan Sepúlveda Salas Gasfiter Zba'),
('m-katherine-perez-perez','PAH Katherine Pérez Pérez','PAH','JISP','Jardín Infantil Soldadito de Plomo',16,'C','','Sin reemplazo (característica del contrato)',''),
('m-luis-correa-pinto','CB1 Luis Correa Pinto','CB1','Garzón','Club de Oficiales El Morro',20,'C','+56 9 5182 2522','CB2 Isasi Acuña Contreras','Cb1 Correa Zba'),
('m-luis-diaz-loayza','PAJ Luis Díaz Loayza','PAJ','Auxiliar mantención jardines y piscina','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-luis-nunez-rivera','SOF Luis Núñez Rivera','SOF','Contador general','Oficina de Finanzas',10,'B','+56 9 6473 2539','ECP Roberto Sandoval Corvacho','Sof Núñez Zbarica'),
('m-magdalena-san-martin-tello','PAH Magdalena San Martín Tello','PAH','Auxiliar administrativo','Sección Habitacional',13,'C','','Sin reemplazo (característica del contrato)',''),
('m-maria-diaz-ortiz','PAC María Díaz Ortíz','PAC','Auxiliar de aseo','Sección Habitabilidad',14,'C','','ECL Teresa Barrientos Oyarzo',''),
('m-maria-espinoza-espinoza','PAJ María Espinoza Espinoza','PAJ','Garzón','Centro Recreacional Arica',19,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-maria-torres-mellado','PAJ María Torres Mellado','PAJ','Camarera','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-mario-astudillo-munoz','PAJ Mario Astudillo Muñóz','PAJ','Auxiliar mantención jardines y piscina','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-maritza-vascope-blanco','PAJ Maritza Vascope Blanco','PAJ','Camarera','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-martinez','SOF Luis Martínez García','SOF','Jefe sección','Sección Habitabilidad',14,'C','+56 9 6362 7704','CB1 Diego Collao Choque','Sof Martínez Zba'),
('m-mauricio-rodriguez-tapia','PAH Mauricio Rodríguez Tapia','PAH','Administrador villa militar','Sección Habitacional',13,'C','','Sin reemplazo (característica del contrato)',''),
('m-melissa-cortes-candia','PAC Melissa Cortes Candia','PAC','Educadora de párvulos','Jardín Infantil Soldadito de Plomo',16,'C','','PAC Ana Hermosilla Burgos',''),
('m-mireya-melo-torres','PAJ Mireya Melo Torres','PAJ','Auxiliar de aseo','Sección Habitabilidad',14,'C','','ECL Patricia Araya Aliaga',''),
('m-monica-del-pila-flores-elgueta','PAH Mónica del Pila Flores Elgueta','PAH','JISP','Jardín Infantil Soldadito de Plomo',16,'C','','Sin reemplazo (característica del contrato)',''),
('m-nicol-maita-ayca','PAH Nicol Maita Ayca','PAH','JISP','Jardín Infantil Soldadito de Plomo',16,'C','','Sin reemplazo (característica del contrato)',''),
('m-nicole-rebolledo-castillo','ECL Nicole Rebolledo Castillo','ECL','Auxiliar técnico en educación de párvulos','Jardín Infantil Soldadito de Plomo',16,'C','','PAC Catherine Garrido Vergara',''),
('m-norma-oyarzun-martinez','CB1 Norma Oyarzún Martínez','CB1','Operador SIFIE','Oficina de Finanzas',10,'B','+56 9 7552 3035','SG2 Rocío Espiñeira Cárdenas','Cb1 Norma Oyarzun Zba'),
('m-oscar-delgado-puebla','PAH Oscar Delgado Puebla','PAH','Auxiliar administrativo','Sección Habitacional',13,'C','','Sin reemplazo (característica del contrato)',''),
('m-pablo-sila-sagardia','SOF Pablo Sila Sagardia','SOF','Encargado de costos','Centro Recreacional Arica',19,'C','','SOF Ariel Martínez Quezada',''),
('m-passalacqua','MAY Leonardo Passalacqua Masafierro','MAY','Jefe administrativo','Jefatura Administrativa',5,'B','+56 9 8632 6616','STE Sebastián Rodríguez Vargas','.May Passacalqua'),
('m-patricia-araya-aliaga','ECL Patricia Araya Aliaga','ECL','Auxiliar de aseo','Sección Habitabilidad',14,'C','','PAC María Díaz Ortíz',''),
('m-patricia-calderon-huerta','PAJ Patricia Calderón Huerta','PAJ','Auxiliar lavandería','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-perez','SOF Edgardo Pérez Gaete','SOF','Técnico administración de personal','Oficina de Personal',6,'B','+56 9 9588 9305','SOF Álvaro Zúñiga Serey','Sof Edgardo Pérez Gaete Zba'),
('m-priscila-general-villegas','SG2 Priscila General Villegas','SG2','Operador de mercado público','Centro de Gestión de Adquisiciones',11,'B','+56 9 8800 2730','SOF Ángel Véliz Valladares','Sg1 Priscila General Villegas Zba'),
('m-ramirez','SOF Luis Ramírez Contreras','SOF','Jefe sección','Sección Habitacional',13,'C','+56 9 8818 8972','SG1 Carlos Chávez Jiménez','Sof Ramírez Zb Arica'),
('m-roberto-sandoval-corvacho','ECP Roberto Sandoval Corvacho','ECP','Asesor financiero','Oficina de Finanzas',10,'B','+56 9 7692 7378','STE Sebastián Rodríguez Vargas','Roberto Finanzas Zba'),
('m-rocio-espineira-cardenas','SG2 Rocío Espiñeira Cárdenas','SG2','Revisor y analista contable','Oficina de Finanzas',10,'B','+56 9 2637 7535','CB1 Norma Oyarzún Martínez','Sg2 Rocio Espiñera Zba'),
('m-rodrigo-oyarce-jara','SG1 Rodrigo Oyarce Jara','SG1','Administrador de contratos','Centro de Gestión de Adquisiciones',11,'B','+56 9 3585 6606','SOF Ángel Véliz Valladares','Sof rodrigo Oyarce Zba'),
('m-rodriguez','STE Sebastián Rodríguez Vargas','STE','Oficial de finanzas','Oficina de Finanzas',10,'B','+56 9 3214 2135','SOF Luis Núñez Rivera','Ste Sebastian Rodriguez Hab 317 Coem'),
('m-rosa-fuentes-godoy','ECL Rosa Fuentes Godoy','ECL','Auxiliar de aseo','Centro Recreacional Arica',19,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-sandra-bustamante-nunez','PAJ Sandra Bustamante Núñez','PAJ','Gobernanta','Club de Oficiales El Morro',20,'C','','Conforme lo disponga el Jefe de Instalación',''),
('m-solange-barraza-alba','ECL Solange Barraza Alba','ECL','Auxiliar de aseo y mantenimiento','Jardín Infantil Soldadito de Plomo',16,'C','','Coordinado por la directora y jefe administrativo',''),
('m-teresa-barrientos-oyarzo','ECL Teresa Barrientos Oyarzo','ECL','Auxiliar de aseo','Sección Habitabilidad',14,'C','','PAJ Mireya Melo Torres',''),
('m-urquieta','SG1 Roberto Urquieta Rivera','SG1','Titular Oficina de Planificación · apoyo secundario OCGR','Oficina de Planificación',1,'A','+56 9 5430 4491','SOF Juan Azócar Olivares','Sof Roberto Urquieta Zba'),
('m-veliz','SOF Ángel Véliz Valladares','SOF','Supervisor de mercado público y contratos','Centro de Gestión de Adquisiciones',11,'B','+56 9 2397 5544','SG2 Priscila General Villegas','Sof Véliz Zba'),
('m-vergara','SOF Miguel Vergara Acuña','SOF','Jefe sección asistencial','Sección Asistencial',15,'C','+56 9 2938 7895','SOF Ricardo Acuña Pérez','Sof Vergara Zba 1'),
('m-victor-miranda-poblete','SG1 Victor Miranda Poblete','SG1','Técnico administración de finanzas','Club de Oficiales El Morro',20,'C','+56 9 6236 7951','SG1 Carlos Abarca Rojas','Sg1 Miranda Zba'),
('m-viviana-urrutia-salinas','PAC Viviana Urrutia Salinas','PAC','Técnico administración de personal','Oficina de Personal',6,'B','+56 9 6313 5113','SOF Álvaro Zúñiga Serey','Viviana Zb Arica'),
('w-cb1-cantingari-zbarica','Cb1 Cantingari','','','Otros contactos (WhatsApp)',90,'X','+56 9 3211 8077','','Cb1 Cantingari Zbarica'),
('w-lo-lo-rodriguez-zba','Lo Lo Rodríguez','','','Otros contactos (WhatsApp)',90,'X','+56 9 5300 0787','','Lo Lo Rodríguez, Zba'),
('w-pac-lopez-zba','Pac López','','','Otros contactos (WhatsApp)',90,'X','+56 9 6673 1066','','Pac López Zba'),
('w-sg-1ro-silva','Sg 1ro Silva','','','Otros contactos (WhatsApp)',90,'X','+56 9 4945 9926','','Sg 1ro Silva'),
('w-sof-araya-zba','Sof Araya','','','Otros contactos (WhatsApp)',90,'X','+56 9 7346 6281','','Sof Araya Zba'),
('w-sof-delgado-zb-arica','Sof Delgado','','','Otros contactos (WhatsApp)',90,'X','+56 9 8368 0023','','Sof Delgado Zb Arica'),
('w-sra-isabel-asistente-social-zba','Sra Isabel Asistente Social','','','Otros contactos (WhatsApp)',90,'X','+56 9 4253 3429','','Sra Isabel Asistente Social Zba'),
('w-tia-ana-carolina-soldadito-de-plomo','Tía Ana Carolina Soldadito De Plomo','','','Otros contactos (WhatsApp)',90,'X','+56 9 6178 4223','','Tía Ana Carolina Soldadito De Plomo'),
('w-cap-perez-jaramillo-logistica-zba','Cap Perez Jaramillo Logística','','','Otros contactos (WhatsApp)',90,'X','+56 9 5708 6045','','Cap Perez Jaramillo Logística Zba'),
('w-d-apolonio-registrador-zba','D Apolonio Registrador','','','Otros contactos (WhatsApp)',90,'X','+56 9 5524 0642','','D Apolonio Registrador Zba'),
('w-martin-andrade-sistema-epos-zba','Martin Andrade Sistema Epos','','','Otros contactos (WhatsApp)',90,'X','+56 9 4961 5545','','Martin Andrade Sistema Epos Zba'),
('w-may-nicolas-carrasco-zb-arica','May Nicolas Carrasco','','','Otros contactos (WhatsApp)',90,'X','+56 9 8292 7611','','May Nicolas Carrasco Zb Arica'),
('w-sepulveda-zba','Sepúlveda','','','Otros contactos (WhatsApp)',90,'X','+56 9 8249 1589','','Sepúlveda Zba'),
('w-sg1ro-loza-zba','Sg1ro Loza','','','Otros contactos (WhatsApp)',90,'X','+56 9 4418 9225','','Sg1ro Loza Zba'),
('w-sof-acuna-zba','Sof Acuña','','','Otros contactos (WhatsApp)',90,'X','+56 9 2755 0862','','Sof Acuña Zba'),
('w-sof-mauricio-estrada-zb-arica','Sof MAURICIO ESTRADA','','','Otros contactos (WhatsApp)',90,'X','+56 9 9397 9027','','Sof MAURICIO ESTRADA Zb Arica'),
('w-telefono-fiscal-zbarica','Teléfono Fiscal','','','Otros contactos (WhatsApp)',90,'X','+56 9 7298 2810','','Teléfono Fiscal Zbarica'),
('w-hugo-morel-rodriguez-empresa-jardines-zba','Hugo Morel Rodriguez Empresa Jardines','','','Otros contactos (WhatsApp)',90,'X','+56 9 9072 6868','','Hugo Morel Rodriguez Empresa Jardines Zba'),
('w-sin-nombre-grupo-coordinacion-zona-1447','Sin nombre (grupo Coordinación zona)','','','Otros contactos (WhatsApp)',90,'X','+56 9 7217 1447','','Sin nombre (grupo Coordinación zona)'),
('w-sin-nombre-grupo-coordinacion-zona-6719','Sin nombre (grupo Coordinación zona)','','','Otros contactos (WhatsApp)',90,'X','+56 9 7773 6719','','Sin nombre (grupo Coordinación zona)')
on conflict (id) do update set name=excluded.name, grado=excluded.grado, cargo=excluded.cargo, unit=excluded.unit, unit_order=excluded.unit_order, nivel=excluded.nivel, phone=excluded.phone, reemplazo=excluded.reemplazo, wa_name=excluded.wa_name;
update public.members set reemplazo_id='m-carlos-abarca-rojas' where id='m-acuna';
update public.members set reemplazo_id='m-evelyn-rojas-alcayaga' where id='m-alejandra-godoy-pizarro';
update public.members set reemplazo_id='m-daniela-vidal-montora' where id='m-alejandra-zuniga-loncomilla';
update public.members set reemplazo_id='m-perez' where id='m-alvaro-zuniga-serey';
update public.members set reemplazo_id='m-juan-sepulveda-salas' where id='m-andres-palma-lopez';
update public.members set reemplazo_id='m-juan-leon-becerra' where id='m-ariel-martinez-quezada';
update public.members set reemplazo_id='m-cortes' where id='m-azocar';
update public.members set reemplazo_id='m-urquieta' where id='m-barbara-llancavil-cortez';
update public.members set reemplazo_id='m-acuna' where id='m-carlos-abarca-rojas';
update public.members set reemplazo_id='m-victor-miranda-poblete' where id='m-carlos-chavez-jimenez';
update public.members set reemplazo_id='m-alejandra-zuniga-loncomilla' where id='m-catherine-garrido-vergara';
update public.members set reemplazo_id='m-passalacqua' where id='m-cerda';
update public.members set reemplazo_id='m-andres-palma-lopez' where id='m-cid';
update public.members set reemplazo_id='m-melissa-cortes-candia' where id='m-constanza-bermejo-perez';
update public.members set reemplazo_id='m-azocar' where id='m-cortes';
update public.members set reemplazo_id='m-nicole-rebolledo-castillo' where id='m-daniela-vidal-montora';
update public.members set reemplazo_id='m-martinez' where id='m-diego-collao-choque';
update public.members set reemplazo_id='m-alejandra-godoy-pizarro' where id='m-evelyn-rojas-alcayaga';
update public.members set reemplazo_id='m-passalacqua' where id='m-francia-mundaca-toledo';
update public.members set reemplazo_id='m-ramirez' where id='m-gabriela-castro-ramos';
update public.members set reemplazo_id='m-azocar' where id='m-hector-lopez-calderon';
update public.members set reemplazo_id='m-melissa-cortes-candia' where id='m-hermosilla';
update public.members set reemplazo_id='m-juan-sepulveda-salas' where id='m-isaac-gonzalez-tapia';
update public.members set reemplazo_id='m-hermosilla' where id='m-isabel-ormeno-valenzuela';
update public.members set reemplazo_id='m-luis-correa-pinto' where id='m-isasi-acuna-contreras';
update public.members set reemplazo_id='m-ariel-martinez-quezada' where id='m-juan-leon-becerra';
update public.members set reemplazo_id='m-andres-palma-lopez' where id='m-juan-sepulveda-salas';
update public.members set reemplazo_id='m-isasi-acuna-contreras' where id='m-luis-correa-pinto';
update public.members set reemplazo_id='m-roberto-sandoval-corvacho' where id='m-luis-nunez-rivera';
update public.members set reemplazo_id='m-teresa-barrientos-oyarzo' where id='m-maria-diaz-ortiz';
update public.members set reemplazo_id='m-diego-collao-choque' where id='m-martinez';
update public.members set reemplazo_id='m-hermosilla' where id='m-melissa-cortes-candia';
update public.members set reemplazo_id='m-patricia-araya-aliaga' where id='m-mireya-melo-torres';
update public.members set reemplazo_id='m-catherine-garrido-vergara' where id='m-nicole-rebolledo-castillo';
update public.members set reemplazo_id='m-rocio-espineira-cardenas' where id='m-norma-oyarzun-martinez';
update public.members set reemplazo_id='m-ariel-martinez-quezada' where id='m-pablo-sila-sagardia';
update public.members set reemplazo_id='m-rodriguez' where id='m-passalacqua';
update public.members set reemplazo_id='m-maria-diaz-ortiz' where id='m-patricia-araya-aliaga';
update public.members set reemplazo_id='m-alvaro-zuniga-serey' where id='m-perez';
update public.members set reemplazo_id='m-veliz' where id='m-priscila-general-villegas';
update public.members set reemplazo_id='m-carlos-chavez-jimenez' where id='m-ramirez';
update public.members set reemplazo_id='m-rodriguez' where id='m-roberto-sandoval-corvacho';
update public.members set reemplazo_id='m-norma-oyarzun-martinez' where id='m-rocio-espineira-cardenas';
update public.members set reemplazo_id='m-veliz' where id='m-rodrigo-oyarce-jara';
update public.members set reemplazo_id='m-luis-nunez-rivera' where id='m-rodriguez';
update public.members set reemplazo_id='m-mireya-melo-torres' where id='m-teresa-barrientos-oyarzo';
update public.members set reemplazo_id='m-azocar' where id='m-urquieta';
update public.members set reemplazo_id='m-priscila-general-villegas' where id='m-veliz';
update public.members set reemplazo_id='m-acuna' where id='m-vergara';
update public.members set reemplazo_id='m-carlos-abarca-rojas' where id='m-victor-miranda-poblete';
update public.members set reemplazo_id='m-alvaro-zuniga-serey' where id='m-viviana-urrutia-salinas';
insert into public.config (key,value) values ('admin_email', '{"email":"sergiocerda22@gmail.com","member_id":"m-cerda"}'::jsonb), ('owners','{}'::jsonb), ('zona', '{"units": [{"unit": "Comando ZB Arica", "nivel": "A"}, {"unit": "Oficina Control de Gestión y Riesgo", "nivel": "A"}, {"unit": "Asesoría Jurídica", "nivel": "A"}, {"unit": "Registratura", "nivel": "A"}, {"unit": "Inspección Técnica de Obras (ITO)", "nivel": "A"}, {"unit": "Jefatura Administrativa", "nivel": "B"}, {"unit": "Oficina de Personal", "nivel": "B"}, {"unit": "Oficina de Seguridad", "nivel": "B"}, {"unit": "Oficina de Planificación", "nivel": "B"}, {"unit": "Oficina de Coordinación Logística", "nivel": "B"}, {"unit": "Oficina de Finanzas", "nivel": "B"}, {"unit": "Centro de Gestión de Adquisiciones", "nivel": "B"}, {"unit": "SICE", "nivel": "B"}, {"unit": "Sección Habitacional", "nivel": "C"}, {"unit": "Sección Habitabilidad", "nivel": "C"}, {"unit": "Sección Asistencial", "nivel": "C"}, {"unit": "Jardín Infantil Soldadito de Plomo", "nivel": "C"}, {"unit": "Área Convenios", "nivel": "C"}, {"unit": "Sección Recreacional", "nivel": "C"}, {"unit": "Centro Recreacional Arica", "nivel": "C"}, {"unit": "Club de Oficiales El Morro", "nivel": "C"}, {"unit": "Sección Mantenimiento de Infraestructura (Sección de Apoyo)", "nivel": "C"}], "cc": [{"codigo": "1100080411", "centro": "FPAF ZB Plana Mayor", "responsable": "SOF Álvaro Zúñiga Serey"}, {"codigo": "1100080212", "centro": "FPAF Cine Tacora", "responsable": "CB1 Diego Collao Choque"}, {"codigo": "1100080412", "centro": "Proyectos", "responsable": "SG1 Carlos Chávez Jiménez"}, {"codigo": "1100080210", "centro": "HABITACIONAL Mantenimiento", "responsable": "SOF Luis Ramírez Contreras"}, {"codigo": "1100080450", "centro": "HABITACIONAL Func Administrativo", "responsable": "SOF Luis Ramírez Contreras"}, {"codigo": "1100080279", "centro": "HABITACIONAL Gastos Comunes", "responsable": "SOF Álvaro Zúñiga Serey"}, {"codigo": "1100080288", "centro": "HABITABILIDAD Mantenimiento", "responsable": "SOF Luis Martínez García"}, {"codigo": "1100080210", "centro": "HABITABILIDAD Func Administrativo", "responsable": "SOF Luis Martínez García"}, {"codigo": "1100080117", "centro": "RECREACIONAL \"Arica\"", "responsable": "SOF Ariel Martínez Quezada"}, {"codigo": "1100080202", "centro": "RECREACIONAL \"El Morro\"", "responsable": "SG1 Victor Miranda Poblete"}, {"codigo": "1100080209", "centro": "ASISTENCIAL \"El Soldadito de Plomo\"", "responsable": "PAJ Isabel Ormeño Valenzuela"}]}'::jsonb) on conflict (key) do update set value=excluded.value;
