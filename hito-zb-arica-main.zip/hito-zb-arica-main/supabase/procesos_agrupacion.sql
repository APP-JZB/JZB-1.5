-- Base de agrupación de tareas + propuesta de procesos (pestaña "Procesos").
-- Solo la ven: Cdte (m-cerda), Bárbara Llancavil, Viviana Urrutia y SOF Urquieta. Las tablas no tienen políticas: se accede solo por funciones.
create or replace function public.puede_ver_procesos() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.my_member_id() in ('m-cerda','m-barbara-llancavil-cortez','m-viviana-urrutia-salinas','m-urquieta'), false)
$$;
grant execute on function public.puede_ver_procesos() to authenticated;

create or replace function public.norm_txt(t text) returns text language sql immutable as $$
  select translate(lower(coalesce(t,'')), 'áéíóúüñ', 'aeiouun')
$$;

create table if not exists public.grupos_tareas (
  id uuid primary key default gen_random_uuid(),
  nombre text not null check (length(trim(nombre)) > 0),
  palabras text[] not null check (cardinality(palabras) > 0),
  estado text not null default 'observando' check (estado in ('observando','adoptado','descartado')),
  notas text default '',
  creado_por text references public.members(id) on delete set null,
  created_at timestamptz not null default now()
);
create table if not exists public.tarea_registro (
  task_id uuid primary key,
  titulo text not null, area text, proc text, etapas text[] default '{}',
  responsable text, creada timestamptz, plazo timestamptz, cumplida timestamptz,
  hecha boolean not null default false, eliminada boolean not null default false,
  grupo_id uuid references public.grupos_tareas(id) on delete set null,
  grupo_manual boolean not null default false,
  actualizado timestamptz not null default now()
);
create index if not exists tarea_registro_grupo_idx on public.tarea_registro(grupo_id);
alter table public.grupos_tareas enable row level security;
alter table public.tarea_registro enable row level security;

create or replace function public.grupo_para(p_titulo text) returns uuid
language sql stable security definer set search_path = public as $$
  select g.id from public.grupos_tareas g
  where not exists (select 1 from unnest(g.palabras) p where position(public.norm_txt(p) in public.norm_txt(p_titulo)) = 0)
  order by cardinality(g.palabras) desc, g.created_at limit 1
$$;

-- Registro histórico: sobrevive aunque la tarea se borre. Nunca debe bloquear la escritura de tareas.
create or replace function public.trg_registro_tarea() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  begin
    if tg_op = 'DELETE' then
      update public.tarea_registro set eliminada = true, actualizado = now() where task_id = old.id;
      return old;
    end if;
    insert into public.tarea_registro as r (task_id, titulo, area, proc, etapas, responsable, creada, plazo, cumplida, hecha, grupo_id)
    values (new.id, new.title, new.area, new.proc,
            coalesce((select array_agg(e->>'n') from jsonb_array_elements(coalesce(new.stages,'[]'::jsonb)) e), '{}'),
            new.member_id, new.created_at, new.due, new.done_at, coalesce(new.done,false), public.grupo_para(new.title))
    on conflict (task_id) do update set titulo = excluded.titulo, area = excluded.area, proc = excluded.proc, etapas = excluded.etapas,
      responsable = excluded.responsable, plazo = excluded.plazo, cumplida = excluded.cumplida, hecha = excluded.hecha, eliminada = false, actualizado = now(),
      grupo_id = case when r.grupo_manual then r.grupo_id else coalesce(public.grupo_para(excluded.titulo), r.grupo_id) end;
  exception when others then null;
  end;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
drop trigger if exists tasks_registro on public.tasks;
create trigger tasks_registro after insert or update or delete on public.tasks for each row execute function public.trg_registro_tarea();

-- Grupos iniciales (ejemplos, editables desde la pestaña)
insert into public.grupos_tareas (nombre, palabras)
select v.n, v.p from (values
  ('Levantamiento TD 2026', array['levantamiento','td']),
  ('Reparación de viviendas fiscales', array['reparacion','vf']),
  ('Plan de tratamiento de riesgos', array['plan','tratamiento'])) v(n, p)
where not exists (select 1 from public.grupos_tareas g where g.nombre = v.n);

-- Carga inicial con las tareas existentes
insert into public.tarea_registro (task_id, titulo, area, proc, etapas, responsable, creada, plazo, cumplida, hecha, grupo_id)
select t.id, t.title, t.area, t.proc, coalesce((select array_agg(e->>'n') from jsonb_array_elements(coalesce(t.stages,'[]'::jsonb)) e), '{}'),
       t.member_id, t.created_at, t.due, t.done_at, coalesce(t.done,false), public.grupo_para(t.title)
from public.tasks t on conflict (task_id) do nothing;

-- Panel: grupos con sus estadísticas + tareas aún sin grupo
create or replace function public.procesos_panel() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare r jsonb;
begin
  if not public.puede_ver_procesos() then raise exception 'Sin acceso'; end if;
  select jsonb_build_object(
    'grupos', coalesce((select jsonb_agg(z.x order by (z.x->>'n')::int desc, z.x->>'nombre') from (
      select jsonb_build_object('id', g.id, 'nombre', g.nombre, 'palabras', g.palabras, 'estado', g.estado, 'notas', g.notas, 'desde', g.created_at,
        'n', s.n, 'abiertas', s.abiertas, 'cumplidas', s.cumplidas, 'a_tiempo', s.a_tiempo, 'dur_mediana', s.dur,
        'primera', s.primera, 'ultima', s.ultima,
        'intervalo', case when s.n > 1 then extract(epoch from (s.ultima - s.primera))/86400/(s.n-1) end,
        'responsables', coalesce(rs.j, '[]'::jsonb), 'etapas', coalesce(et.e, '{}'::text[]), 'proc', pr.proc) x
      from public.grupos_tareas g
      left join lateral (select count(*) n, count(*) filter (where not hecha) abiertas, count(*) filter (where hecha) cumplidas,
          count(*) filter (where hecha and cumplida <= plazo) a_tiempo,
          percentile_cont(0.5) within group (order by extract(epoch from (cumplida - creada))/86400) filter (where hecha and cumplida is not null) dur,
          min(creada) primera, max(creada) ultima
        from public.tarea_registro where grupo_id = g.id and not eliminada) s on true
      left join lateral (select jsonb_agg(jsonb_build_object('id', q.responsable, 'name', m.name, 'n', q.c) order by q.c desc) j
        from (select responsable, count(*) c from public.tarea_registro where grupo_id = g.id and not eliminada and responsable is not null group by 1) q
        left join public.members m on m.id = q.responsable) rs on true
      left join lateral (select etapas e from public.tarea_registro where grupo_id = g.id and not eliminada and cardinality(etapas) > 0 group by etapas order by count(*) desc limit 1) et on true
      left join lateral (select proc from public.tarea_registro where grupo_id = g.id and not eliminada and proc is not null group by proc order by count(*) desc limit 1) pr on true
    ) z), '[]'::jsonb),
    'sin_grupo', coalesce((select jsonb_agg(jsonb_build_object('id', q.task_id, 'titulo', q.titulo, 'area', q.area, 'responsable', m.name, 'plazo', q.plazo) order by q.creada desc)
      from (select * from public.tarea_registro where grupo_id is null and not eliminada order by creada desc limit 300) q
      left join public.members m on m.id = q.responsable), '[]'::jsonb)
  ) into r;
  return r;
end $$;
grant execute on function public.procesos_panel() to authenticated;

create or replace function public.crear_grupo(p_nombre text, p_palabras text[]) returns uuid
language plpgsql security definer set search_path = public as $$
declare pal text[]; gid uuid;
begin
  if not public.puede_ver_procesos() then raise exception 'Sin acceso'; end if;
  pal := coalesce((select array_agg(distinct public.norm_txt(trim(x))) from unnest(p_palabras) x where length(trim(x)) >= 2), '{}');
  if cardinality(pal) = 0 then raise exception 'Indica al menos una palabra clave'; end if;
  insert into public.grupos_tareas (nombre, palabras, creado_por) values (trim(p_nombre), pal, public.my_member_id()) returning id into gid;
  update public.tarea_registro set grupo_id = public.grupo_para(titulo) where grupo_id is null and not grupo_manual;
  return gid;
end $$;
grant execute on function public.crear_grupo(text, text[]) to authenticated;

create or replace function public.mover_tarea_grupo(p_task uuid, p_grupo uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.puede_ver_procesos() then raise exception 'Sin acceso'; end if;
  update public.tarea_registro set grupo_id = p_grupo, grupo_manual = (p_grupo is not null) where task_id = p_task;
end $$;
grant execute on function public.mover_tarea_grupo(uuid, uuid) to authenticated;

create or replace function public.estado_grupo(p_id uuid, p_estado text, p_notas text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.puede_ver_procesos() then raise exception 'Sin acceso'; end if;
  update public.grupos_tareas set estado = p_estado, notas = coalesce(p_notas, notas) where id = p_id;
end $$;
grant execute on function public.estado_grupo(uuid, text, text) to authenticated;

create or replace function public.borrar_grupo(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.puede_ver_procesos() then raise exception 'Sin acceso'; end if;
  delete from public.grupos_tareas where id = p_id;
end $$;
grant execute on function public.borrar_grupo(uuid) to authenticated;

notify pgrst, 'reload schema';
select (select count(*) from public.grupos_tareas) grupos, (select count(*) from public.tarea_registro) registros, (select count(*) from public.tarea_registro where grupo_id is not null) agrupadas;
