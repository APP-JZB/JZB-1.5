-- Dashboard para integrantes autenticados. Conserva RLS; no modifica tareas.
begin;
create or replace function public.hito_dashboard_comandante(p_from timestamptz,p_to timestamptz)
returns jsonb language plpgsql stable security invoker set search_path='' as $$
declare result jsonb;
begin
 if auth.uid() is null or not exists(select 1 from public.members where user_id=auth.uid()) then
  raise exception 'Inicia sesión con una cuenta vinculada a HITO' using errcode='42501';
 end if;
 if p_from is null or p_to is null or p_from>=p_to then raise exception 'Período inválido'; end if;
 with base as (
  select t.*,coalesce(nullif(m.unit,''),'Sin unidad') unit,
   coalesce(m.name,'Sin responsable') responsible,
   (t.done is true and t.done_at<=t.due and not coalesce(t.late,false)) on_time
  from public.tasks t left join public.members m on m.id=t.member_id
  where t.due>=p_from and t.due<p_to
 ), totals as (
  select count(*) total,count(*) filter(where done is true) completed,
   count(*) filter(where done is not true and due<now()) overdue,
   count(*) filter(where done is not true and due>=now() and due<now()+interval '48 hours') soon,
   count(*) filter(where due<=now()) matured,
   count(*) filter(where due<=now() and on_time) on_time,
   round(avg(case when done is true then 100 else greatest(0,least(coalesce(progress,0),100)) end),1) progress_pct
  from base
 ) select jsonb_build_object(
  'as_of',now(),'from',p_from,'to',p_to,
  'metrics',(select to_jsonb(t)||jsonb_build_object('compliance_pct',round(100.0*on_time/nullif(matured,0),1)) from totals t),
  'units',(select coalesce(jsonb_agg(to_jsonb(q) order by q.overdue desc,q.name),'[]'::jsonb) from (
   select unit name,count(*) total,count(*) filter(where done is true) completed,
    count(*) filter(where done is not true and due<now()) overdue,
    round(100.0*count(*) filter(where due<=now() and on_time)/nullif(count(*) filter(where due<=now()),0),1) compliance_pct
   from base group by unit) q),
  'processes',(select coalesce(jsonb_agg(to_jsonb(q) order by q.total desc,q.name),'[]'::jsonb) from (
   select coalesce(nullif(proc,''),'Sin proceso') name,count(*) total,count(*) filter(where done is true) completed
   from base group by coalesce(nullif(proc,''),'Sin proceso')) q),
  'alerts',(select coalesce(jsonb_agg(to_jsonb(q) order by q.due,q.id),'[]'::jsonb) from (
   select id,title,due,responsible,unit,case when due<now() then 'Vencida' else 'Vence en menos de 48 h' end reason
   from base where done is not true and due<now()+interval '48 hours' order by due,id limit 50) q)
 ) into result;
 return result;
end $$;
revoke all on function public.hito_dashboard_comandante(timestamptz,timestamptz) from public,anon,authenticated;
grant execute on function public.hito_dashboard_comandante(timestamptz,timestamptz) to authenticated;
notify pgrst,'reload schema';
commit;
