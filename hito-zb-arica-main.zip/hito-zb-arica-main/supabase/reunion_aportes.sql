-- Aportes a la Reunión de Coordinación: cada jefe de área (y el más antiguo de cada oficina de Comando y
-- Grupo Personal) puede agregar puntos a su área. Solo se agregan: nada de la foto de Hito se borra ni cambia.
create table if not exists public.reunion_aportes (
  id uuid primary key default gen_random_uuid(),
  semana date not null,
  area text not null,
  cuadrante text not null check (cuadrante in ('EJE','DES','POR','CRI')),
  texto text not null check (length(trim(texto)) > 0),
  autor text references public.members(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists reunion_aportes_semana_idx on public.reunion_aportes(semana);

create or replace function public.rango_grado(g text) returns int language sql immutable as $$
  select coalesce(array_position(array['GDB','CRL','TCL','MAY','CAP','TTE','STE','SOM','SOF','SG1','SG2','CB1','CB2','CBO','SLC','ECP','ECL','PAC','PAJ','PAH'], upper(g)), 50)
$$;

create or replace function public.puede_aportar(p_area text) returns boolean
language sql stable security definer set search_path = public as $$
  -- Cdte; los más antiguos de Comando y Grupo Personal (Jefe Administrativo, Jefe de Plana Mayor, SOF Pérez) en todas las áreas;
  -- y cada jefe de área en la suya.
  select public.is_admin()
      or coalesce(public.my_member_id() in ('m-passalacqua','m-azocar','m-perez'), false)
      or coalesce((p_area, public.my_member_id()) in (
           ('CDO','m-passalacqua'), ('AJ','m-illesca'), ('PER','m-perez'), ('FIN','m-rodriguez'), ('SEG','m-hector-lopez-calderon'),
           ('PLAN','m-urquieta'), ('OCGR','m-barbara-llancavil-cortez'), ('CGA','m-veliz'), ('CTO','m-rodrigo-oyarce-jara'),
           ('VF','m-ramirez'), ('HAB','m-martinez'), ('REC','m-francia-mundaca-toledo'), ('CRA','m-ariel-martinez-quezada'),
           ('COEM','m-acuna'), ('JI','m-hermosilla'), ('ASI','m-vergara'), ('LOG','m-carlos-chavez-jimenez'), ('MANT','m-cid'),
           ('ITO','m-fabian-torres-rivera')), false)
$$;
grant execute on function public.puede_aportar(text) to authenticated;

-- Áreas en que la persona puede aportar (para la app)
create or replace function public.mis_areas_aporte() returns text[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(a), '{}') from unnest(array['AJ','CGA','CTO','CDO','PER','SEG','PLAN','OCGR','LOG','FIN','VF','JI','ASI','REC','CRA','COEM','HAB','ITO','MANT']) a
  where public.puede_aportar(a)
$$;
grant execute on function public.mis_areas_aporte() to authenticated;

alter table public.reunion_aportes enable row level security;
drop policy if exists aportes_read on public.reunion_aportes;
create policy aportes_read on public.reunion_aportes for select to authenticated
  using (public.is_admin() or public.es_supervisor() or public.puede_aportar(area));
drop policy if exists aportes_insert on public.reunion_aportes;
create policy aportes_insert on public.reunion_aportes for insert to authenticated
  with check (autor = public.my_member_id() and public.puede_aportar(area));
drop policy if exists aportes_delete on public.reunion_aportes;
create policy aportes_delete on public.reunion_aportes for delete to authenticated
  using (public.is_admin() or autor = public.my_member_id());
grant select, insert, delete on public.reunion_aportes to authenticated;

-- Los jefes que aportan también pueden ver la reunión (la app les muestra solo sus áreas)
drop policy if exists reuniones_read on public.reuniones;
create policy reuniones_read on public.reuniones for select to authenticated
  using (public.is_admin() or public.es_supervisor() or cardinality(public.mis_areas_aporte()) > 0);
notify pgrst, 'reload schema';
select 'ok' estado;
