alter table public.members add column if not exists email text;
update public.members set email = 'sergio.cerda@ejercito.cl' where id = 'm-cerda' and email is null;
