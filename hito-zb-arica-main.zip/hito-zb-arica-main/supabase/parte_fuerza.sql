create table if not exists public.parte_fuerza (
  fecha date not null,
  member_id text not null references public.members(id) on delete cascade,
  forma boolean not null,
  motivo text default '',
  by_member text references public.members(id) on delete set null,
  updated_at timestamptz default now(),
  primary key (fecha, member_id)
);
alter table public.parte_fuerza enable row level security;
drop policy if exists parte_admin on public.parte_fuerza;
create policy parte_admin on public.parte_fuerza for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.parte_fuerza to authenticated;
