-- Glosario de Hito (Mural → Glosario). Lo leen todos; solo el Comandante lo edita desde la app.
-- Claude también lo actualiza con SQL cuando cambia una función de la app.
create table if not exists public.glosario (
  id uuid primary key default gen_random_uuid(),
  termino text not null unique,
  definicion text not null,
  grupo text not null default 'General',
  orden int not null default 100,
  updated_at timestamptz not null default now(),
  updated_by text references public.members(id) on delete set null
);
alter table public.glosario enable row level security;
drop policy if exists glosario_read on public.glosario;
create policy glosario_read on public.glosario for select to authenticated using (true);
drop policy if exists glosario_write on public.glosario;
create policy glosario_write on public.glosario for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.glosario to authenticated;

insert into public.glosario (grupo, orden, termino, definicion) values
-- Tareas
('Tareas', 10, 'Tarea', 'Trabajo concreto con un responsable, un plazo y, si corresponde, etapas y evidencia. Se mide si se cumplió a tiempo.'),
('Tareas', 11, 'Responsable (principal)', 'La persona que debe cumplir la tarea y responde por ella ante el Comandante. Su nota depende de cumplirla a tiempo.'),
('Tareas', 12, 'Responsable secundario (apoyo)', 'Persona que ayuda al responsable y lo puede reemplazar. Ve la tarea y puede registrar avance, pero no reemplaza la responsabilidad del titular.'),
('Tareas', 13, 'Participantes', 'Personas que intervienen en la tarea o en el evento. Reciben los avisos y la ven en su lista.'),
('Tareas', 14, 'Derivar / delegar', 'Pasar la ejecución de una tarea a otra persona. La primera persona elegida queda como ejecutor ("Derivada a") y las demás como responsables adicionales. Si lo hace el Comandante se aplica de inmediato; si lo hace otro integrante queda pendiente de aprobación. En la app "derivar" y "delegar" hoy funcionan igual.'),
('Tareas', 15, 'Escalar (escalamiento)', 'Elevar una tarea al Comandante porque su solución ya no depende del responsable: necesita una decisión, recursos o una gestión de nivel superior. Solo el Comandante la marca; aparece arriba en "Hoy" como "Requieren escalamiento" y se cuenta en Control.'),
('Tareas', 16, 'Solicitud de tarea', 'Trabajo que un integrante le pide a otro. Dentro de la misma área se publica directo; hacia otra área la aprueba primero el Jefe Administrativo y después el Comandante; si va al Jefe Administrativo o al Comandante, ellos la aceptan, modifican o rechazan.'),
('Tareas', 17, 'Etapas y avance', 'Partes en que se divide una tarea. Al marcar etapas el avance (%) se calcula solo; si no tiene etapas, el responsable informa el porcentaje.'),
('Tareas', 18, 'Evidencia', 'El producto que demuestra que la tarea se cumplió: acta, informe, PPT, foto, documento.'),
('Tareas', 19, 'Controla', 'La persona que revisa que la tarea o actividad se cumplió con su evidencia. Por defecto es el Comandante.'),
('Tareas', 20, 'Reemplazo', 'Persona que asume las tareas de un integrante cuando este no está (feriado, comisión, licencia). La tarea se le puede pasar con un toque desde su detalle.'),
('Tareas', 21, 'Notificar', 'Enviar el aviso de una tarea o evento por WhatsApp o correo (Outlook) desde la app. No cambia la tarea, solo avisa.'),
-- Plazos
('Plazos', 30, 'En plazo 😊', 'Tarea abierta que vence en más de 48 horas.'),
('Plazos', 31, 'Próxima a vencer 😐', 'Tarea abierta que vence dentro de las próximas 48 horas.'),
('Plazos', 32, 'Vencida 😟', 'Tarea que pasó su plazo sin cumplirse. El responsable debe presentarse en la oficina del Comandante.'),
('Plazos', 33, 'Prórroga', 'Más plazo para una tarea. Se pide antes del vencimiento, con motivo; el Comandante la aprueba o rechaza. Después del vencimiento ya no se puede pedir.'),
('Plazos', 34, 'Citación / Resolver vencida', 'Cuando una tarea vence, el responsable queda citado a la oficina del Comandante y al Comandante le aparece "Resolver vencida": registra si se presentó y, si corresponde, le da un nuevo plazo. Si no se presenta queda la inasistencia registrada.'),
('Plazos', 35, 'Cumplida a tiempo', 'Tarea marcada como cumplida antes de su plazo. Con prórroga aprobada cuenta la fecha nueva; una tarea resuelta después de una citación cuenta como atrasada.'),
('Plazos', 36, 'Nota', 'Nota = 1,0 + 6,0 × porcentaje de tareas cumplidas a tiempo en el periodo.'),
-- Personas y organización
('Organización', 40, 'Área', 'Oficina o sección a la que pertenece una tarea o una persona (Personal, Finanzas, Habitacional, CRA, Jardín Infantil, etc.). Define el color de la tarea y quién la ve.'),
('Organización', 41, 'Jefe de sección', 'Jefe de un área. Ve las tareas de su área y controla el parte de su gente.'),
('Organización', 42, 'Supervisor', 'Integrante designado que ve toda la Zona en modo consulta, sin poder modificar.'),
('Organización', 43, 'Encuadramiento', 'Lista oficial de integrantes de la Zona con su unidad, cargo y contacto. Es la base del parte y de los permisos.'),
('Organización', 44, 'Plan de enlace', 'Directorio de teléfonos y correos de la Zona. Cada integrante corrige sus propios datos.'),
-- Parte
('Parte', 50, 'Parte de fuerza', 'Registro diario de quién está presente. Cada integrante informa si forma y los jefes lo controlan y lo envían.'),
('Parte', 51, 'Fuerza', 'Total de personas que deben formar ese día.'),
('Parte', 52, 'Forma', 'La persona está presente y disponible.'),
('Parte', 53, 'Novedad', 'Motivo por el que alguien no forma: feriado, permiso, licencia médica, comisión, curso u otro, con fecha desde–hasta.'),
-- Gestión y control
('Gestión', 60, 'TF (Tarea Fundamental)', 'Las grandes funciones de la Zona (TF1 a TF6). Cada TF agrupa procesos; las tareas del día a día se clasifican por área.'),
('Gestión', 61, 'Proceso', 'Secuencia estable de pasos que se repite (por ejemplo, una adquisición o la entrega de una vivienda), con responsable, etapas y riesgos.'),
('Gestión', 62, 'Riesgo', 'Evento que podría impedir cumplir un proceso, evaluado según la matriz CAIGG (probabilidad e impacto).'),
('Gestión', 63, 'Plan de tratamiento', 'Medidas para bajar un riesgo, con responsable y plazo. Cada plan crea su tarea en Hito.'),
('Gestión', 64, 'Actividad periódica', 'Tarea que se repite sola (mensual, trimestral, etc.). La app crea cada ocurrencia 14 días antes, con responsable, quién controla y evidencia.'),
('Gestión', 65, 'Reunión de Coordinación', 'Foto semanal de las tareas que se genera cada jueves a las 17:00, con aportes de los jefes de área y descarga en PowerPoint.'),
('Gestión', 66, 'Centro de costo', 'Cuenta presupuestaria donde se imputa un gasto, según el clasificador. Cada centro tiene un responsable y su saldo disponible.'),
-- Procesos (pestaña)
('Procesos', 70, 'Grupo de tareas', 'Conjunto de tareas parecidas que se reúnen por palabras clave para ver si forman un proceso.'),
('Procesos', 71, 'Observando', 'El grupo se está midiendo. Tras 30 días y al menos 3 tareas, la app propone un proceso.'),
('Procesos', 72, 'Proceso adoptado / descartado', 'Decisión del Comandante sobre la propuesta: adoptarla como proceso de la Zona o descartarla.'),
('Procesos', 73, 'Sugerencia de proceso', 'Propuesta de un integrante con acceso a Procesos (grupo nuevo o proceso). Queda pendiente hasta que el Comandante la aprueba o la rechaza.'),
-- Pantallas
('Pantallas', 80, 'Hoy', 'Pantalla de inicio del Comandante: vencidas, escalamientos, prórrogas pendientes y lo que vence pronto.'),
('Pantallas', 81, 'Carta Gantt', 'Línea de tiempo de las tareas por área, desde su creación hasta su plazo.'),
('Pantallas', 82, 'Mural', 'Avisos de la Zona y este glosario.')
on conflict (termino) do nothing;
notify pgrst, 'reload schema';
select count(*) terminos from public.glosario;
