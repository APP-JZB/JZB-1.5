-- Sincronización con Google Calendar / Outlook: enlace .ics personal y secreto por integrante
-- (autorizado por el Comandante el 10 OCT 2026: acceso por enlace secreto, renovable desde la app)
create table if not exists public.cal_tokens (
  member_id text primary key references public.members(id) on delete cascade,
  token text unique not null default encode(extensions.gen_random_bytes(18), 'hex'),
  created_at timestamptz default now()
);
alter table public.cal_tokens enable row level security;
drop policy if exists cal_tokens_own on public.cal_tokens;
create policy cal_tokens_own on public.cal_tokens for select to authenticated using (member_id = public.my_member_id());

create or replace function public.mi_token_calendario(renovar boolean default false) returns text
language plpgsql security definer set search_path = public, extensions as $$
declare m text := public.my_member_id(); t text;
begin
  if m is null then return null; end if;
  if renovar then delete from public.cal_tokens where member_id = m; end if;
  insert into public.cal_tokens (member_id) values (m) on conflict (member_id) do nothing;
  select token into t from public.cal_tokens where member_id = m;
  return t;
end $$;
revoke all on function public.mi_token_calendario(boolean) from public, anon;
grant execute on function public.mi_token_calendario(boolean) to authenticated;

-- Datos del calendario para un enlace (lo usa la función calendario; sin enlace válido no devuelve nada)
create or replace function public.ics_datos(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare m text; adm boolean;
begin
  if p_token is null or length(p_token) < 20 then return null; end if;
  select c.member_id, (mb.role = 'admin') into m, adm from public.cal_tokens c join public.members mb on mb.id = c.member_id where c.token = p_token;
  if m is null then return null; end if;
  return jsonb_build_object(
    'admin', adm,
    'tasks', coalesce((select jsonb_agg(jsonb_build_object('id', t.id, 'title', t.title, 'due', t.due, 'done', t.done, 'proc', t.proc,
        'progress', t.progress, 'resp', (select name from public.members x where x.id = t.member_id), 'evidencia', t.evidencia,
        'mia', (t.member_id = m or t.apoyo = m or t.delegado = m)))
      from public.tasks t
      where (adm or t.member_id = m or t.apoyo = m or t.delegado = m or t.publico)
        and t.due > now() - interval '45 days'), '[]'::jsonb),
    'events', coalesce((select jsonb_agg(jsonb_build_object('id', e.id, 'title', e.title, 'type', e.type, 'at', e.at, 'detail', e.detail))
      from public.events e where e.at > now() - interval '45 days'), '[]'::jsonb));
end $$;
revoke all on function public.ics_datos(text) from public;
grant execute on function public.ics_datos(text) to anon, authenticated;
select 'ok' estado;
