// Hito ZB Arica · calendario de suscripción (.ics) para Google Calendar y Outlook.
// Acceso solo con el enlace secreto de cada integrante (?t=...). Usa la clave pública: los datos los filtra ics_datos().
import { createClient } from "npm:@supabase/supabase-js@2";

const esc = (s: unknown) => String(s ?? "").replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
const dt = (d: Date) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
const enc = new TextEncoder();
function fold(line: string) {
  if (enc.encode(line).length <= 74) return line;
  const out: string[] = []; let cur = ""; let n = 0;
  for (const ch of line) {
    const b = enc.encode(ch).length;
    if (n + b > 73) { out.push(cur); cur = " " + ch; n = 1 + b; } else { cur += ch; n += b; }
  }
  out.push(cur);
  return out.join("\r\n");
}

Deno.serve(async (req) => {
  const url = new URL(req.url);
  const tk = (url.searchParams.get("t") || "").replace(/\.ics$/, "");
  if (!/^[0-9a-f]{20,64}$/.test(tk)) return new Response("Enlace no válido", { status: 404 });
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { auth: { persistSession: false } });
  const { data, error } = await sb.rpc("ics_datos", { p_token: tk });
  if (error || !data) return new Response("Enlace no válido o renovado", { status: 404 });
  const now = dt(new Date());
  const L: string[] = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//ZB Arica//Hito//ES", "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
    "X-WR-CALNAME:Hito ZB Arica", "X-WR-TIMEZONE:America/Santiago", "X-WR-CALDESC:Plazos y eventos de la app Hito",
    "REFRESH-INTERVAL;VALUE=DURATION:PT1H", "X-PUBLISHED-TTL:PT1H"];
  for (const t of (data.tasks || [])) {
    const end = new Date(t.due); const start = new Date(end.getTime() - 30 * 60000);
    const pre = t.done ? "✓ " : "⏰ ";
    const who = data.admin && !t.mia ? " · " + (t.resp || "") : "";
    L.push("BEGIN:VEVENT", "UID:tarea-" + t.id + "@hito-zb-arica", "DTSTAMP:" + now, "DTSTART:" + dt(start), "DTEND:" + dt(end),
      "SUMMARY:" + esc(pre + "Plazo: " + t.title + who),
      "DESCRIPTION:" + esc("Proceso " + (t.proc || "—") + " · Responsable: " + (t.resp || "—") + " · Avance " + (t.progress ?? 0) + "%" + (t.evidencia ? "\nEvidencia: " + t.evidencia : "") + "\nAbre Hito para actualizar."),
      "CATEGORIES:Hito,Plazo", "TRANSP:TRANSPARENT");
    if (!t.done) L.push("BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:" + esc("Vence: " + t.title), "TRIGGER:-P1D", "END:VALARM");
    L.push("END:VEVENT");
  }
  for (const e of (data.events || [])) {
    const cumple = (e.type || "").toLowerCase() === "cumpleaños" || (e.title || "").startsWith("🎂");
    if (cumple) {
      const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Santiago", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(e.at)).split("-");
      const ymd = parts.join("");
      const next = new Date(Date.UTC(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]) + 1)).toISOString().slice(0, 10).replace(/-/g, "");
      L.push("BEGIN:VEVENT", "UID:evento-" + e.id + "@hito-zb-arica", "DTSTAMP:" + now,
        "DTSTART;VALUE=DATE:" + ymd, "DTEND;VALUE=DATE:" + next,
        "SUMMARY:" + esc((e.type ? e.type + ": " : "") + e.title),
        "DESCRIPTION:" + esc(e.detail || ""), "CATEGORIES:Hito,Cumpleaños",
        "BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:" + esc("Mañana: " + e.title), "TRIGGER:-P1D", "END:VALARM",
        "BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:" + esc("Hoy: " + e.title), "TRIGGER:PT0S", "END:VALARM",
        "END:VEVENT");
    } else {
      const s = new Date(e.at); const en = new Date(s.getTime() + 60 * 60000);
      L.push("BEGIN:VEVENT", "UID:evento-" + e.id + "@hito-zb-arica", "DTSTAMP:" + now, "DTSTART:" + dt(s), "DTEND:" + dt(en),
        "SUMMARY:" + esc((e.type ? e.type + ": " : "") + e.title), "DESCRIPTION:" + esc(e.detail || ""), "CATEGORIES:Hito,Evento", "END:VEVENT");
    }
  }
  L.push("END:VCALENDAR");
  return new Response(L.map(fold).join("\r\n") + "\r\n", {
    headers: { "Content-Type": "text/calendar; charset=utf-8", "Content-Disposition": "inline; filename=hito-zb-arica.ics", "Cache-Control": "max-age=900" },
  });
});
