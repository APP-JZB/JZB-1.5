import { createClient } from "npm:@supabase/supabase-js@2.117.3";

const OWNER = "6c012c39-34a7-40d9-9154-d7ace10606da";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS", "Cache-Control": "no-store" };
const reply = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req: Request) => {
 if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
 if (req.method !== "POST") return reply(405, { error: "Método no permitido" });
 try {
  const authorization = req.headers.get("Authorization") || "";
  if (!authorization.startsWith("Bearer ")) return reply(401, { error: "Inicia sesión nuevamente" });
  const url = Deno.env.get("SUPABASE_URL")!;
  const body = await req.json();
  const service = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false, autoRefreshToken: false } });
  const randomToken = () => Array.from(crypto.getRandomValues(new Uint8Array(32)), b => b.toString(16).padStart(2,"0")).join("");
  if (body.action === "observer_login") {
   if (typeof body.phone !== "string" || typeof body.password !== "string") return reply(400,{error:"Indica teléfono y PIN"});
   const token=randomToken();
   const {data,error}=await service.rpc("hito_observer_login",{p_phone:body.phone,p_password:body.password,p_token:token});
   if(error || data?.error)return reply(400,{error:data?.error||"No se pudo ingresar"});
   return reply(200,{token});
  }
  if (["observer_read","observer_logout","observer_change_password"].includes(body.action)) {
   if(typeof body.token!=="string")return reply(401,{error:"Inicia sesión nuevamente"});
   const action=body.action==="observer_read"?`read_${["month","year","all"].includes(body.period)?body.period:"month"}`:body.action==="observer_logout"?"logout":"change_password";
   const {data,error}=await service.rpc("hito_observer_session",{p_token:body.token,p_action:action,p_password:typeof body.password==="string"?body.password:null});
   if(error)return reply(error.code==="42501"?401:400,{error:error.message||"No se pudo consultar"});
   return reply(200,data);
  }
  const caller = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: authorization } }, auth: { persistSession: false, autoRefreshToken: false } });
  const { data: identity, error: identityError } = await caller.auth.getUser(authorization.slice(7));
  if (identityError || !identity.user) return reply(401, { error: "Sesión inválida" });
  const { data: me, error: memberError } = await caller.from("members").select("id,role").eq("user_id", identity.user.id).single();
  if (memberError || !me) return reply(403, { error: "Cuenta sin acceso a HITO" });
  if (body.action === "change_password") {
   const password = typeof body.password === "string" ? body.password : "";
   if (me.role === "admin" ? password.length < 8 || password.length > 64 : !/^\d{8,64}$/.test(password)) return reply(400, { error: "La clave nueva debe tener entre 8 y 64 caracteres; usa solo dígitos si ingresas con teléfono" });
   if (password === body.temporary_password) return reply(400, { error: "Elige una clave diferente de la temporal" });
   const { error } = await service.auth.admin.updateUserById(identity.user.id, { password, app_metadata: { ...identity.user.app_metadata, hito_password_change_required: false } });
   if (error) return reply(400, { error: "No se pudo cambiar la clave. Usa una clave nueva y reintenta." });
   return reply(200, { ok: true });
  }
  if (identity.user.id !== OWNER || me.role !== "admin") return reply(403, { error: "Solo el Comandante puede restablecer contraseñas" });
  let temporary = "";
  while (temporary.length < 12) for (const b of crypto.getRandomValues(new Uint8Array(32))) { if (b < 250 && temporary.length < 12) temporary += String(b % 10); }
  if (["observer_list","observer_create","observer_activate","observer_deactivate"].includes(body.action) || (body.action==="reset_password" && String(body.member_id).startsWith("obs-"))) {
   const action=body.action==="observer_list"?"list":body.action==="observer_create"?"create":body.action==="observer_activate"?"activate":body.action==="observer_deactivate"?"deactivate":"reset";
   const {data,error}=await service.rpc("hito_observer_manage",{p_action:action,p_data:{id:body.member_id,name:body.name,phone:body.phone,email:body.email,password:temporary}});
   if(error)return reply(400,{error:error.code==="23505"?"Ese teléfono ya tiene una cuenta de observador":error.message});
   return reply(200,action==="list"?{observers:data}:action==="create"||action==="reset"?{ok:true,temporary_password:temporary}:{ok:true});
  }
  if (body.action !== "reset_password") return reply(400, { error: "Acción inválida" });
  if (typeof body.member_id !== "string") return reply(400, { error: "Selecciona un usuario" });
  const { data: target, error: targetError } = await service.from("members").select("id,user_id,role").eq("id", body.member_id).single();
  if (targetError || !target?.user_id) return reply(400, { error: "Esta persona aún no crea su acceso. Debe usar Crear mi acceso." });
  if (target.role === "admin" || target.user_id === OWNER) return reply(400, { error: "Para tu propia cuenta usa Cambiar mi contraseña" });
  const { data: targetIdentity, error: targetIdentityError } = await service.auth.admin.getUserById(target.user_id);
  if (targetIdentityError || !targetIdentity.user) return reply(400, { error: "No se encontró la cuenta" });
  const { error } = await service.auth.admin.updateUserById(target.user_id, { password: temporary, app_metadata: { ...targetIdentity.user.app_metadata, hito_password_change_required: true } });
  if (error) return reply(500, { error: "No se pudo restablecer la contraseña" });
  // La cuenta conserva el mismo UUID, sus tareas y su tipo de acceso.
  return reply(200, { ok: true, temporary_password: temporary });
 } catch {
  return reply(500, { error: "No se pudo procesar la solicitud" });
 }
});
