// Hito ZB Arica · asistente de IA para todos los integrantes (OpenAI).
// Secreto: OPENAI_API_KEY (o "hito"). Modelo opcional: OPENAI_MODEL.
// Usa la sesión del usuario: las reglas RLS de la base se aplican igual que en la app.
// Los cambios que un integrante haga a sus tareas generan un aviso al Comandante (trigger en la base).
import { createClient } from "npm:@supabase/supabase-js@2";

const MODEL = Deno.env.get("OPENAI_MODEL") || "gpt-4.1-mini";
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status, headers: { ...cors, "Content-Type": "application/json" } });
const fn = (name: string, description: string, properties: Record<string, unknown>, required: string[]) =>
  ({ type: "function", function: { name, description, parameters: { type: "object", properties, required } } });

const T_CREAR = fn("crear_tarea", "Crea una tarea. Usa el código de proceso y el id de integrante exactos del contexto. Si quien pide no es el Comandante, la tarea queda a su propio nombre.", {
  title: { type: "string" }, proc: { type: "string", description: "Código del proceso, p. ej. HAT-06" },
  member_id: { type: "string", description: "id del responsable, p. ej. m-ramirez (solo Comandante)" },
  due: { type: "string", description: "Fecha y hora límite ISO 8601 con zona -03:00" },
}, ["title", "proc", "due"]);
const T_PLAZO = fn("cambiar_plazo", "Cambia el plazo de una tarea existente (por id).", { task_id: { type: "string" }, due: { type: "string" } }, ["task_id", "due"]);
const T_AVANCE = fn("actualizar_avance", "Actualiza el avance (0-100) de una tarea o la marca cumplida.", { task_id: { type: "string" }, progress: { type: "number" }, done: { type: "boolean" } }, ["task_id"]);
const T_EVENTO = fn("crear_evento", "Anota un evento en el calendario (no es tarea).", {
  title: { type: "string" }, type: { type: "string", enum: ["Incidente", "Visita", "Reunión", "Novedad", "Otro"] },
  at: { type: "string", description: "ISO 8601 con zona -03:00" }, detail: { type: "string" },
}, ["title", "type", "at"]);
const T_MURAL = fn("publicar_mural", "Publica un aviso en el diario mural (solo Comandante).", {
  title: { type: "string" }, body: { type: "string" }, cat: { type: "string", enum: ["avisos", "turnos", "documentos", "social"] },
}, ["title", "body", "cat"]);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const auth = req.headers.get("Authorization") ?? "";
    const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: auth } }, auth: { persistSession: false },
    });
    const { data: meId } = await sb.rpc("my_member_id");
    if (!meId) return json({ error: "Inicia sesión en Hito para usar el asistente." }, 200);
    const { data: meRow } = await sb.from("members").select("id,name,cargo,unit,role").eq("id", meId).single();
    const admin = meRow?.role === "admin";
    const key = Deno.env.get("OPENAI_API_KEY") || Deno.env.get("hito");
    if (!key) return json({ error: "Falta configurar OPENAI_API_KEY en Supabase (Edge Functions → Secrets)." }, 200);

    const { messages, procs } = await req.json();
    const [{ data: members }, { data: tasks }] = await Promise.all([
      sb.from("members").select("id,name,cargo,unit"),
      sb.from("tasks").select("id,title,proc,area,member_id,apoyo,delegado,participantes,due,progress,done").eq("done", false).order("due").limit(admin ? 200 : 80),
    ]);
    const mine = (tasks || []).filter((t: any) => admin || t.member_id === meId || t.apoyo === meId || t.delegado === meId || (t.participantes || []).includes(meId));
    const now = new Date().toLocaleString("es-CL", { timeZone: "America/Santiago", dateStyle: "full", timeStyle: "short" });
    const system = [
      "Eres el asistente de la app Hito de la Zona de Bienestar \"Arica\" (Ejército de Chile). Responde en español de Chile, breve y concreto.",
      "Ahora es " + now + " (hora de Chile, UTC-03:00).",
      "Usuario: " + meRow?.name + " · " + (meRow?.cargo || "") + " · " + (admin ? "COMANDANTE (puede todo)" : "INTEGRANTE"),
      admin
        ? "Puedes crear tareas para cualquier integrante, cambiar plazos, actualizar avances, anotar eventos y publicar en el mural."
        : "Este integrante solo puede: consultar sus tareas, crear tareas a su propio nombre, actualizar el avance de sus tareas, cambiar plazos de tareas que él creó y anotar eventos. Avísale que cualquier cambio a sus tareas le llega como aviso al Comandante. Para plazos asignados por el Comandante debe pedir prórroga en la app. No reveles tareas de otras personas.",
      "Si el usuario dicta varias tareas en un mensaje, créalas todas. Si falta un dato clave (responsable o plazo) pregunta antes de crear; si dice 'el viernes' sin hora, usa 12:00. Confirma lo que hiciste.",
      "Cuando pidan un cuadro, tabla o informe, entrégalo como tabla en formato markdown (| col | col |) para que puedan descargarlo en Excel, Word o PPT.",
      "PROCESOS (código | TF | nombre | responsable):\n" + (procs || []).map((p: any) => [p.code, p.tf, p.name, p.owner].join(" | ")).join("\n"),
      "INTEGRANTES (id | nombre | cargo | unidad):\n" + (members || []).map((m: any) => [m.id, m.name, m.cargo, m.unit].join(" | ")).join("\n"),
      (admin ? "TAREAS ABIERTAS" : "TAREAS ABIERTAS DEL USUARIO") + " (id | título | proceso | responsable | plazo | avance):\n" +
        mine.map((t: any) => [t.id, t.title, t.proc, t.member_id, t.due, (t.progress || 0) + "%"].join(" | ")).join("\n"),
    ].join("\n\n");

    const tools = admin ? [T_CREAR, T_PLAZO, T_AVANCE, T_EVENTO, T_MURAL] : [T_CREAR, T_PLAZO, T_AVANCE, T_EVENTO];
    const procMap: Record<string, any> = {}; (procs || []).forEach((p: any) => (procMap[p.code] = p));
    const msgs: any[] = [{ role: "system", content: system }].concat(
      (messages || []).slice(-20).filter((m: any) => m.role === "user" || m.role === "assistant").map((m: any) => ({ role: m.role, content: String(m.content) })));
    const actions: string[] = [];

    for (let i = 0; i < 8; i++) {
      const r = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Authorization": "Bearer " + key, "Content-Type": "application/json" },
        body: JSON.stringify({ model: MODEL, messages: msgs, tools, temperature: 0.2 }),
      });
      const j = await r.json();
      if (!r.ok) return json({ error: "IA: " + (j?.error?.message ?? r.status) });
      const msg = j.choices?.[0]?.message;
      if (!msg) return json({ error: "La IA no respondió." });
      msgs.push(msg);
      const calls = msg.tool_calls || [];
      if (!calls.length) return json({ text: msg.content || "Listo.", actions });
      for (const c of calls) {
        let out = "ok";
        let a: any = {};
        try { a = JSON.parse(c.function?.arguments || "{}"); } catch (_) { a = {}; }
        try {
          const name = c.function?.name;
          if (name === "crear_tarea") {
            const p = procMap[a.proc] || procMap["PLAN"];
            if (!p) throw new Error("Proceso desconocido: " + a.proc);
            const row: any = {
              title: a.title, tf: p.tf, proc: p.code, member_id: admin ? (a.member_id || p.owner) : meId, due: a.due,
              stages: (p.stages || []).map((n: string) => ({ n, done: false })), log: [{ t: "creada (asistente IA) por " + meRow?.name, at: Date.now() }],
            };
            if (!admin) row.created_by = meId;
            const { data, error } = await sb.from("tasks").insert(row).select("id").single();
            if (error) throw error;
            out = "Tarea creada id " + data.id; actions.push("Tarea: " + a.title);
          } else if (name === "cambiar_plazo") {
            const { data, error } = await sb.from("tasks").update({ due: a.due }).eq("id", a.task_id).select("id");
            if (error) throw error; if (!data?.length) throw new Error("No tienes permiso para cambiar esa tarea.");
            actions.push("Nuevo plazo: " + a.task_id);
          } else if (name === "actualizar_avance") {
            const upd: any = {}; if (typeof a.progress === "number") upd.progress = Math.max(0, Math.min(100, Math.round(a.progress)));
            if (typeof a.done === "boolean") { upd.done = a.done; upd.done_at = a.done ? new Date().toISOString() : null; if (a.done) upd.progress = 100; }
            const { data, error } = await sb.from("tasks").update(upd).eq("id", a.task_id).select("id");
            if (error) throw error; if (!data?.length) throw new Error("No tienes permiso para cambiar esa tarea.");
            actions.push("Avance actualizado");
          } else if (name === "crear_evento") {
            const { error } = await sb.from("events").insert({ title: a.title, type: a.type, at: a.at, detail: a.detail ?? "", by_member: meId });
            if (error) throw error; actions.push("Evento: " + a.title);
          } else if (name === "publicar_mural" && admin) {
            const { error } = await sb.from("posts").insert({ title: a.title, body: a.body, cat: a.cat });
            if (error) throw error; actions.push("Mural: " + a.title);
          } else out = "Acción no permitida.";
        } catch (e) {
          out = "Error: " + ((e as any).message ?? String(e));
        }
        msgs.push({ role: "tool", tool_call_id: c.id, content: out });
      }
    }
    return json({ text: "Hice varias acciones; revisa la app.", actions });
  } catch (e) {
    return json({ error: (e as Error).message }, 200);
  }
});
