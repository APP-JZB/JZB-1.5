// Hito ZB Arica · copia cada tarea de Hito a la lista de su proceso en ClickUp.
// Secretos necesarios (Edge Functions → Secrets): CLICKUP_TOKEN
// La llama la base de datos (trigger tasks_clickup) con la cabecera x-hito-hook.
import { createClient } from "npm:@supabase/supabase-js@2";

const LISTS: Record<string, string> = {"ADM-CGR":"901329225514","PLAN":"901329225515","DOC":"901329225517","HAT-01":"901329225519","HAT-02":"901329225520","HAT-03":"901329225521","HAT-04":"901329225522","HAT-05":"901329225523","HAT-06":"901329225524","HAB-01":"901329225525","HAB-02":"901329225526","HAB-03":"901329225527","HAB-04":"901329225528","HAB-05":"901329225529","HAB-06":"901329225530","REC-01":"901329225531","REC-02":"901329225532","REC-03":"901329225533","REC-04":"901329225534","REC-05":"901329225538","REC-06":"901329225539","JI-01":"901329225540","JI-02":"901329225541","JI-03":"901329225542","JI-04":"901329225543","JI-05":"901329225544","JI-06":"901329225545","JI-07":"901329225546","CONV":"901329225547","ADM-FIN":"901329225548","ADM-ADQ":"901329225549","ADM-CON":"901329225550","ADM-PER":"901329225551","ADM-LOG":"901329225552"};
const CU = "https://api.clickup.com/api/v2";

const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });

async function cu(method: string, path: string, body?: unknown) {
  const r = await fetch(CU + path, {
    method,
    headers: { Authorization: Deno.env.get("CLICKUP_TOKEN") ?? "", "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const txt = await r.text();
  let j: any = {}; try { j = JSON.parse(txt); } catch { /* vacío */ }
  return { ok: r.ok, status: r.status, j, txt };
}

function fmt(d: string) {
  return new Date(d).toLocaleString("es-CL", { timeZone: "America/Santiago", dateStyle: "short", timeStyle: "short" });
}

Deno.serve(async (req) => {
  try {
    const hook = req.headers.get("x-hito-hook") ?? "";
    const { data: s } = await db.from("secrets").select("value").eq("key", "hook").single();
    if (!s || hook !== s.value) return new Response("no autorizado", { status: 401 });
    if (!Deno.env.get("CLICKUP_TOKEN")) return new Response("falta CLICKUP_TOKEN", { status: 200 });

    const { op, record: t } = await req.json();

    if (op === "DELETE") {
      if (t.clickup_id) await cu("DELETE", "/task/" + t.clickup_id);
      return new Response("ok");
    }

    const { data: m } = t.member_id ? await db.from("members").select("name,cargo").eq("id", t.member_id).single() : { data: null };
    const stages = Array.isArray(t.stages) ? t.stages : [];
    const desc = [
      "**Responsable:** " + (m ? m.name + (m.cargo ? " — " + m.cargo : "") : "Sin asignar"),
      "**Plazo:** " + fmt(t.due),
      "**Avance:** " + (t.progress ?? 0) + "%",
      t.proc ? "**Proceso:** " + t.proc + " · " + t.tf : "",
      stages.length ? "\n**Etapas**\n" + stages.map((x: any) => (x.done ? "- [x] " : "- [ ] ") + x.n).join("\n") : "",
      "\n_Sincronizado desde Hito ZB Arica. Edita la tarea en Hito: los cambios hechos aquí se sobrescriben._",
    ].filter(Boolean).join("\n");
    const body: any = {
      name: t.title,
      markdown_content: desc,
      due_date: new Date(t.due).getTime(),
      due_date_time: true,
    };

    if (!t.clickup_id) {
      const list = LISTS[t.proc] ?? LISTS["ADM-CGR"];
      const r = await cu("POST", "/list/" + list + "/task", body);
      if (!r.ok) return new Response("ClickUp " + r.status + ": " + r.txt, { status: 200 });
      await db.from("tasks").update({ clickup_id: r.j.id }).eq("id", t.id);
      if (t.done) await cu("PUT", "/task/" + r.j.id, { status: "complete" });
      return new Response("creada " + r.j.id);
    }

    const upd: any = { name: body.name, markdown_content: desc, due_date: body.due_date, due_date_time: true };
    let r = await cu("PUT", "/task/" + t.clickup_id, { ...upd, status: t.done ? "complete" : "to do" });
    if (!r.ok) r = await cu("PUT", "/task/" + t.clickup_id, upd); // la lista puede tener otros nombres de estado
    return new Response("actualizada " + r.status);
  } catch (e) {
    return new Response("error: " + (e as Error).message, { status: 200 });
  }
});
