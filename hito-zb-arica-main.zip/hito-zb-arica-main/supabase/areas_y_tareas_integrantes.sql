-- Áreas de trabajo y tareas creadas por integrantes
alter table public.tasks add column if not exists area text;
alter table public.tasks add column if not exists created_by text references public.members(id) on delete set null;

-- Un integrante puede crear tareas propias (quedan a su nombre y marcadas como creadas por él)
create or replace function public.guard_task_insert() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() or auth.uid() is null then return new; end if;
  new.member_id := public.my_member_id();
  new.created_by := public.my_member_id();
  new.done := false; new.done_at := null; new.late := false; new.no_shows := 0;
  return new;
end $$;
drop trigger if exists tasks_guard_insert on public.tasks;
create trigger tasks_guard_insert before insert on public.tasks for each row execute function public.guard_task_insert();

drop policy if exists tasks_insert on public.tasks;
create policy tasks_insert on public.tasks for insert to authenticated
  with check (public.is_admin() or member_id = public.my_member_id());

-- Las tareas que el propio integrante creó las puede editar completas; las asignadas por el Comandante no.
create or replace function public.guard_task_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() or auth.uid() is null then return new; end if;
  if old.created_by is not null and old.created_by = public.my_member_id() then
    new.member_id := old.member_id; new.created_by := old.created_by; new.late := old.late; new.no_shows := old.no_shows;
  else
    new.title := old.title; new.tf := old.tf; new.proc := old.proc; new.member_id := old.member_id; new.area := old.area;
    new.due := old.due; new.late := old.late; new.no_shows := old.no_shows; new.created_at := old.created_at; new.created_by := old.created_by;
  end if;
  if old.done = false and new.done = true then new.done_at := now(); end if;
  if new.done = false then new.done_at := null; end if;
  return new;
end $$;

drop policy if exists tasks_delete on public.tasks;
create policy tasks_delete on public.tasks for delete to authenticated
  using (public.is_admin() or (created_by = public.my_member_id()));

select 'ok' as estado;
