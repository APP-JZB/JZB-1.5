-- Respaldo completo de los datos de Hito en un JSON (solo el Comandante). Excluye enlaces secretos de calendario y la tabla secrets.
-- Uso: select public.respaldo_json();
create or replace function public.respaldo_json() returns jsonb
language plpgsql security definer set search_path = public as $$
declare r record; res jsonb := jsonb_build_object('generado', now(), 'proyecto', 'Hito ZB Arica'); v jsonb;
begin
  if auth.uid() is not null and not public.is_admin() then raise exception 'Solo el Comandante'; end if;
  for r in select table_name from information_schema.tables where table_schema = 'public' and table_type = 'BASE TABLE' and table_name not in ('cal_tokens', 'secrets') order by 1 loop
    execute format('select coalesce(jsonb_agg(to_jsonb(x)), ''[]''::jsonb) from public.%I x', r.table_name) into v;
    res := res || jsonb_build_object(r.table_name, v);
  end loop;
  return res;
end $$;
revoke all on function public.respaldo_json() from public, anon;
grant execute on function public.respaldo_json() to authenticated;
