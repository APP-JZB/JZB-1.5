-- Visibilidad: integrantes ven lo de su organización (área); Jefe Administrativo, SOF Azócar y SG1 Urquieta ven todo;
-- solo el Comandante (rol admin) modifica.
create or replace function public.es_supervisor() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.my_member_id() in ('m-passalacqua','m-azocar','m-urquieta'), false)
$$;
create or replace function public.my_area() returns text
language sql stable security definer set search_path = public as $$
  select case coalesce(m.parte_unit, m.unit)
    when 'Comando ZB Arica' then 'CDO' when 'Jefatura Administrativa' then 'CDO' when 'Registratura' then 'CDO'
    when 'Oficina de Planificación' then 'PLAN' when 'Oficina Control de Gestión y Riesgo' then 'OCGR'
    when 'Asesoría Jurídica' then 'AJ' when 'Oficina de Personal' then 'PER' when 'Oficina de Finanzas' then 'FIN'
    when 'Oficina de Seguridad' then 'SEG' when 'SICE' then 'SEG' when 'Centro de Gestión de Adquisiciones' then 'CGA'
    when 'Inspección Técnica de Obras (ITO)' then 'ITO' when 'Oficina de Coordinación Logística' then 'LOG'
    when 'Sección Mantenimiento de Infraestructura (Sección de Apoyo)' then 'MANT' when 'Sección Habitacional' then 'VF'
    when 'Sección Habitabilidad' then 'HAB' when 'Sección Recreacional' then 'REC' when 'Centro Recreacional Arica' then 'CRA'
    when 'Club de Oficiales El Morro' then 'COEM' when 'Jardín Infantil Soldadito de Plomo' then 'JI'
    when 'Sección Asistencial' then 'ASI' when 'Área Convenios' then 'ASI' end
  from public.members m where m.id = public.my_member_id()
$$;
grant execute on function public.es_supervisor() to authenticated;
grant execute on function public.my_area() to authenticated;

-- Tareas
drop policy if exists tasks_read_sup on public.tasks;
create policy tasks_read_sup on public.tasks for select to authenticated using (public.es_supervisor());
drop policy if exists tasks_read_area on public.tasks;
create policy tasks_read_area on public.tasks for select to authenticated using (area is not null and area = public.my_area());
-- Prórrogas
drop policy if exists prorrogas_read_sup on public.prorrogas;
create policy prorrogas_read_sup on public.prorrogas for select to authenticated using (public.es_supervisor());
-- Riesgos
drop policy if exists ries_read_sup on public.riesgos;
create policy ries_read_sup on public.riesgos for select to authenticated using (public.es_supervisor() or (area is not null and area = public.my_area()));
-- Novedades, parte y avisos
drop policy if exists novedades_read_sup on public.novedades;
create policy novedades_read_sup on public.novedades for select to authenticated using (public.es_supervisor());
drop policy if exists parte_read_sup on public.parte_fuerza;
create policy parte_read_sup on public.parte_fuerza for select to authenticated using (public.es_supervisor());
drop policy if exists avisos_read_sup on public.avisos_admin;
create policy avisos_read_sup on public.avisos_admin for select to authenticated using (public.es_supervisor());

-- Solo el Comandante modifica: SOF Azócar y SG1 Urquieta dejan el rol admin (pasan a consulta total)
update public.members set role = 'member' where id in ('m-azocar', 'm-urquieta');
select id, name, role from public.members where role = 'admin' or id in ('m-azocar','m-urquieta','m-passalacqua');
