-- Parte de fuerza: cada integrante marca solo su propio Sí/No.
-- Ven y modifican el parte completo: Cdte (admin), Jefe Administrativo, Sra. Viviana Urrutia, SOF Pérez y SOF Azócar.
create or replace function public.es_jefe_parte() returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_admin() or coalesce(public.my_member_id() in ('m-passalacqua','m-viviana-urrutia-salinas','m-perez','m-azocar'), false)
$$;
grant execute on function public.es_jefe_parte() to authenticated;

drop policy if exists parte_jefes on public.parte_fuerza;
create policy parte_jefes on public.parte_fuerza for all to authenticated using (public.es_jefe_parte()) with check (public.es_jefe_parte());
drop policy if exists parte_propio_read on public.parte_fuerza;
create policy parte_propio_read on public.parte_fuerza for select to authenticated using (member_id = public.my_member_id());
drop policy if exists parte_propio_insert on public.parte_fuerza;
create policy parte_propio_insert on public.parte_fuerza for insert to authenticated with check (member_id = public.my_member_id() and by_member = public.my_member_id());
drop policy if exists parte_propio_update on public.parte_fuerza;
create policy parte_propio_update on public.parte_fuerza for update to authenticated using (member_id = public.my_member_id()) with check (member_id = public.my_member_id() and by_member = public.my_member_id());
grant select, insert, update on public.parte_fuerza to authenticated;

drop policy if exists novedades_jefes on public.novedades;
create policy novedades_jefes on public.novedades for all to authenticated using (public.es_jefe_parte()) with check (public.es_jefe_parte());
select 'ok' estado;
