-- Perfiles manuales de cargo para Hito ZB Arica
-- Ejecutar en Supabase → SQL Editor → New query → Run.
-- Solo el Comandante y el SOF Edgardo Pérez Gaete (m-perez) pueden crear o editar.

create table if not exists public.position_profiles (
  cargo_key text primary key,
  cargo text not null,
  title text not null,
  sections jsonb not null default '[]'::jsonb check (jsonb_typeof(sections) = 'array'),
  updated_by text not null references public.members(id),
  updated_at timestamptz not null default now()
);

alter table public.position_profiles enable row level security;

drop policy if exists position_profiles_read on public.position_profiles;
create policy position_profiles_read
  on public.position_profiles for select to authenticated
  using (true);

drop policy if exists position_profiles_insert on public.position_profiles;
create policy position_profiles_insert
  on public.position_profiles for insert to authenticated
  with check (public.is_admin() or public.my_member_id() = 'm-perez');

drop policy if exists position_profiles_update on public.position_profiles;
create policy position_profiles_update
  on public.position_profiles for update to authenticated
  using (public.is_admin() or public.my_member_id() = 'm-perez')
  with check (public.is_admin() or public.my_member_id() = 'm-perez');

grant select, insert, update on public.position_profiles to authenticated;
