-- Catálogo presupuestario por centro de costo (Instalaciones de Bienestar 5659)
create table if not exists public.cc_catalogo (
  cc_key text not null,
  codigo text not null,
  monto numeric not null default 0 check (monto >= 0),
  updated_by text references public.members(id) on delete set null,
  updated_at timestamptz not null default now(),
  primary key (cc_key, codigo)
);
alter table public.cc_catalogo enable row level security;
drop policy if exists cc_catalogo_read on public.cc_catalogo;
create policy cc_catalogo_read on public.cc_catalogo for select to authenticated using (true);
drop policy if exists cc_catalogo_write on public.cc_catalogo;
create policy cc_catalogo_write on public.cc_catalogo for all to authenticated
  using (public.is_admin() or public.my_member_id() in ('m-rodriguez','m-cerda','m-roberto-sandoval-corvacho'))
  with check (public.is_admin() or public.my_member_id() in ('m-rodriguez','m-cerda','m-roberto-sandoval-corvacho'));
grant select, insert, update, delete on public.cc_catalogo to authenticated;
do $$ begin begin alter publication supabase_realtime add table public.cc_catalogo; exception when others then null; end; end $$;
select 'ok' estado;
