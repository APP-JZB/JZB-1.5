-- Responsable secundario (apoyo/reemplazo) en tareas; ver historial de sesión para la función guard_task_update completa.
alter table public.tasks add column if not exists apoyo text references public.members(id) on delete set null;
