-- Carta Gantt del levantamiento de procesos TD 2026 (PPT TD 2026, lámina 73). Hito final: expediente remitido el 20 OCT 2026.
insert into public.tasks (title,area,tf,proc,member_id,apoyo,due,stages,log,evidencia,controla)
select v.title,v.area,'TF1','PLAN',v.m,v.a,v.due::timestamptz,'[]'::jsonb,
 '[{"t":"creada desde Carta Gantt del levantamiento (PPT TD 2026)","at":1791676800000}]'::jsonb,v.ev,'m-cerda'
from (values
 ('Levantamiento TD 2026 · Dirección y gestión administrativa (07–10 OCT)','CDO','m-passalacqua','m-urquieta','2026-10-10 18:00-03','Procesos ADM confirmados'),
 ('Levantamiento TD 2026 · Habitacional (08–12 OCT)','VF','m-ramirez','m-juan-leon-becerra','2026-10-12 18:00-03','Procesos HAT-01 a HAT-06, riesgos y controles confirmados'),
 ('Levantamiento TD 2026 · Habitabilidad (08–12 OCT)','HAB','m-martinez','m-diego-collao-choque','2026-10-12 18:00-03','Procesos HAB-01 a HAB-06, riesgos y controles confirmados'),
 ('Levantamiento TD 2026 · Recreacional (09–14 OCT)','REC','m-francia-mundaca-toledo','m-acuna','2026-10-14 18:00-03','Procesos REC-01 a REC-06, riesgos y controles confirmados'),
 ('Levantamiento TD 2026 · Jardín Infantil (09–14 OCT)','JI','m-hermosilla','m-melissa-cortes-candia','2026-10-14 18:00-03','Procesos JI-01 a JI-07, riesgos y controles confirmados'),
 ('Levantamiento TD 2026 · Consolidación EPR (15–17 OCT)','OCGR','m-urquieta','m-barbara-llancavil-cortez','2026-10-17 18:00-03','Expediente consolidado'),
 ('Levantamiento TD 2026 · Revisión y entrega del expediente (18–20 OCT)','CDO','m-cerda','m-azocar','2026-10-20 12:00-03','Expediente revisado y remitido el 20 OCT 2026')
) v(title,area,m,a,due,ev)
where not exists (select 1 from public.tasks t where t.title=v.title);
select count(*) levantamiento from public.tasks where title like 'Levantamiento TD 2026%';
