-- Hito ZB Arica · integraciones (ClickUp + asistente IA)
-- Ejecutar completo en: Supabase → SQL Editor → New query → Run. Se puede ejecutar más de una vez.

create extension if not exists pg_net;

-- Id de la tarea espejo en ClickUp
alter table public.tasks add column if not exists clickup_id text;

-- Secreto interno entre la base de datos y la función clickup-sync (sin políticas: nadie lo lee desde la app)
create table if not exists public.secrets (key text primary key, value text not null);
alter table public.secrets enable row level security;
revoke all on public.secrets from anon, authenticated;
insert into public.secrets (key, value) values ('hook', encode(gen_random_bytes(24), 'hex')) on conflict (key) do nothing;

-- Cada alta/cambio/borrado de tarea avisa a la función clickup-sync
create or replace function public.notify_clickup() returns trigger
language plpgsql security definer set search_path = public, extensions as $$
declare s text; payload jsonb;
begin
  -- evitar bucle cuando la propia función guarda el clickup_id
  if tg_op = 'UPDATE' and new.clickup_id is distinct from old.clickup_id
     and row(new.title,new.due,new.done,new.progress,new.member_id,new.stages,new.proc) is not distinct from row(old.title,old.due,old.done,old.progress,old.member_id,old.stages,old.proc) then
    return new;
  end if;
  select value into s from public.secrets where key = 'hook';
  payload := jsonb_build_object('op', tg_op, 'record', case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end);
  perform net.http_post(
    url := 'https://qgzdytylvsbvvmkmlvxq.supabase.co/functions/v1/clickup-sync',
    body := payload,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-hito-hook', s)
  );
  return coalesce(new, old);
exception when others then
  return coalesce(new, old); -- ClickUp nunca debe impedir guardar una tarea
end $$;

drop trigger if exists tasks_clickup on public.tasks;
create trigger tasks_clickup after insert or update or delete on public.tasks
  for each row execute function public.notify_clickup();
