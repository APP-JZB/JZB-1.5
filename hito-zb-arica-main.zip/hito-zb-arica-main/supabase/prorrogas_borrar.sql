-- El Comandante puede borrar solicitudes de prórroga (p. ej. duplicadas).
drop policy if exists prorrogas_delete on public.prorrogas;
create policy prorrogas_delete on public.prorrogas for delete to authenticated using (public.is_admin());
grant delete on public.prorrogas to authenticated;
select count(*) from pg_policies where tablename = 'prorrogas' and policyname = 'prorrogas_delete';
