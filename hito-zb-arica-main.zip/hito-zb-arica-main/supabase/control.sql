-- Control de gestión: actividades periódicas, riesgos, escalamiento
alter table public.tasks add column if not exists escalar boolean not null default false;
alter table public.tasks add column if not exists controla text references public.members(id) on delete set null;
alter table public.tasks add column if not exists evidencia text default '';
alter table public.tasks add column if not exists actividad_id uuid;
create table if not exists public.actividades (
  id uuid primary key default gen_random_uuid(),
  codigo text, title text not null, area text, periodicidad text not null default 'Mensual',
  dia int default 1, hora int default 12, prioridad text default 'MEDIA',
  member_id text references public.members(id) on delete set null,
  controla text references public.members(id) on delete set null,
  evidencia text default '', desde date, hasta date, activa boolean default true,
  created_at timestamptz default now()
);
create unique index if not exists tasks_actividad_due on public.tasks(actividad_id, due);
create table if not exists public.riesgos (
  id uuid primary key default gen_random_uuid(),
  codigo text, area text, actividad_id uuid references public.actividades(id) on delete set null,
  task_id uuid references public.tasks(id) on delete set null,
  tipo text default 'Operacional', descripcion text default '', probabilidad int, impacto int,
  accion text default '', responsable text references public.members(id) on delete set null,
  plazo date, estado_accion text default 'Pendiente', cierre date, created_at timestamptz default now()
);
alter table public.actividades enable row level security;
alter table public.riesgos enable row level security;
drop policy if exists act_read on public.actividades;
create policy act_read on public.actividades for select to authenticated using (true);
drop policy if exists act_write on public.actividades;
create policy act_write on public.actividades for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists ries_admin on public.riesgos;
create policy ries_admin on public.riesgos for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.actividades, public.riesgos to authenticated;
do $$ begin
  begin alter publication supabase_realtime add table public.actividades; exception when others then null; end;
  begin alter publication supabase_realtime add table public.riesgos; exception when others then null; end;
end $$;
insert into public.actividades (codigo,title,area,periodicidad,dia,hora,prioridad,member_id,controla,evidencia,desde,hasta)
select * from (values
 ('CAL-001','Reunión de Coordinación','OCGR','Semanal',5,9,'ALTA','m-urquieta','m-cerda','PPT', date '2026-10-06', date '2026-12-25'),
 ('CAL-002','Control de Liquidez de Centros de Costo','FIN','Mensual',25,12,'ALTA','m-rodriguez','m-cerda','Informe de liquidez por centro de costo', date '2026-10-10', date '2026-12-31'),
 ('CAL-003','Control de Adquisiciones, Licitaciones y Contratos','CGA','Semanal',1,12,'ALTA','m-veliz','m-cerda','Estado de licitaciones y OC', date '2026-10-10', date '2026-12-31'),
 ('CAL-004','Control del Estado Habitacional por Villa','VF','Mensual',25,12,'MEDIA','m-ramirez','m-cerda','Informe por villa', date '2026-10-10', date '2026-12-31'),
 ('CAL-005','Control del Estado de Habitabilidad','HAB','Mensual',25,12,'MEDIA','m-martinez','m-cerda','Informe de habitabilidad', date '2026-10-10', date '2026-12-31'),
 ('CAL-006','Control de Resultados Recreacionales','REC','Mensual',25,12,'MEDIA','m-francia-mundaca-toledo','m-cerda','Resultados CRA y COEM', date '2026-10-10', date '2026-12-31'),
 ('CAL-007','Control de Jardín Infantil y Convenios','ASI','Mensual',25,12,'MEDIA','m-vergara','m-cerda','Informe JI y convenios', date '2026-10-10', date '2026-12-31'),
 ('CAL-008','Control de Mantenimiento e Infraestructura','MANT','Según disposición',1,12,'ALTA','m-cid','m-cerda','', date '2026-10-10', date '2026-12-31'),
 ('CAL-009','Control de Vehículos Fiscales','LOG','Mensual',25,12,'MEDIA','m-carlos-chavez-jimenez','m-cerda','Control de vehículos', date '2026-10-10', date '2026-12-31')
) v where not exists (select 1 from public.actividades);
select 'ok' estado, (select count(*) from public.actividades) actividades;
