create or replace function public.actualizar_mis_datos(p_phone text, p_email text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if public.my_member_id() is null then raise exception 'Sin integrante asociado'; end if;
  update public.members set phone = nullif(trim(p_phone), ''), email = nullif(lower(trim(p_email)), '') where id = public.my_member_id();
end $$;
revoke all on function public.actualizar_mis_datos(text, text) from public, anon;
grant execute on function public.actualizar_mis_datos(text, text) to authenticated;
