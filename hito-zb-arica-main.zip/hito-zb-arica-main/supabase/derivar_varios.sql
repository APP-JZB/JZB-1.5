-- Derivar / delegar a uno o varios responsables. El primero queda como ejecutor (delegado), el resto como participantes.
-- Comandante: directo. Cualquier otro usuario: solicitud pend_cdte que aprueba el Comandante.
create or replace function public.derivar_varios(p_task uuid, p_destinos text[], p_due timestamptz default null) returns text
language plpgsql security definer set search_path = public as $$
declare yo text := public.my_member_id(); t public.tasks%rowtype; dest text;
begin
  if yo is null then raise exception 'Sin sesión'; end if;
  if coalesce(array_length(p_destinos, 1), 0) = 0 then raise exception 'Elige al menos una persona'; end if;
  select * into t from public.tasks where id = p_task;
  if not found then raise exception 'Tarea no encontrada'; end if;
  if not (public.is_admin() or t.member_id = yo or t.delegado = yo or t.apoyo = yo) then raise exception 'Solo un responsable de la tarea puede derivarla'; end if;
  dest := p_destinos[1];
  if public.is_admin() then
    perform set_config('hito.bypass', '1', true);
    update public.tasks set delegado = dest, delegado_por = yo, due = coalesce(p_due, due),
      participantes = coalesce((select array_agg(distinct x) from unnest(coalesce(participantes,'{}') || p_destinos[2:]) x where x <> dest and x <> member_id), '{}'),
      log = coalesce(log,'[]'::jsonb) || jsonb_build_array(jsonb_build_object('t', 'derivada a ' || (select string_agg(name, ', ') from public.members where id = any(p_destinos)), 'at', (extract(epoch from now())*1000)::bigint))
    where id = p_task;
    return 'derivada';
  end if;
  insert into public.solicitudes (tipo, task_id, datos, destino, solicitante, estado)
  values ('derivacion', p_task, jsonb_build_object('title', t.title, 'due', coalesce(p_due, t.due), 'destinos', to_jsonb(p_destinos)), dest, yo, 'pend_cdte');
  return 'pend_cdte';
end $$;
grant execute on function public.derivar_varios(uuid, text[], timestamptz) to authenticated;

-- Al aprobar una derivación con varios destinos, el resto queda como participantes.
create or replace function public.resolver_solicitud(p_id uuid, p_aprobar boolean, p_motivo text default '', p_datos jsonb default null, p_derivar_a text default null) returns text
language plpgsql security definer set search_path = public as $$
declare yo text := public.my_member_id(); s public.solicitudes%rowtype; nota text; dest text; otros text[];
begin
  select * into s from public.solicitudes where id = p_id for update;
  if not found then raise exception 'Solicitud no encontrada'; end if;
  if s.estado = 'pend_destino' and yo <> s.destino then raise exception 'La resuelve quien recibe el trabajo'; end if;
  if s.estado = 'pend_ja' and yo <> 'm-passalacqua' then raise exception 'La aprueba primero el Jefe Administrativo'; end if;
  if s.estado = 'pend_cdte' and not public.is_admin() then raise exception 'La aprueba el Comandante de Zona'; end if;
  if s.estado not in ('pend_ja','pend_cdte','pend_destino') then return s.estado; end if;
  if p_datos is not null then update public.solicitudes set datos = datos || p_datos where id = p_id; s.datos := s.datos || p_datos; end if;
  if not p_aprobar then
    update public.solicitudes set estado = 'rechazada', motivo = coalesce(p_motivo,'') where id = p_id;
    return 'rechazada';
  end if;
  if s.estado = 'pend_ja' and p_derivar_a is null then
    update public.solicitudes set estado = 'pend_cdte', ja_por = yo, ja_at = now() where id = p_id;
    return 'pend_cdte';
  end if;
  dest := coalesce(p_derivar_a, s.destino);
  otros := coalesce(array(select jsonb_array_elements_text(coalesce(s.datos->'destinos','[]'::jsonb))), '{}');
  nota := case when p_derivar_a is not null then ' · derivada por ' || (select name from public.members where id = yo)
               when s.estado = 'pend_destino' then ' · aceptada por quien la recibe'
               when s.datos ? 'destinos' then ' · aprobada por el Cdte.' else ' · aprobada por Jefe Adm. y Cdte.' end;
  if s.tipo = 'tarea' then
    perform public._publicar_tarea(s.datos, dest, s.solicitante, nota);
  else
    perform set_config('hito.bypass', '1', true);
    update public.tasks set delegado = dest, delegado_por = case when p_derivar_a is not null then yo else s.solicitante end,
      due = coalesce((s.datos->>'due')::timestamptz, due),
      participantes = case when cardinality(otros) > 0 then coalesce((select array_agg(distinct x) from unnest(coalesce(participantes,'{}') || otros) x where x <> dest and x <> member_id), '{}') else participantes end,
      log = coalesce(log,'[]'::jsonb) || jsonb_build_array(jsonb_build_object('t', 'derivada a ' || case when cardinality(otros) > 1 then (select string_agg(name, ', ') from public.members where id = any(otros)) else (select name from public.members where id = dest) end || nota, 'at', (extract(epoch from now())*1000)::bigint))
    where id = s.task_id;
  end if;
  update public.solicitudes set estado = 'aprobada', destino = dest, cdte_at = now(), ja_por = coalesce(ja_por, case when s.estado = 'pend_destino' then yo end) where id = p_id;
  return 'aprobada';
end $$;
grant execute on function public.resolver_solicitud(uuid, boolean, text, jsonb, text) to authenticated;
notify pgrst, 'reload schema';
select 'ok' estado;
